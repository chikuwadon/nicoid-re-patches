.class public final Le/e/a/DownloadActions116;
.super Ljava/lang/Object;
.source "DownloadActions116.java"


# static fields
.field static final CACHE:I = 0xa

.field static final MP4:I = 0x46d2


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static cache(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 13
    invoke-static {p1, p2}, Le/e/a/CacheTitles117;->remember(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p0, p1}, Le/e/a/CachedPlayback;->acquisitionIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-static {p0, p1}, Le/e/a/CacheFolders;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method public static complete(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    .line 7
    :try_start_0
    sget-object v0, Le/e/a/ListActions;->ACTIONS:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    if-nez v0, :cond_b

    return-void

    :cond_b
    const-string v1, "e"

    invoke-static {p0, v1}, Le/e/a/ListActions;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const-string v2, "d"

    invoke-static {v1, v2}, Le/e/a/ListActions;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/Activity;

    const-string v3, "b"

    invoke-static {v1, v3}, Le/e/a/ListActions;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const-string v3, "c"

    invoke-static {p0, v3}, Le/e/a/ListActions;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    instance-of v3, v1, Ljava/util/List;

    if-eqz v3, :cond_4d

    if-ltz p0, :cond_4d

    move-object v3, v1

    check-cast v3, Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-lt p0, v3, :cond_3b

    goto :goto_4d

    :cond_3b
    check-cast v1, Ljava/util/List;

    invoke-interface {v1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    const-string v1, "a"

    invoke-static {p1, v1}, Le/e/a/ListActions;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/Menu;

    invoke-static {p1, v0, v2, p0}, Le/e/a/DownloadActions116;->normalize(Landroid/view/Menu;Ljava/util/List;Landroid/app/Activity;Ljava/lang/Object;)V
    :try_end_4c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_4c} :catch_4e

    goto :goto_56

    :cond_4d
    :goto_4d
    return-void

    :catch_4e
    move-exception p0

    const-string p1, "nicoid-download"

    const-string v0, "Cannot attach video download actions"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_56
    return-void
.end method

.method static synthetic lambda$0(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 9
    invoke-static {p0, p1, p2}, Le/e/a/DownloadUi115;->choose(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$1(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 10
    invoke-static {p0, p1, p2}, Le/e/a/DownloadActions116;->cache(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$2(Le/e/a/ListActions$Action;Landroid/view/MenuItem;)Z
    .registers 2

    .line 11
    iget-object p0, p0, Le/e/a/ListActions$Action;->run:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    const/4 p0, 0x1

    return p0
.end method

.method static normalize(Landroid/view/Menu;Ljava/util/List;Landroid/app/Activity;Ljava/lang/Object;)V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/Menu;",
            "Ljava/util/List<",
            "Le/e/a/ListActions$Action;",
            ">;",
            "Landroid/app/Activity;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    .line 8
    invoke-static {p3}, Le/e/a/DownloadActions116;->videoId(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    :cond_b
    const-string v1, "title"

    invoke-static {p3, v1}, Le/e/a/ListActions;->value(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-static {v0, p3}, Le/e/a/CacheTitles117;->remember(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v3, 0x0

    move-object v4, v3

    :cond_1f
    :goto_1f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/16 v6, 0xa

    const/16 v7, 0x46d2

    if-nez v5, :cond_aa

    .line 9
    const/4 v5, 0x0

    if-nez v3, :cond_44

    const-string v2, "Save as MP4"

    const-string v3, "\u53e6\u5b58\u70baMP4"

    const-string v8, "MP4\u3067\u4fdd\u5b58"

    invoke-static {p2, v8, v2, v3}, Le/e/a/PanelUi;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v5, v7, v5, v2}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v2

    new-instance v3, Le/e/a/ListActions$Action;

    new-instance v7, Le/e/a/DownloadActions116$$ExternalSyntheticLambda0;

    invoke-direct {v7, p2, v0, p3}, Le/e/a/DownloadActions116$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v3, v2, v7}, Le/e/a/ListActions$Action;-><init>(Landroid/view/MenuItem;Ljava/lang/Runnable;)V

    .line 10
    :cond_44
    if-nez v4, :cond_60

    invoke-static {p2}, Le/e/a/ListActions;->cacheList(Landroid/app/Activity;)Z

    move-result v2

    if-nez v2, :cond_60

    const-string v2, "\u30ad\u30e3\u30c3\u30b7\u30e5\u53d6\u5f97"

    invoke-static {v2}, Le/e/a/UiStrings;->translate(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v5, v6, v5, v2}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v2

    new-instance v4, Le/e/a/ListActions$Action;

    new-instance v6, Le/e/a/DownloadActions116$$ExternalSyntheticLambda1;

    invoke-direct {v6, p2, v0, p3}, Le/e/a/DownloadActions116$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v4, v2, v6}, Le/e/a/ListActions$Action;-><init>(Landroid/view/MenuItem;Ljava/lang/Runnable;)V

    .line 11
    :cond_60
    const/4 p2, 0x4

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p3

    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-virtual {v1, p2, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    if-eqz v4, :cond_73

    add-int/lit8 p2, p2, 0x1

    invoke-virtual {v1, p2, v4}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_73
    invoke-interface {p0}, Landroid/view/Menu;->clear()V

    invoke-interface {p1}, Ljava/util/List;->clear()V

    move p2, v5

    :goto_7a
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-lt p2, p3, :cond_81

    .line 12
    return-void

    .line 11
    :cond_81
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Le/e/a/ListActions$Action;

    iget v0, p3, Le/e/a/ListActions$Action;->id:I

    iget-object v2, p3, Le/e/a/ListActions$Action;->title:Ljava/lang/String;

    invoke-interface {p0, v5, v0, p2, v2}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v2, p3, Le/e/a/ListActions$Action;->enabled:Z

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    move-result-object v0

    new-instance v2, Le/e/a/DownloadActions116$$ExternalSyntheticLambda2;

    invoke-direct {v2, p3}, Le/e/a/DownloadActions116$$ExternalSyntheticLambda2;-><init>(Le/e/a/ListActions$Action;)V

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    new-instance v2, Le/e/a/ListActions$Action;

    iget-object p3, p3, Le/e/a/ListActions$Action;->run:Ljava/lang/Runnable;

    invoke-direct {v2, v0, p3}, Le/e/a/ListActions$Action;-><init>(Landroid/view/MenuItem;Ljava/lang/Runnable;)V

    invoke-interface {p1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_7a

    .line 8
    :cond_aa
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Le/e/a/ListActions$Action;

    iget v8, v5, Le/e/a/ListActions$Action;->id:I

    if-ne v8, v7, :cond_b9

    if-nez v3, :cond_1f

    move-object v3, v5

    goto/16 :goto_1f

    :cond_b9
    iget v7, v5, Le/e/a/ListActions$Action;->id:I

    if-ne v7, v6, :cond_c2

    if-nez v4, :cond_1f

    move-object v4, v5

    goto/16 :goto_1f

    :cond_c2
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1f
.end method

.method static videoId(Ljava/lang/Object;)Ljava/lang/String;
    .registers 5

    .line 6
    const-string v0, "videoId"

    const-string v1, "video_id"

    const-string v2, "videourl"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :goto_b
    const/4 v2, 0x3

    if-lt v1, v2, :cond_11

    const-string p0, ""

    return-object p0

    :cond_11
    aget-object v2, v0, v1

    invoke-static {p0, v2}, Le/e/a/ListActions;->value(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Le/e/a/HistoryRules;->id(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_26

    const-string v3, "(?:sm|so|nm|ss)?[0-9]+"

    invoke-virtual {v2, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_26

    return-object v2

    :cond_26
    add-int/lit8 v1, v1, 0x1

    goto :goto_b
.end method
