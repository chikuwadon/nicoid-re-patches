.class public final Le/e/a/ContentFilterRules;
.super Ljava/lang/Object;
.source "ContentFilterRules.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/ContentFilterRules$Rule;
    }
.end annotation


# static fields
.field private static final cache:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 5
    new-instance v0, Ljava/util/LinkedHashMap;

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v2, 0x1

    const/16 v3, 0x100

    invoke-direct {v0, v3, v1, v2}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    sput-object v0, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Ljava/lang/String;)Ljava/lang/String;
    .registers 2
    .param p0, "x0"    # Ljava/lang/String;

    .line 3
    invoke-static {p0}, Le/e/a/ContentFilterRules;->normalized(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static blocked(Ljava/lang/String;[Ljava/lang/String;)Z
    .registers 8
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "words"    # [Ljava/lang/String;

    .line 8
    const/4 v0, 0x0

    if-eqz p0, :cond_1c

    array-length v1, p1

    if-nez v1, :cond_7

    goto :goto_1c

    :cond_7
    invoke-static {p0}, Le/e/a/ContentFilterRules;->normalized(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .local v1, "value":Ljava/lang/String;
    array-length v2, p1

    const/4 v3, 0x0

    :goto_d
    if-ge v3, v2, :cond_1c

    aget-object v4, p1, v3

    .local v4, "w":Ljava/lang/String;
    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_19

    const/4 v0, 0x1

    return v0

    .end local v4    # "w":Ljava/lang/String;
    :cond_19
    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    .end local v1    # "value":Ljava/lang/String;
    :cond_1c
    :goto_1c
    return v0
.end method

.method public static keywords(Ljava/lang/String;)[Ljava/lang/String;
    .registers 8
    .param p0, "v"    # Ljava/lang/String;

    .line 7
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .local v0, "a":Ljava/util/LinkedHashSet;, "Ljava/util/LinkedHashSet<Ljava/lang/String;>;"
    const/4 v1, 0x0

    if-eqz p0, :cond_28

    const-string v2, "[,\uff0c\u3001\\r\\n]+"

    invoke-virtual {p0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x0

    :goto_10
    if-ge v4, v3, :cond_28

    aget-object v5, v2, v4

    .local v5, "s":Ljava/lang/String;
    invoke-static {v5}, Le/e/a/ContentFilterRules;->normalized(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_25

    invoke-virtual {v0, v5}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    .end local v5    # "s":Ljava/lang/String;
    :cond_25
    add-int/lit8 v4, v4, 0x1

    goto :goto_10

    :cond_28
    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashSet;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    return-object v1
.end method

.method private static declared-synchronized normalized(Ljava/lang/String;)Ljava/lang/String;
    .registers 5
    .param p0, "v"    # Ljava/lang/String;

    const-class v0, Le/e/a/ContentFilterRules;

    monitor-enter v0

    .line 6
    :try_start_3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x1000

    if-le v1, v2, :cond_19

    sget-object v1, Ljava/text/Normalizer$Form;->NFKC:Ljava/text/Normalizer$Form;

    invoke-static {p0, v1}, Ljava/text/Normalizer;->normalize(Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_55

    monitor-exit v0

    return-object v1

    :cond_19
    :try_start_19
    sget-object v1, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;
    :try_end_21
    .catchall {:try_start_19 .. :try_end_21} :catchall_55

    .local v1, "x":Ljava/lang/String;
    if-eqz v1, :cond_25

    monitor-exit v0

    return-object v1

    :cond_25
    :try_start_25
    sget-object v2, Ljava/text/Normalizer$Form;->NFKC:Ljava/text/Normalizer$Form;

    invoke-static {p0, v2}, Ljava/text/Normalizer;->normalize(Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    .end local v1    # "x":Ljava/lang/String;
    .local v2, "x":Ljava/lang/String;
    sget-object v1, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p0, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->size()I

    move-result v1

    const/16 v3, 0x100

    if-le v1, v3, :cond_53

    sget-object v1, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    sget-object v3, Le/e/a/ContentFilterRules;->cache:Ljava/util/LinkedHashMap;

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_53
    .catchall {:try_start_25 .. :try_end_53} :catchall_55

    :cond_53
    monitor-exit v0

    return-object v2

    .line 6
    .end local v2    # "x":Ljava/lang/String;
    .end local p0    # "v":Ljava/lang/String;
    :catchall_55
    move-exception p0

    :try_start_56
    monitor-exit v0
    :try_end_57
    .catchall {:try_start_56 .. :try_end_57} :catchall_55

    throw p0
.end method
