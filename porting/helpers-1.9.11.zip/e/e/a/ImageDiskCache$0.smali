.class public final synthetic Le/e/a/ImageDiskCache$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Le/e/a/ImageDiskCache;"
    method = "lambda$new$0"
    proto = "(Le/e/a/ImageDiskCache$Entry;Le/e/a/ImageDiskCache$Entry;)I"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 3

    .line 0
    check-cast p1, Le/e/a/ImageDiskCache$Entry;

    check-cast p2, Le/e/a/ImageDiskCache$Entry;

    invoke-static {p1, p2}, Le/e/a/ImageDiskCache;->lambda$new$0(Le/e/a/ImageDiskCache$Entry;Le/e/a/ImageDiskCache$Entry;)I

    move-result p1

    return p1
.end method
