.class final Le/e/a/ImageDiskCache;
.super Ljava/lang/Object;
.source "ImageDiskCache.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/ImageDiskCache$Entry;
    }
.end annotation


# static fields
.field private static final AGE:J = 0x240c8400L

.field private static final LIMIT:J = 0x2000000L

.field private static final RECONCILE_NANOS:J = 0x45d964b800L

.field private static final TEMP_AGE:J = 0x5265c00L


# instance fields
.field private final directory:Ljava/io/File;

.field private initialized:Z

.field private final known:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Le/e/a/ImageDiskCache$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private final oldest:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Le/e/a/ImageDiskCache$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private reconciled:J

.field reconciliations:I

.field private total:J


# direct methods
.method constructor <init>(Ljava/io/File;)V
    .registers 4
    .param p1, "parent"    # Ljava/io/File;

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Le/e/a/ImageDiskCache;->known:Ljava/util/Map;

    .line 9
    new-instance v0, Ljava/util/TreeSet;

    new-instance v1, Le/e/a/ImageDiskCache$0;

    invoke-direct {v1}, Le/e/a/ImageDiskCache$0;-><init>()V

    invoke-direct {v0, v1}, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V

    iput-object v0, p0, Le/e/a/ImageDiskCache;->oldest:Ljava/util/TreeSet;

    .line 12
    new-instance v0, Ljava/io/File;

    const-string v1, "nicoid-thumbnails"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    return-void
.end method

.method private file(Ljava/lang/String;)Ljava/io/File;
    .registers 9
    .param p1, "url"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13
    :try_start_0
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const-string v1, "UTF-8"

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v0

    .local v0, "digest":[B
    const-string v1, "0123456789abcdef"

    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    .local v1, "hex":[C
    array-length v2, v0

    mul-int/lit8 v2, v2, 0x2

    new-array v2, v2, [C

    .local v2, "name":[C
    const/4 v3, 0x0

    .local v3, "n":I
    :goto_1c
    array-length v4, v0

    if-ge v3, v4, :cond_38

    aget-byte v4, v0, v3

    and-int/lit16 v4, v4, 0xff

    .local v4, "b":I
    mul-int/lit8 v5, v3, 0x2

    ushr-int/lit8 v6, v4, 0x4

    aget-char v6, v1, v6

    aput-char v6, v2, v5

    mul-int/lit8 v5, v3, 0x2

    add-int/lit8 v5, v5, 0x1

    and-int/lit8 v6, v4, 0xf

    aget-char v6, v1, v6

    aput-char v6, v2, v5

    .end local v4    # "b":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_1c

    .end local v3    # "n":I
    :cond_38
    new-instance v3, Ljava/io/File;

    iget-object v4, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v6, Ljava/lang/String;

    invoke-direct {v6, v2}, Ljava/lang/String;-><init>([C)V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".img"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_57
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_57} :catch_58

    return-object v3

    .end local v0    # "digest":[B
    .end local v1    # "hex":[C
    .end local v2    # "name":[C
    :catch_58
    move-exception v0

    .local v0, "e":Ljava/security/NoSuchAlgorithmException;
    new-instance v1, Ljava/io/IOException;

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method private forget(Ljava/io/File;)V
    .registers 7
    .param p1, "f"    # Ljava/io/File;

    .line 14
    iget-object v0, p0, Le/e/a/ImageDiskCache;->known:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Le/e/a/ImageDiskCache$Entry;

    .local v0, "old":Le/e/a/ImageDiskCache$Entry;
    if-eqz v0, :cond_1a

    iget-object v1, p0, Le/e/a/ImageDiskCache;->oldest:Ljava/util/TreeSet;

    invoke-virtual {v1, v0}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    iget-wide v1, p0, Le/e/a/ImageDiskCache;->total:J

    iget-wide v3, v0, Le/e/a/ImageDiskCache$Entry;->size:J

    sub-long/2addr v1, v3

    iput-wide v1, p0, Le/e/a/ImageDiskCache;->total:J

    :cond_1a
    return-void
.end method

.method static synthetic lambda$new$0(Le/e/a/ImageDiskCache$Entry;Le/e/a/ImageDiskCache$Entry;)I
    .registers 6
    .param p0, "a"    # Le/e/a/ImageDiskCache$Entry;
    .param p1, "b"    # Le/e/a/ImageDiskCache$Entry;

    .line 9
    iget-wide v0, p0, Le/e/a/ImageDiskCache$Entry;->time:J

    iget-wide v2, p1, Le/e/a/ImageDiskCache$Entry;->time:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    .local v0, "n":I
    if-nez v0, :cond_1b

    iget-object v1, p0, Le/e/a/ImageDiskCache$Entry;->file:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p1, Le/e/a/ImageDiskCache$Entry;->file:Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v1

    goto :goto_1c

    :cond_1b
    move v1, v0

    :goto_1c
    return v1
.end method

.method private reconcile()V
    .registers 15

    .line 16
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    .local v0, "now":J
    iget-boolean v2, p0, Le/e/a/ImageDiskCache;->initialized:Z

    if-eqz v2, :cond_16

    iget-wide v2, p0, Le/e/a/ImageDiskCache;->reconciled:J

    sub-long v2, v0, v2

    const-wide v4, 0x45d964b800L

    cmp-long v6, v2, v4

    if-gez v6, :cond_16

    return-void

    :cond_16
    iget-object v2, p0, Le/e/a/ImageDiskCache;->known:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->clear()V

    iget-object v2, p0, Le/e/a/ImageDiskCache;->oldest:Ljava/util/TreeSet;

    invoke-virtual {v2}, Ljava/util/TreeSet;->clear()V

    const-wide/16 v2, 0x0

    iput-wide v2, p0, Le/e/a/ImageDiskCache;->total:J

    iget-object v2, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    .local v2, "files":[Ljava/io/File;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .local v3, "wall":J
    if-eqz v2, :cond_69

    array-length v5, v2

    const/4 v6, 0x0

    :goto_32
    if-ge v6, v5, :cond_69

    aget-object v7, v2, v6

    .local v7, "f":Ljava/io/File;
    invoke-virtual {v7}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v8

    .local v8, "name":Ljava/lang/String;
    const-string v9, ".img"

    invoke-virtual {v8, v9}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_46

    invoke-direct {p0, v7}, Le/e/a/ImageDiskCache;->remember(Ljava/io/File;)V

    goto :goto_66

    :cond_46
    const-string v9, "image-"

    invoke-virtual {v8, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_66

    const-string v9, ".tmp"

    invoke-virtual {v8, v9}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_66

    invoke-virtual {v7}, Ljava/io/File;->lastModified()J

    move-result-wide v9

    sub-long v9, v3, v9

    const-wide/32 v11, 0x5265c00

    cmp-long v13, v9, v11

    if-lez v13, :cond_66

    invoke-virtual {v7}, Ljava/io/File;->delete()Z

    .end local v7    # "f":Ljava/io/File;
    .end local v8    # "name":Ljava/lang/String;
    :cond_66
    :goto_66
    add-int/lit8 v6, v6, 0x1

    goto :goto_32

    :cond_69
    const/4 v5, 0x1

    iput-boolean v5, p0, Le/e/a/ImageDiskCache;->initialized:Z

    iput-wide v0, p0, Le/e/a/ImageDiskCache;->reconciled:J

    iget v6, p0, Le/e/a/ImageDiskCache;->reconciliations:I

    add-int/2addr v6, v5

    iput v6, p0, Le/e/a/ImageDiskCache;->reconciliations:I

    return-void
.end method

.method private remember(Ljava/io/File;)V
    .registers 7
    .param p1, "f"    # Ljava/io/File;

    .line 15
    invoke-direct {p0, p1}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V

    new-instance v0, Le/e/a/ImageDiskCache$Entry;

    invoke-direct {v0, p1}, Le/e/a/ImageDiskCache$Entry;-><init>(Ljava/io/File;)V

    .local v0, "e":Le/e/a/ImageDiskCache$Entry;
    iget-object v1, p0, Le/e/a/ImageDiskCache;->known:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Le/e/a/ImageDiskCache;->oldest:Ljava/util/TreeSet;

    invoke-virtual {v1, v0}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    iget-wide v1, p0, Le/e/a/ImageDiskCache;->total:J

    iget-wide v3, v0, Le/e/a/ImageDiskCache$Entry;->size:J

    add-long/2addr v1, v3

    iput-wide v1, p0, Le/e/a/ImageDiskCache;->total:J

    return-void
.end method

.method private trim()V
    .registers 10

    .line 26
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .local v0, "now":J
    iget-object v2, p0, Le/e/a/ImageDiskCache;->oldest:Ljava/util/TreeSet;

    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .local v2, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Le/e/a/ImageDiskCache$Entry;>;"
    :cond_a
    :goto_a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_57

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/ImageDiskCache$Entry;

    .local v3, "e":Le/e/a/ImageDiskCache$Entry;
    iget-wide v4, p0, Le/e/a/ImageDiskCache;->total:J

    const-wide/32 v6, 0x2000000

    cmp-long v8, v4, v6

    if-gtz v8, :cond_31

    iget-wide v4, v3, Le/e/a/ImageDiskCache$Entry;->time:J

    sub-long v4, v0, v4

    const-wide/32 v6, 0x240c8400

    cmp-long v8, v4, v6

    if-gtz v8, :cond_31

    iget-wide v4, v3, Le/e/a/ImageDiskCache$Entry;->time:J

    cmp-long v6, v0, v4

    if-ltz v6, :cond_31

    goto :goto_57

    :cond_31
    iget-object v4, v3, Le/e/a/ImageDiskCache$Entry;->file:Ljava/io/File;

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    move-result v4

    if-nez v4, :cond_41

    iget-object v4, v3, Le/e/a/ImageDiskCache$Entry;->file:Ljava/io/File;

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_a

    :cond_41
    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    iget-object v4, p0, Le/e/a/ImageDiskCache;->known:Ljava/util/Map;

    iget-object v5, v3, Le/e/a/ImageDiskCache$Entry;->file:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-wide v4, p0, Le/e/a/ImageDiskCache;->total:J

    iget-wide v6, v3, Le/e/a/ImageDiskCache$Entry;->size:J

    sub-long/2addr v4, v6

    iput-wide v4, p0, Le/e/a/ImageDiskCache;->total:J

    goto :goto_a

    .end local v2    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Le/e/a/ImageDiskCache$Entry;>;"
    .end local v3    # "e":Le/e/a/ImageDiskCache$Entry;
    :cond_57
    :goto_57
    return-void
.end method


# virtual methods
.method declared-synchronized get(Ljava/lang/String;)[B
    .registers 12
    .param p1, "url"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    .line 17
    :try_start_1
    invoke-direct {p0, p1}, Le/e/a/ImageDiskCache;->file(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .local v0, "f":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_11

    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V
    :try_end_f
    .catchall {:try_start_1 .. :try_end_f} :catchall_93

    monitor-exit p0

    return-object v2

    .end local p0    # "this":Le/e/a/ImageDiskCache;
    :cond_11
    :try_start_11
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v0}, Ljava/io/File;->lastModified()J

    move-result-wide v5

    sub-long/2addr v3, v5

    .local v3, "age":J
    const-wide/16 v5, 0x0

    cmp-long v1, v3, v5

    if-ltz v1, :cond_88

    const-wide/32 v5, 0x240c8400

    cmp-long v1, v3, v5

    if-gtz v1, :cond_88

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v5

    const-wide/32 v7, 0x800000

    cmp-long v1, v5, v7

    if-lez v1, :cond_33

    goto :goto_88

    :cond_33
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_38
    .catchall {:try_start_11 .. :try_end_38} :catchall_93

    .local v1, "in":Ljava/io/InputStream;
    :try_start_38
    new-instance v5, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v5}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_3d
    .catchall {:try_start_38 .. :try_end_3d} :catchall_7e

    .local v5, "body":Ljava/io/ByteArrayOutputStream;
    const/16 v6, 0x2000

    :try_start_3f
    new-array v6, v6, [B

    .local v6, "b":[B
    :goto_41
    invoke-virtual {v1, v6}, Ljava/io/InputStream;->read([B)I

    move-result v7

    move v8, v7

    .local v8, "n":I
    const/4 v9, -0x1

    if-eq v7, v9, :cond_68

    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v7

    add-int/2addr v7, v8

    const/high16 v9, 0x800000

    if-le v7, v9, :cond_63

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v7

    if-eqz v7, :cond_5b

    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V
    :try_end_5b
    .catchall {:try_start_3f .. :try_end_5b} :catchall_74

    :cond_5b
    :try_start_5b
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5e
    .catchall {:try_start_5b .. :try_end_5e} :catchall_7e

    :try_start_5e
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_61
    .catchall {:try_start_5e .. :try_end_61} :catchall_93

    monitor-exit p0

    return-object v2

    :cond_63
    const/4 v7, 0x0

    :try_start_64
    invoke-virtual {v5, v6, v7, v8}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_41

    :cond_68
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2
    :try_end_6c
    .catchall {:try_start_64 .. :try_end_6c} :catchall_74

    :try_start_6c
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_6f
    .catchall {:try_start_6c .. :try_end_6f} :catchall_7e

    :try_start_6f
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_72
    .catchall {:try_start_6f .. :try_end_72} :catchall_93

    monitor-exit p0

    return-object v2

    .end local v6    # "b":[B
    .end local v8    # "n":I
    :catchall_74
    move-exception v2

    :try_start_75
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_78
    .catchall {:try_start_75 .. :try_end_78} :catchall_79

    goto :goto_7d

    :catchall_79
    move-exception v6

    :try_start_7a
    invoke-virtual {v2, v6}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "f":Ljava/io/File;
    .end local v1    # "in":Ljava/io/InputStream;
    .end local v3    # "age":J
    .end local p1    # "url":Ljava/lang/String;
    :goto_7d
    throw v2
    :try_end_7e
    .catchall {:try_start_7a .. :try_end_7e} :catchall_7e

    .end local v5    # "body":Ljava/io/ByteArrayOutputStream;
    .restart local v0    # "f":Ljava/io/File;
    .restart local v1    # "in":Ljava/io/InputStream;
    .restart local v3    # "age":J
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_7e
    move-exception v2

    :try_start_7f
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_82
    .catchall {:try_start_7f .. :try_end_82} :catchall_83

    goto :goto_87

    :catchall_83
    move-exception v5

    :try_start_84
    invoke-virtual {v2, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_87
    throw v2

    .end local v1    # "in":Ljava/io/InputStream;
    :cond_88
    :goto_88
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v1

    if-eqz v1, :cond_91

    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V
    :try_end_91
    .catchall {:try_start_84 .. :try_end_91} :catchall_93

    :cond_91
    monitor-exit p0

    return-object v2

    .line 17
    .end local v0    # "f":Ljava/io/File;
    .end local v3    # "age":J
    .end local p1    # "url":Ljava/lang/String;
    :catchall_93
    move-exception p1

    :try_start_94
    monitor-exit p0
    :try_end_95
    .catchall {:try_start_94 .. :try_end_95} :catchall_93

    throw p1
.end method

.method declared-synchronized put(Ljava/lang/String;[B)V
    .registers 10
    .param p1, "url"    # Ljava/lang/String;
    .param p2, "data"    # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    .line 20
    :try_start_1
    array-length v0, p2

    if-eqz v0, :cond_82

    array-length v0, p2

    const/high16 v1, 0x800000

    if-le v0, v1, :cond_b

    goto/16 :goto_82

    .line 21
    :cond_b
    iget-object v0, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-nez v0, :cond_24

    iget-object v0, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_1c

    goto :goto_24

    :cond_1c
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Thumbnail cache unavailable"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .end local p0    # "this":Le/e/a/ImageDiskCache;
    :cond_24
    :goto_24
    invoke-direct {p0}, Le/e/a/ImageDiskCache;->reconcile()V

    .line 22
    invoke-direct {p0, p1}, Le/e/a/ImageDiskCache;->file(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .local v0, "target":Ljava/io/File;
    const-string v1, "image-"

    const-string v2, ".tmp"

    iget-object v3, p0, Le/e/a/ImageDiskCache;->directory:Ljava/io/File;

    invoke-static {v1, v2, v3}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v1
    :try_end_35
    .catchall {:try_start_1 .. :try_end_35} :catchall_84

    .line 23
    .local v1, "temporary":Ljava/io/File;
    :try_start_35
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_3a
    .catchall {:try_start_35 .. :try_end_3a} :catchall_7d

    .local v2, "out":Ljava/io/OutputStream;
    :try_start_3a
    invoke-virtual {v2, p2}, Ljava/io/OutputStream;->write([B)V
    :try_end_3d
    .catchall {:try_start_3a .. :try_end_3d} :catchall_73

    :try_start_3d
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    .end local v2    # "out":Ljava/io/OutputStream;
    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v2

    if-eqz v2, :cond_6b

    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->remember(Ljava/io/File;)V

    invoke-direct {p0}, Le/e/a/ImageDiskCache;->trim()V

    iget-wide v2, p0, Le/e/a/ImageDiskCache;->total:J

    const-wide/32 v4, 0x2000000

    cmp-long v6, v2, v4

    if-lez v6, :cond_66

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v2

    if-eqz v2, :cond_5e

    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V

    :cond_5e
    new-instance v2, Ljava/io/IOException;

    const-string v3, "Thumbnail cache limit unavailable"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local p1    # "url":Ljava/lang/String;
    .end local p2    # "data":[B
    :goto_65
    throw v2
    :try_end_66
    .catchall {:try_start_3d .. :try_end_66} :catchall_7d

    .line 24
    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local p1    # "url":Ljava/lang/String;
    .restart local p2    # "data":[B
    :cond_66
    :try_start_66
    invoke-virtual {v1}, Ljava/io/File;->delete()Z
    :try_end_69
    .catchall {:try_start_66 .. :try_end_69} :catchall_84

    .line 25
    monitor-exit p0

    return-void

    .line 23
    :cond_6b
    :try_start_6b
    new-instance v2, Ljava/io/IOException;

    const-string v3, "Thumbnail cache write failed"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    :try_end_72
    .catchall {:try_start_6b .. :try_end_72} :catchall_7d

    goto :goto_65

    .restart local v2    # "out":Ljava/io/OutputStream;
    :catchall_73
    move-exception v3

    :try_start_74
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_77
    .catchall {:try_start_74 .. :try_end_77} :catchall_78

    goto :goto_7c

    :catchall_78
    move-exception v4

    :try_start_79
    invoke-virtual {v3, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local p1    # "url":Ljava/lang/String;
    .end local p2    # "data":[B
    :goto_7c
    throw v3
    :try_end_7d
    .catchall {:try_start_79 .. :try_end_7d} :catchall_7d

    .line 24
    .end local v2    # "out":Ljava/io/OutputStream;
    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local p1    # "url":Ljava/lang/String;
    .restart local p2    # "data":[B
    :catchall_7d
    move-exception v2

    :try_start_7e
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    throw v2
    :try_end_82
    .catchall {:try_start_7e .. :try_end_82} :catchall_84

    .line 20
    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    :cond_82
    :goto_82
    monitor-exit p0

    return-void

    .line 19
    .end local p1    # "url":Ljava/lang/String;
    .end local p2    # "data":[B
    :catchall_84
    move-exception p1

    :try_start_85
    monitor-exit p0
    :try_end_86
    .catchall {:try_start_85 .. :try_end_86} :catchall_84

    throw p1
.end method

.method declared-synchronized remove(Ljava/lang/String;)V
    .registers 4
    .param p1, "url"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    monitor-enter p0

    .line 18
    :try_start_1
    invoke-direct {p0, p1}, Le/e/a/ImageDiskCache;->file(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .local v0, "f":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_14

    .end local p0    # "this":Le/e/a/ImageDiskCache;
    :cond_11
    invoke-direct {p0, v0}, Le/e/a/ImageDiskCache;->forget(Ljava/io/File;)V
    :try_end_14
    .catchall {:try_start_1 .. :try_end_14} :catchall_16

    :cond_14
    monitor-exit p0

    return-void

    .line 18
    .end local v0    # "f":Ljava/io/File;
    .end local p1    # "url":Ljava/lang/String;
    :catchall_16
    move-exception p1

    :try_start_17
    monitor-exit p0
    :try_end_18
    .catchall {:try_start_17 .. :try_end_18} :catchall_16

    throw p1
.end method
