.class public final Le/e/a/RowDates194;
.super Ljava/lang/Object;
.source "RowDates194.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/RowDates194$Formats;
    }
.end annotation


# static fields
.field private static final DATE:Ljava/util/regex/Pattern;

.field private static final EPOCH:Ljava/util/regex/Pattern;

.field private static final FORMATS:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Le/e/a/RowDates194$Formats;",
            ">;"
        }
    .end annotation
.end field

.field private static final PARSED:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private static final PATTERNS:[Ljava/lang/String;

.field private static final TAGS:Ljava/util/regex/Pattern;

.field private static final ZONE:Ljava/util/TimeZone;

.field private static final ZONE_SUFFIX:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 6
    const-string v0, "<[^>]*>"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->TAGS:Ljava/util/regex/Pattern;

    const-string v0, "[0-9]{10}|[0-9]{13}"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->EPOCH:Ljava/util/regex/Pattern;

    .line 7
    const-string v0, "[0-9]{4}(?:[-/][0-9]{2}[-/][0-9]{2}[ T][0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:\\.[0-9]+)?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?|\u5e74[0-9]{2}\u6708[0-9]{2}\u65e5 [0-9]{2}(?:\u6642[0-9]{2}\u5206|:[0-9]{2}))"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->DATE:Ljava/util/regex/Pattern;

    .line 8
    const-string v0, "(?:Z|[+-][0-9]{2}:?[0-9]{2})$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->ZONE_SUFFIX:Ljava/util/regex/Pattern;

    .line 9
    const-string v0, "Asia/Tokyo"

    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->ZONE:Ljava/util/TimeZone;

    .line 10
    const-string v7, "yyyy\u5e74MM\u6708dd\u65e5 HH\u6642mm\u5206"

    const-string v8, "yyyy\u5e74MM\u6708dd\u65e5 HH:mm"

    const-string v1, "yyyy-MM-dd HH:mm"

    const-string v2, "yyyy-MM-dd HH:mm:ss"

    const-string v3, "yyyy-MM-dd HH:mm:ss.SSS"

    const-string v4, "yyyy-MM-dd HH:mmXXX"

    const-string v5, "yyyy-MM-dd HH:mm:ssXXX"

    const-string v6, "yyyy-MM-dd HH:mm:ss.SSSXXX"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le/e/a/RowDates194;->PATTERNS:[Ljava/lang/String;

    .line 11
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Le/e/a/RowDates194;->FORMATS:Ljava/lang/ThreadLocal;

    .line 12
    new-instance v0, Le/e/a/RowDates194$1;

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v2, 0x1

    const/16 v3, 0x100

    invoke-direct {v0, v3, v1, v2}, Le/e/a/RowDates194$1;-><init>(IFZ)V

    sput-object v0, Le/e/a/RowDates194;->PARSED:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000()[Ljava/lang/String;
    .registers 1

    .line 4
    sget-object v0, Le/e/a/RowDates194;->PATTERNS:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$100(Ljava/lang/String;)Ljava/text/SimpleDateFormat;
    .registers 2
    .param p0, "x0"    # Ljava/lang/String;

    .line 4
    invoke-static {p0}, Le/e/a/RowDates194;->create(Ljava/lang/String;)Ljava/text/SimpleDateFormat;

    move-result-object v0

    return-object v0
.end method

.method private static create(Ljava/lang/String;)Ljava/text/SimpleDateFormat;
    .registers 3
    .param p0, "pattern"    # Ljava/lang/String;

    .line 14
    new-instance v0, Ljava/text/SimpleDateFormat;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-direct {v0, p0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .local v0, "f":Ljava/text/SimpleDateFormat;
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->setLenient(Z)V

    sget-object v1, Le/e/a/RowDates194;->ZONE:Ljava/util/TimeZone;

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    return-object v0
.end method

.method public static format(JLjava/lang/String;)Ljava/lang/String;
    .registers 6
    .param p0, "millis"    # J
    .param p2, "label"    # Ljava/lang/String;

    .line 25
    const-wide/16 v0, 0x0

    cmp-long v2, p0, v0

    if-gtz v2, :cond_9

    const-string v0, ""

    goto :goto_33

    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Le/e/a/RowDates194;->formats()Le/e/a/RowDates194$Formats;

    move-result-object v1

    iget-object v1, v1, Le/e/a/RowDates194$Formats;->output:Ljava/text/SimpleDateFormat;

    new-instance v2, Ljava/util/Date;

    invoke-direct {v2, p0, p1}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v1, v2}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p2}, Le/e/a/UiStrings;->translate(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_33
    return-object v0
.end method

.method private static formats()Le/e/a/RowDates194$Formats;
    .registers 3

    .line 15
    sget-object v0, Le/e/a/RowDates194;->FORMATS:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Le/e/a/RowDates194$Formats;

    .local v0, "f":Le/e/a/RowDates194$Formats;
    if-nez v0, :cond_16

    new-instance v1, Le/e/a/RowDates194$Formats;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Le/e/a/RowDates194$Formats;-><init>(Le/e/a/RowDates194$1;)V

    move-object v0, v1

    sget-object v1, Le/e/a/RowDates194;->FORMATS:Ljava/lang/ThreadLocal;

    invoke-virtual {v1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_16
    return-object v0
.end method

.method public static millis(Ljava/lang/String;)J
    .registers 6
    .param p0, "source"    # Ljava/lang/String;

    .line 16
    if-nez p0, :cond_5

    const-wide/16 v0, 0x0

    return-wide v0

    :cond_5
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x800

    if-gt v0, v1, :cond_25

    sget-object v0, Le/e/a/RowDates194;->PARSED:Ljava/util/Map;

    monitor-enter v0

    :try_start_10
    sget-object v2, Le/e/a/RowDates194;->PARSED:Ljava/util/Map;

    invoke-interface {v2, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    .local v2, "c":Ljava/lang/Long;
    if-eqz v2, :cond_20

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    monitor-exit v0

    return-wide v3

    .end local v2    # "c":Ljava/lang/Long;
    :cond_20
    monitor-exit v0

    goto :goto_25

    :catchall_22
    move-exception v1

    monitor-exit v0
    :try_end_24
    .catchall {:try_start_10 .. :try_end_24} :catchall_22

    throw v1

    :cond_25
    :goto_25
    invoke-static {p0}, Le/e/a/RowDates194;->parse(Ljava/lang/String;)J

    move-result-wide v2

    .local v2, "value":J
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-gt v0, v1, :cond_40

    sget-object v0, Le/e/a/RowDates194;->PARSED:Ljava/util/Map;

    monitor-enter v0

    :try_start_32
    sget-object v1, Le/e/a/RowDates194;->PARSED:Ljava/util/Map;

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-interface {v1, p0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0

    goto :goto_40

    :catchall_3d
    move-exception v1

    monitor-exit v0
    :try_end_3f
    .catchall {:try_start_32 .. :try_end_3f} :catchall_3d

    throw v1

    :cond_40
    :goto_40
    return-wide v2
.end method

.method private static parse(Ljava/lang/String;)J
    .registers 19
    .param p0, "source"    # Ljava/lang/String;

    .line 17
    sget-object v0, Le/e/a/RowDates194;->TAGS:Ljava/util/regex/Pattern;

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const-string v2, ""

    invoke-virtual {v0, v2}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .end local p0    # "source":Ljava/lang/String;
    .local v1, "source":Ljava/lang/String;
    sget-object v0, Le/e/a/RowDates194;->EPOCH:Ljava/util/regex/Pattern;

    invoke-virtual {v0, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    const-wide/16 v3, 0x0

    if-eqz v0, :cond_35

    :try_start_20
    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    .local v5, "n":J
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v0
    :try_end_28
    .catch Ljava/lang/NumberFormatException; {:try_start_20 .. :try_end_28} :catch_33

    const/16 v2, 0xa

    if-ne v0, v2, :cond_31

    const-wide/16 v2, 0x3e8

    mul-long v2, v2, v5

    goto :goto_32

    :cond_31
    move-wide v2, v5

    :goto_32
    return-wide v2

    .end local v5    # "n":J
    :catch_33
    move-exception v0

    .local v0, "e":Ljava/lang/NumberFormatException;
    return-wide v3

    .end local v0    # "e":Ljava/lang/NumberFormatException;
    :cond_35
    sget-object v0, Le/e/a/RowDates194;->DATE:Ljava/util/regex/Pattern;

    invoke-virtual {v0, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .local v0, "found":Ljava/util/regex/Matcher;
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v5

    if-nez v5, :cond_42

    return-wide v3

    :cond_42
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v5

    .line 18
    .local v5, "date":Ljava/lang/String;
    const/16 v6, 0x5e74

    invoke-virtual {v5, v6}, Ljava/lang/String;->indexOf(I)I

    move-result v6

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-ltz v6, :cond_5b

    const/16 v2, 0x6642

    invoke-virtual {v5, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    if-ltz v2, :cond_59

    const/4 v7, 0x6

    .local v7, "pattern":I
    :cond_59
    goto/16 :goto_11c

    .line 19
    .end local v7    # "pattern":I
    :cond_5b
    const/4 v6, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    invoke-virtual {v5, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-eq v6, v7, :cond_67

    return-wide v3

    :cond_67
    const/16 v6, 0x2f

    const/16 v7, 0x2d

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x54

    const/16 v9, 0x20

    invoke-virtual {v6, v7, v9}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Le/e/a/RowDates194;->ZONE_SUFFIX:Ljava/util/regex/Pattern;

    invoke-virtual {v6, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v6

    .local v6, "zone":Ljava/util/regex/Matcher;
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    .local v7, "hasZone":Z
    if-eqz v7, :cond_87

    invoke-virtual {v6}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    .local v2, "suffix":Ljava/lang/String;
    :cond_87
    if-eqz v7, :cond_92

    invoke-virtual {v6}, Ljava/util/regex/Matcher;->start()I

    move-result v9

    invoke-virtual {v5, v8, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    goto :goto_93

    :cond_92
    move-object v9, v5

    .line 20
    .local v9, "body":Ljava/lang/String;
    :goto_93
    const/16 v10, 0x2e

    invoke-virtual {v9, v10}, Ljava/lang/String;->indexOf(I)I

    move-result v10

    .local v10, "dot":I
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v11

    const/16 v12, 0x10

    if-le v11, v12, :cond_a3

    const/4 v11, 0x1

    goto :goto_a4

    :cond_a3
    const/4 v11, 0x0

    .local v11, "pattern":I
    :goto_a4
    const/4 v12, 0x3

    if-ltz v10, :cond_e0

    add-int/lit8 v13, v10, 0x1

    invoke-virtual {v9, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v13

    .local v13, "fraction":Ljava/lang/String;
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    const-string v15, "."

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v3, "000"

    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v8, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v14, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x2

    .line 21
    .end local v13    # "fraction":Ljava/lang/String;
    :cond_e0
    if-eqz v7, :cond_10a

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x5

    if-ne v3, v4, :cond_108

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v8, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_108
    add-int/lit8 v11, v11, 0x3

    :cond_10a
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move v7, v11

    .line 23
    .end local v2    # "suffix":Ljava/lang/String;
    .end local v6    # "zone":Ljava/util/regex/Matcher;
    .end local v9    # "body":Ljava/lang/String;
    .end local v10    # "dot":I
    .end local v11    # "pattern":I
    .local v7, "pattern":I
    :goto_11c
    invoke-static {}, Le/e/a/RowDates194;->formats()Le/e/a/RowDates194$Formats;

    move-result-object v2

    invoke-virtual {v2, v7}, Le/e/a/RowDates194$Formats;->get(I)Ljava/text/SimpleDateFormat;

    move-result-object v2

    .local v2, "format":Ljava/text/SimpleDateFormat;
    sget-object v3, Le/e/a/RowDates194;->ZONE:Ljava/util/TimeZone;

    invoke-virtual {v2, v3}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    new-instance v3, Ljava/text/ParsePosition;

    invoke-direct {v3, v8}, Ljava/text/ParsePosition;-><init>(I)V

    .local v3, "pos":Ljava/text/ParsePosition;
    invoke-virtual {v2, v5, v3}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;Ljava/text/ParsePosition;)Ljava/util/Date;

    move-result-object v4

    .local v4, "parsed":Ljava/util/Date;
    if-eqz v4, :cond_145

    invoke-virtual {v3}, Ljava/text/ParsePosition;->getIndex()I

    move-result v6

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v8

    if-ne v6, v8, :cond_145

    invoke-virtual {v4}, Ljava/util/Date;->getTime()J

    move-result-wide v8

    move-wide/from16 v16, v8

    goto :goto_147

    :cond_145
    const-wide/16 v16, 0x0

    :goto_147
    return-wide v16
.end method
