.class final Le/e/a/ShortImages;
.super Ljava/lang/Object;
.source "ShortImages.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/ShortImages$Job;,
        Le/e/a/ShortImages$Subscription;,
        Le/e/a/ShortImages$Binding;
    }
.end annotation


# static fields
.field private static final MAIN:Landroid/os/Handler;

.field private static final WORKERS:Ljava/util/concurrent/ThreadPoolExecutor;

.field private static final bindings:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/widget/ImageView;",
            "Le/e/a/ShortImages$Binding;",
            ">;"
        }
    .end annotation
.end field

.field private static disk:Le/e/a/ImageDiskCache;

.field private static final jobs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Le/e/a/ShortImages$Job;",
            ">;"
        }
    .end annotation
.end field

.field private static final memory:Landroid/util/LruCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/LruCache<",
            "Ljava/lang/String;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 22
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Le/e/a/ShortImages;->MAIN:Landroid/os/Handler;

    .line 23
    new-instance v2, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v8, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v8}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-wide/16 v5, 0x1e

    invoke-direct/range {v2 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V

    sput-object v2, Le/e/a/ShortImages;->WORKERS:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 24
    sget-object v0, Le/e/a/ShortImages;->WORKERS:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    .line 25
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    .line 26
    new-instance v0, Le/e/a/ShortImages$1;

    const/high16 v1, 0xc00000

    invoke-direct {v0, v1}, Le/e/a/ShortImages$1;-><init>(I)V

    sput-object v0, Le/e/a/ShortImages;->memory:Landroid/util/LruCache;

    .line 30
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    return-void
.end method

.method constructor <init>()V
    .registers 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V
    .registers 2
    .param p0, "x0"    # Le/e/a/ShortImages$Job;
    .param p1, "x1"    # Le/e/a/ShortImages$Subscription;

    .line 21
    invoke-static {p0, p1}, Le/e/a/ShortImages;->remove(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V

    return-void
.end method

.method static synthetic access$100([B)Landroid/graphics/Bitmap;
    .registers 2
    .param p0, "x0"    # [B

    .line 21
    invoke-static {p0}, Le/e/a/ShortImages;->decode([B)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$200()Landroid/util/LruCache;
    .registers 1

    .line 21
    sget-object v0, Le/e/a/ShortImages;->memory:Landroid/util/LruCache;

    return-object v0
.end method

.method static synthetic access$300()Landroid/os/Handler;
    .registers 1

    .line 21
    sget-object v0, Le/e/a/ShortImages;->MAIN:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$400()Ljava/util/Map;
    .registers 1

    .line 21
    sget-object v0, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    return-object v0
.end method

.method static synthetic access$500()Ljava/util/WeakHashMap;
    .registers 1

    .line 21
    sget-object v0, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    return-object v0
.end method

.method static cancel(Landroid/app/Activity;)V
    .registers 7
    .param p0, "activity"    # Landroid/app/Activity;

    .line 69
    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/ShortImages$Job;

    .line 70
    .local v1, "job":Le/e/a/ShortImages$Job;
    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, v1, Le/e/a/ShortImages$Job;->subscribers:Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_26
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/ShortImages$Subscription;

    .line 71
    .local v3, "subscriber":Le/e/a/ShortImages$Subscription;
    iget-object v4, v3, Le/e/a/ShortImages$Subscription;->target:Ljava/lang/ref/WeakReference;

    invoke-virtual {v4}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageView;

    .line 72
    .local v4, "target":Landroid/widget/ImageView;
    if-eqz v4, :cond_46

    invoke-virtual {v4}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Le/e/a/ShortImages;->owner(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v5

    if-ne v5, p0, :cond_49

    :cond_46
    invoke-static {v1, v3}, Le/e/a/ShortImages;->remove(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V

    .line 73
    .end local v3    # "subscriber":Le/e/a/ShortImages$Subscription;
    .end local v4    # "target":Landroid/widget/ImageView;
    :cond_49
    goto :goto_26

    .line 74
    .end local v1    # "job":Le/e/a/ShortImages$Job;
    :cond_4a
    goto :goto_f

    .line 75
    :cond_4b
    return-void
.end method

.method private static decode([B)Landroid/graphics/Bitmap;
    .registers 7
    .param p0, "bytes"    # [B

    .line 150
    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .local v0, "options":Landroid/graphics/BitmapFactory$Options;
    const/4 v1, 0x1

    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 151
    array-length v1, p0

    const/4 v2, 0x0

    invoke-static {p0, v2, v1, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 152
    iget v1, v0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    const/4 v3, 0x0

    if-lez v1, :cond_42

    iget v1, v0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    if-gtz v1, :cond_17

    goto :goto_42

    .line 153
    :cond_17
    const/4 v1, 0x1

    .local v1, "sample":I
    :goto_18
    iget v4, v0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    div-int/2addr v4, v1

    const/16 v5, 0x384

    if-gt v4, v5, :cond_3f

    iget v4, v0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    div-int/2addr v4, v1

    const/16 v5, 0x640

    if-le v4, v5, :cond_27

    goto :goto_3f

    .line 154
    :cond_27
    iput-boolean v2, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    iput v1, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 155
    array-length v4, p0

    invoke-static {p0, v2, v4, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 156
    .local v2, "bitmap":Landroid/graphics/Bitmap;
    if-eqz v2, :cond_3e

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getByteCount()I

    move-result v4

    const/high16 v5, 0x800000

    if-le v4, v5, :cond_3e

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    return-object v3

    .line 157
    :cond_3e
    return-object v2

    .line 153
    .end local v2    # "bitmap":Landroid/graphics/Bitmap;
    :cond_3f
    :goto_3f
    mul-int/lit8 v1, v1, 0x2

    goto :goto_18

    .line 152
    .end local v1    # "sample":I
    :cond_42
    :goto_42
    return-object v3
.end method

.method static load(Ljava/lang/String;Landroid/widget/ImageView;Landroid/widget/TextView;)V
    .registers 13
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "target"    # Landroid/widget/ImageView;
    .param p2, "placeholder"    # Landroid/widget/TextView;

    .line 43
    sget-object v0, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Le/e/a/ShortImages$Binding;

    .line 44
    .local v0, "previous":Le/e/a/ShortImages$Binding;
    const/4 v1, 0x0

    if-eqz p0, :cond_d9

    const-string v2, "https://"

    invoke-virtual {p0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_15

    goto/16 :goto_d9

    .line 50
    :cond_15
    if-eqz v0, :cond_2c

    iget-object v2, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    if-eqz v2, :cond_2c

    iget-object v2, v0, Le/e/a/ShortImages$Binding;->url:Ljava/lang/String;

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2c

    .line 51
    iget-object v2, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    iget-object v2, v2, Le/e/a/ShortImages$Subscription;->job:Le/e/a/ShortImages$Job;

    iget-object v3, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    invoke-static {v2, v3}, Le/e/a/ShortImages;->remove(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V

    .line 52
    :cond_2c
    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    .line 53
    new-instance v2, Le/e/a/ShortImages$Binding;

    invoke-direct {v2, p0, p2}, Le/e/a/ShortImages$Binding;-><init>(Ljava/lang/String;Landroid/widget/TextView;)V

    .line 54
    .local v2, "binding":Le/e/a/ShortImages$Binding;
    if-eqz v0, :cond_42

    iget-object v3, v0, Le/e/a/ShortImages$Binding;->url:Ljava/lang/String;

    invoke-virtual {v3, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_42

    iget-object v3, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    iput-object v3, v2, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    .line 55
    :cond_42
    sget-object v3, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v3, p1, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    sget-object v3, Le/e/a/ShortImages;->memory:Landroid/util/LruCache;

    invoke-virtual {v3, p0}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/Bitmap;

    .line 57
    .local v3, "cached":Landroid/graphics/Bitmap;
    if-eqz v3, :cond_5d

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v4

    if-eqz v4, :cond_5d

    sget-object v4, Le/e/a/ShortImages;->memory:Landroid/util/LruCache;

    invoke-virtual {v4, p0}, Landroid/util/LruCache;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    .line 58
    :cond_5d
    if-eqz v3, :cond_6a

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    if-eqz p2, :cond_69

    const/16 v1, 0x8

    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_69
    return-void

    .line 59
    :cond_6a
    sget-object v4, Le/e/a/ShortImages;->disk:Le/e/a/ImageDiskCache;

    if-nez v4, :cond_81

    new-instance v4, Le/e/a/ImageDiskCache;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v5

    invoke-direct {v4, v5}, Le/e/a/ImageDiskCache;-><init>(Ljava/io/File;)V

    sput-object v4, Le/e/a/ShortImages;->disk:Le/e/a/ImageDiskCache;

    .line 60
    :cond_81
    sget-object v4, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    invoke-interface {v4, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Le/e/a/ShortImages$Job;

    .local v4, "job":Le/e/a/ShortImages$Job;
    if-nez v4, :cond_8c

    const/4 v1, 0x1

    .line 61
    .local v1, "start":Z
    :cond_8c
    if-eqz v1, :cond_9b

    new-instance v5, Le/e/a/ShortImages$Job;

    sget-object v6, Le/e/a/ShortImages;->disk:Le/e/a/ImageDiskCache;

    invoke-direct {v5, p0, v6}, Le/e/a/ShortImages$Job;-><init>(Ljava/lang/String;Le/e/a/ImageDiskCache;)V

    move-object v4, v5

    sget-object v5, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    invoke-interface {v5, p0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    :cond_9b
    iget-object v5, v4, Le/e/a/ShortImages$Job;->subscribers:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_a1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Le/e/a/ShortImages$Subscription;

    .local v6, "existing":Le/e/a/ShortImages$Subscription;
    iget-object v7, v6, Le/e/a/ShortImages$Subscription;->target:Ljava/lang/ref/WeakReference;

    invoke-virtual {v7}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v7

    if-ne v7, p1, :cond_b6

    return-void

    .end local v6    # "existing":Le/e/a/ShortImages$Subscription;
    :cond_b6
    goto :goto_a1

    .line 63
    :cond_b7
    new-instance v5, Le/e/a/ShortImages$Subscription;

    invoke-direct {v5, p1, p2, v4}, Le/e/a/ShortImages$Subscription;-><init>(Landroid/widget/ImageView;Landroid/widget/TextView;Le/e/a/ShortImages$Job;)V

    .line 64
    .local v5, "subscriber":Le/e/a/ShortImages$Subscription;
    iput-object v5, v2, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    .line 65
    iget-object v6, v4, Le/e/a/ShortImages$Job;->subscribers:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1, v5}, Landroid/widget/ImageView;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 66
    if-eqz v1, :cond_d8

    move-object v6, v4

    .local v6, "next":Le/e/a/ShortImages$Job;
    iget-object v7, v6, Le/e/a/ShortImages$Job;->task:Le/e/a/NetworkTask;

    sget-object v8, Le/e/a/ShortImages;->WORKERS:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v9, Le/e/a/ShortImages$0;

    invoke-direct {v9, v6}, Le/e/a/ShortImages$0;-><init>(Le/e/a/ShortImages$Job;)V

    invoke-virtual {v7, v8, v9}, Le/e/a/NetworkTask;->start(Ljava/util/concurrent/ExecutorService;Ljava/lang/Runnable;)V

    .line 67
    .end local v6    # "next":Le/e/a/ShortImages$Job;
    :cond_d8
    return-void

    .line 45
    .end local v1    # "start":Z
    .end local v2    # "binding":Le/e/a/ShortImages$Binding;
    .end local v3    # "cached":Landroid/graphics/Bitmap;
    .end local v4    # "job":Le/e/a/ShortImages$Job;
    .end local v5    # "subscriber":Le/e/a/ShortImages$Subscription;
    :cond_d9
    :goto_d9
    if-eqz v0, :cond_e8

    iget-object v2, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    if-eqz v2, :cond_e8

    iget-object v2, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    iget-object v2, v2, Le/e/a/ShortImages$Subscription;->job:Le/e/a/ShortImages$Job;

    iget-object v3, v0, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    invoke-static {v2, v3}, Le/e/a/ShortImages;->remove(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V

    .line 46
    :cond_e8
    sget-object v2, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v2, p1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 47
    if-eqz p2, :cond_f9

    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 48
    :cond_f9
    return-void
.end method

.method private static owner(Landroid/content/Context;)Landroid/app/Activity;
    .registers 3
    .param p0, "context"    # Landroid/content/Context;

    .line 77
    const/4 v0, 0x0

    .local v0, "depth":I
    :goto_1
    const/16 v1, 0x8

    if-ge v0, v1, :cond_1f

    instance-of v1, p0, Landroid/content/ContextWrapper;

    if-eqz v1, :cond_1f

    .line 78
    instance-of v1, p0, Landroid/app/Activity;

    if-eqz v1, :cond_11

    move-object v1, p0

    check-cast v1, Landroid/app/Activity;

    return-object v1

    .line 79
    :cond_11
    move-object v1, p0

    check-cast v1, Landroid/content/ContextWrapper;

    invoke-virtual {v1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v1

    .local v1, "next":Landroid/content/Context;
    if-ne v1, p0, :cond_1b

    goto :goto_1f

    :cond_1b
    move-object p0, v1

    .line 77
    .end local v1    # "next":Landroid/content/Context;
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 81
    .end local v0    # "depth":I
    :cond_1f
    :goto_1f
    const/4 v0, 0x0

    return-object v0
.end method

.method private static remove(Le/e/a/ShortImages$Job;Le/e/a/ShortImages$Subscription;)V
    .registers 5
    .param p0, "job"    # Le/e/a/ShortImages$Job;
    .param p1, "subscriber"    # Le/e/a/ShortImages$Subscription;

    .line 84
    iget-object v0, p0, Le/e/a/ShortImages$Job;->subscribers:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v0, p1, Le/e/a/ShortImages$Subscription;->target:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    .line 85
    .local v0, "target":Landroid/widget/ImageView;
    if-eqz v0, :cond_23

    .line 86
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 87
    sget-object v1, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v1, v0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/ShortImages$Binding;

    .line 88
    .local v1, "binding":Le/e/a/ShortImages$Binding;
    if-eqz v1, :cond_23

    iget-object v2, v1, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    if-ne v2, p1, :cond_23

    const/4 v2, 0x0

    iput-object v2, v1, Le/e/a/ShortImages$Binding;->subscription:Le/e/a/ShortImages$Subscription;

    .line 90
    .end local v1    # "binding":Le/e/a/ShortImages$Binding;
    :cond_23
    iget-object v1, p0, Le/e/a/ShortImages$Job;->subscribers:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_41

    sget-object v1, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    iget-object v2, p0, Le/e/a/ShortImages$Job;->url:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, p0, :cond_41

    .line 91
    sget-object v1, Le/e/a/ShortImages;->jobs:Ljava/util/Map;

    iget-object v2, p0, Le/e/a/ShortImages$Job;->url:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Le/e/a/ShortImages$Job;->task:Le/e/a/NetworkTask;

    invoke-virtual {v1}, Le/e/a/NetworkTask;->cancel()V

    .line 93
    :cond_41
    return-void
.end method

.method static resume(Landroid/app/Activity;)V
    .registers 8
    .param p0, "activity"    # Landroid/app/Activity;

    .line 37
    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Le/e/a/ShortImages;->bindings:Ljava/util/WeakHashMap;

    invoke-virtual {v1}, Ljava/util/WeakHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_53

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 38
    .local v1, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/widget/ImageView;Le/e/a/ShortImages$Binding;>;"
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    .local v2, "view":Landroid/widget/ImageView;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/ShortImages$Binding;

    .local v3, "binding":Le/e/a/ShortImages$Binding;
    iget-object v4, v3, Le/e/a/ShortImages$Binding;->placeholder:Ljava/lang/ref/WeakReference;

    invoke-virtual {v4}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    .line 39
    .local v4, "placeholder":Landroid/widget/TextView;
    if-eqz v2, :cond_52

    invoke-virtual {v2}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Le/e/a/ShortImages;->owner(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v5

    if-ne v5, p0, :cond_52

    invoke-virtual {v2}, Landroid/widget/ImageView;->isAttachedToWindow()Z

    move-result v5

    if-eqz v5, :cond_52

    iget-object v5, v3, Le/e/a/ShortImages$Binding;->url:Ljava/lang/String;

    invoke-virtual {v2}, Landroid/widget/ImageView;->getTag()Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_52

    iget-object v5, v3, Le/e/a/ShortImages$Binding;->url:Ljava/lang/String;

    invoke-static {v5, v2, v4}, Le/e/a/ShortImages;->load(Ljava/lang/String;Landroid/widget/ImageView;Landroid/widget/TextView;)V

    .line 40
    .end local v1    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Landroid/widget/ImageView;Le/e/a/ShortImages$Binding;>;"
    .end local v2    # "view":Landroid/widget/ImageView;
    .end local v3    # "binding":Le/e/a/ShortImages$Binding;
    .end local v4    # "placeholder":Landroid/widget/TextView;
    :cond_52
    goto :goto_f

    .line 41
    :cond_53
    return-void
.end method
