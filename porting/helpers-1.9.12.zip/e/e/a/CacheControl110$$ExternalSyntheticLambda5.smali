.class public final synthetic Le/e/a/CacheControl110$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/preference/PreferenceActivity;


# direct methods
.method public synthetic constructor <init>(Landroid/preference/PreferenceActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/CacheControl110$$ExternalSyntheticLambda5;->f$0:Landroid/preference/PreferenceActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    .line 0
    iget-object v0, p0, Le/e/a/CacheControl110$$ExternalSyntheticLambda5;->f$0:Landroid/preference/PreferenceActivity;

    invoke-static {v0, p1, p2}, Le/e/a/CacheControl110;->lambda$5(Landroid/preference/PreferenceActivity;Landroid/content/DialogInterface;I)V

    return-void
.end method
