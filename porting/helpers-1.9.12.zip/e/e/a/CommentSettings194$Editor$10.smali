.class Le/e/a/CommentSettings194$Editor$10;
.super Ljava/lang/Object;
.source "CommentSettings194.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le/e/a/CommentSettings194$Editor;-><init>(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Le/e/a/CommentSettings194$Editor;


# direct methods
.method constructor <init>(Le/e/a/CommentSettings194$Editor;)V
    .registers 2

    .line 201
    iput-object p1, p0, Le/e/a/CommentSettings194$Editor$10;->this$1:Le/e/a/CommentSettings194$Editor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 204
    iget-object v0, p0, Le/e/a/CommentSettings194$Editor$10;->this$1:Le/e/a/CommentSettings194$Editor;

    invoke-virtual {v0}, Le/e/a/CommentSettings194$Editor;->m35lambda$10$eeaCommentSettings194$Editor()V

    .line 205
    return-void
.end method
