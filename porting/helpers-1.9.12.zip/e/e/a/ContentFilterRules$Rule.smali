.class public final Le/e/a/ContentFilterRules$Rule;
.super Ljava/lang/Object;
.source "ContentFilterRules.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/ContentFilterRules;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Rule"
.end annotation


# instance fields
.field final enabled:Z

.field final mode:Ljava/lang/String;

.field final pattern:Ljava/util/regex/Pattern;

.field final value:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 6
    .param p1, "value"    # Ljava/lang/String;
    .param p2, "mode"    # Ljava/lang/String;
    .param p3, "enabled"    # Z

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Le/e/a/ContentFilterRules$Rule;->mode:Ljava/lang/String;

    iput-boolean p3, p0, Le/e/a/ContentFilterRules$Rule;->enabled:Z

    const-string v0, "regex"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_11

    move-object v1, p1

    goto :goto_15

    :cond_11
    # invokes: Le/e/a/ContentFilterRules;->normalized(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {p1}, Le/e/a/ContentFilterRules;->access$000(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_15
    iput-object v1, p0, Le/e/a/ContentFilterRules$Rule;->value:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-static {p1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    goto :goto_23

    :cond_22
    const/4 v0, 0x0

    :goto_23
    iput-object v0, p0, Le/e/a/ContentFilterRules$Rule;->pattern:Ljava/util/regex/Pattern;

    return-void
.end method


# virtual methods
.method public matches(Ljava/lang/String;)Z
    .registers 5
    .param p1, "text"    # Ljava/lang/String;

    .line 9
    iget-boolean v0, p0, Le/e/a/ContentFilterRules$Rule;->enabled:Z

    if-eqz v0, :cond_30

    if-nez p1, :cond_7

    goto :goto_30

    :cond_7
    iget-object v0, p0, Le/e/a/ContentFilterRules$Rule;->pattern:Ljava/util/regex/Pattern;

    if-eqz v0, :cond_16

    iget-object v0, p0, Le/e/a/ContentFilterRules$Rule;->pattern:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    return v0

    :cond_16
    # invokes: Le/e/a/ContentFilterRules;->normalized(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {p1}, Le/e/a/ContentFilterRules;->access$000(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .local v0, "s":Ljava/lang/String;
    iget-object v1, p0, Le/e/a/ContentFilterRules$Rule;->mode:Ljava/lang/String;

    const-string v2, "exact"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v2, p0, Le/e/a/ContentFilterRules$Rule;->value:Ljava/lang/String;

    if-eqz v1, :cond_2b

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    goto :goto_2f

    :cond_2b
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    :goto_2f
    return v1

    .end local v0    # "s":Ljava/lang/String;
    :cond_30
    :goto_30
    const/4 v0, 0x0

    return v0
.end method
