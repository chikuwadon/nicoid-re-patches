.class final Le/e/a/FilterUi110;
.super Ljava/lang/Object;
.source "FilterUi110.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/FilterUi110$Page;
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static category(Landroid/content/Context;I)Ljava/lang/String;
    .registers 4

    .line 6
    if-nez p1, :cond_5

    const-string v0, "\u52d5\u753b\u30bf\u30a4\u30c8\u30eb"

    goto :goto_7

    :cond_5
    const-string v0, "\u6295\u7a3f\u8005\u30fb\u30c1\u30e3\u30f3\u30cd\u30eb\u540d"

    :goto_7
    if-nez p1, :cond_c

    const-string v1, "Video titles"

    goto :goto_e

    :cond_c
    const-string v1, "Uploaders / channels"

    :goto_e
    if-nez p1, :cond_13

    const-string p1, "\u5f71\u7247\u6a19\u984c"

    goto :goto_15

    :cond_13
    const-string p1, "\u6295\u7a3f\u8005\uff0f\u983b\u9053\u540d\u7a31"

    :goto_15
    invoke-static {p0, v0, v1, p1}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static date(J)Ljava/lang/String;
    .registers 5

    .line 8
    const-wide/16 v0, 0x0

    cmp-long v2, p0, v0

    if-gtz v2, :cond_9

    const-string p0, "\u2014"

    goto :goto_1d

    :cond_9
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy/MM/dd HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1, p0, p1}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    :goto_1d
    return-object p0
.end method

.method static edit(Landroid/app/Activity;Lorg/json/JSONArray;Lorg/json/JSONObject;ILjava/lang/Runnable;)V
    .registers 25

    .line 26
    invoke-static/range {p0 .. p0}, Le/e/a/PlaybackSession;->dialogContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v6

    if-nez p2, :cond_d

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object v7, v0

    goto :goto_f

    :cond_d
    move-object/from16 v7, p2

    :goto_f
    invoke-static {v6}, Le/e/a/PanelUi;->column(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-static {v0}, Le/e/a/UiDialogs;->insetContent(Landroid/view/View;)V

    new-instance v8, Landroid/widget/CheckBox;

    invoke-direct {v8, v6}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    const-string v1, "Enabled"

    const-string v2, "\u555f\u7528"

    const-string v3, "\u6709\u52b9"

    invoke-static {v6, v3, v1, v2}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    const-string v1, "enabled"

    const/4 v2, 0x1

    invoke-virtual {v7, v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-virtual {v8, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    invoke-static {v8}, Le/e/a/PanelUi;->tint(Landroid/widget/CompoundButton;)V

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "Target"

    const-string v3, "\u5c0d\u8c61\u7a2e\u985e"

    const-string v4, "\u5bfe\u8c61\u306e\u7a2e\u985e"

    invoke-static {v6, v4, v1, v3}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xd

    invoke-static {v6, v1, v3}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "category"

    move/from16 v4, p3

    invoke-virtual {v7, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    filled-new-array {v1}, [I

    move-result-object v4

    invoke-static {v6}, Le/e/a/PanelUi;->column(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v5, "User ID (optional, AND condition)"

    const-string v9, "\u4f7f\u7528\u8005 ID\uff08\u9078\u586b\uff0cAND \u689d\u4ef6\uff09"

    const-string v10, "\u30e6\u30fc\u30b6\u30fcID\uff08\u4efb\u610f\u30fbAND\u6761\u4ef6\uff09"

    invoke-static {v6, v10, v5, v9}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v6, v5, v3}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/EditText;

    invoke-direct {v5, v6}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const-string v9, "nicoid-managed-input"

    invoke-virtual {v5, v9}, Landroid/widget/EditText;->setTag(Ljava/lang/Object;)V

    const/4 v10, 0x2

    invoke-virtual {v5, v10}, Landroid/widget/EditText;->setInputType(I)V

    invoke-virtual {v5, v2}, Landroid/widget/EditText;->setSingleLine(Z)V

    const-string v11, "userId"

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const-string v11, "Numeric user ID"

    const-string v12, "\u6578\u5b57\u4f7f\u7528\u8005 ID"

    const-string v13, "\u30e6\u30fc\u30b6\u30fcID"

    invoke-static {v6, v13, v11, v12}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x30

    invoke-static {v6, v12}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v13

    const/4 v14, -0x1

    invoke-direct {v11, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v5, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v11, "Name and ID must both match. You may specify only an ID."

    const-string v13, "\u540d\u7a31\u8207 ID \u5fc5\u9808\u540c\u6642\u7b26\u5408\uff0c\u4e5f\u53ef\u53ea\u6307\u5b9a ID\u3002"

    const-string v15, "\u540d\u524d\u3068ID\u3092\u6307\u5b9a\u3059\u308b\u3068\u4e21\u65b9\u306e\u4e00\u81f4\u3067NG\u3002ID\u306e\u307f\u306e\u6307\u5b9a\u3082\u53ef\u80fd\u3067\u3059\u3002"

    invoke-static {v6, v15, v11, v13}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0xb

    invoke-static {v6, v11, v13}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v11

    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-array v15, v10, [Landroid/widget/Button;

    new-instance v2, Le/e/a/FilterUi110$$ExternalSyntheticLambda4;

    invoke-direct {v2, v1, v4, v15, v6}, Le/e/a/FilterUi110$$ExternalSyntheticLambda4;-><init>(Landroid/widget/LinearLayout;[I[Landroid/widget/Button;Landroid/content/Context;)V

    const/4 v13, 0x0

    const/4 v12, 0x0

    :goto_c3
    const/4 v14, 0x4

    if-lt v12, v10, :cond_368

    invoke-virtual {v0, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v11, "Match method"

    const-string v12, "\u6bd4\u5c0d\u65b9\u5f0f"

    const-string v15, "\u30de\u30c3\u30c1\u65b9\u6cd5"

    invoke-static {v6, v15, v11, v12}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v6, v11, v3}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v11

    const/16 v12, 0xa

    invoke-static {v6, v12}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v6, v14}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v11, v13, v15, v13, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v0, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v11, Landroid/widget/RadioGroup;

    invoke-direct {v11, v6}, Landroid/widget/RadioGroup;-><init>(Landroid/content/Context;)V

    const-string v12, "exact"

    const-string v15, "regex"

    const-string v14, "partial"

    filled-new-array {v14, v12, v15}, [Ljava/lang/String;

    move-result-object v18

    const-string v12, "Matches text containing the keyword."

    const-string v15, "\u6bd4\u5c0d\u5305\u542b\u95dc\u9375\u5b57\u7684\u6587\u5b57\u3002"

    const-string v10, "\u5165\u529b\u3057\u305f\u30ad\u30fc\u30ef\u30fc\u30c9\u3092\u542b\u3080\u5834\u5408\u306b\u4e00\u81f4\u3057\u307e\u3059\u3002"

    invoke-static {v6, v10, v12, v15}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v12, "Matches the exact keyword."

    const-string v15, "\u5b8c\u5168\u6bd4\u5c0d\u95dc\u9375\u5b57\u3002"

    const-string v13, "\u5165\u529b\u3057\u305f\u30ad\u30fc\u30ef\u30fc\u30c9\u3068\u5b8c\u5168\u306b\u4e00\u81f4\u3059\u308b\u5834\u5408\u306b\u4e00\u81f4\u3057\u307e\u3059\u3002"

    invoke-static {v6, v13, v12, v15}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "Matches a regular expression."

    const-string v15, "\u4f7f\u7528\u6b63\u898f\u8868\u793a\u5f0f\u6bd4\u5c0d\u3002"

    const-string v3, "\u6b63\u898f\u8868\u73fe\u3067\u4e00\u81f4\u3059\u308b\u5834\u5408\u306b\u4e00\u81f4\u3057\u307e\u3059\u3002"

    invoke-static {v6, v3, v13, v15}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    filled-new-array {v10, v12, v3}, [Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    :goto_119
    const/4 v12, 0x3

    const-string v13, "\n"

    if-lt v10, v12, :cond_2c7

    invoke-virtual {v0, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v3, "Blocked keyword"

    const-string v10, "\u5c01\u9396\u95dc\u9375\u5b57"

    const-string v12, "NG\u30ef\u30fc\u30c9"

    invoke-static {v6, v12, v3, v10}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v12, 0xd

    invoke-static {v6, v3, v12}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v3

    const/16 v10, 0xc

    invoke-static {v6, v10}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, 0x6

    invoke-static {v6, v14}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v3, v15, v12, v15, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v12, 0x10

    invoke-virtual {v3, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v12, Landroid/widget/EditText;

    invoke-direct {v12, v6}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-virtual {v12, v9}, Landroid/widget/EditText;->setTag(Ljava/lang/Object;)V

    const-string v9, "value"

    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v12, v9}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x0

    invoke-virtual {v12, v9}, Landroid/widget/EditText;->setSingleLine(Z)V

    const/4 v15, 0x2

    invoke-virtual {v12, v15}, Landroid/widget/EditText;->setMaxLines(I)V

    const v14, 0x800013

    invoke-virtual {v12, v14}, Landroid/widget/EditText;->setGravity(I)V

    invoke-virtual {v12, v9}, Landroid/widget/EditText;->setIncludeFontPadding(Z)V

    invoke-static {v6, v10}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v15

    const/4 v14, 0x4

    invoke-static {v6, v14}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v12, v15, v9, v14, v9}, Landroid/widget/EditText;->setPadding(IIII)V

    const/high16 v14, 0x41700000    # 15.0f

    invoke-virtual {v12, v14}, Landroid/widget/EditText;->setTextSize(F)V

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v14, v9, v10, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v12, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v9, "\u00d7"

    invoke-static {v6, v9}, Le/e/a/PanelUi;->button(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v9

    invoke-static {v9}, Le/e/a/Ui110;->flat(Landroid/widget/Button;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x30

    invoke-static {v6, v14}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v6, v14}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v10, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v9, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v10, "Clear input"

    const-string v14, "\u6e05\u9664\u8f38\u5165"

    const-string v15, "\u5165\u529b\u3092\u6d88\u53bb"

    invoke-static {v6, v15, v10, v14}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v10, Le/e/a/FilterUi110$$ExternalSyntheticLambda6;

    invoke-direct {v10, v12}, Le/e/a/FilterUi110$$ExternalSyntheticLambda6;-><init>(Landroid/widget/EditText;)V

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0x34

    invoke-static {v6, v10}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v12}, Landroid/widget/EditText;->getTextSize()F

    move-result v14

    const/high16 v15, 0x40000000    # 2.0f

    mul-float v14, v14, v15

    const/16 v15, 0x8

    move-object/from16 v16, v8

    invoke-static {v6, v15}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v8

    int-to-float v8, v8

    add-float/2addr v14, v8

    float-to-int v8, v14

    invoke-static {v10, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    const/4 v10, -0x1

    invoke-direct {v9, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v8, "Registered"

    const-string v9, "\u767b\u9304\u6642\u9593"

    const-string v10, "\u767b\u9332\u65e5\u6642"

    invoke-static {v6, v10, v8, v9}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-nez p2, :cond_202

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    goto :goto_204

    :cond_202
    const-wide/16 v8, 0x0

    :goto_204
    const-string v10, "date"

    invoke-virtual {v7, v10, v8, v9}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v8

    invoke-static {v8, v9}, Le/e/a/FilterUi110;->date(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v8, 0xb

    invoke-static {v6, v1, v8}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v1

    const v8, 0x3f333333    # 0.7f

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setAlpha(F)V

    const/16 v8, 0xc

    invoke-static {v6, v8}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v8

    const/4 v9, 0x0

    invoke-virtual {v1, v9, v8, v9, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v1, Landroid/widget/ScrollView;

    invoke-direct {v1, v6}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    invoke-static {v6}, Le/e/a/UiDialogs;->builder(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    if-nez p2, :cond_240

    const-string v8, "NG\u767b\u9332"

    goto :goto_242

    :cond_240
    const-string v8, "NG\u7de8\u96c6"

    :goto_242
    if-nez p2, :cond_247

    const-string v9, "Add NG rule"

    goto :goto_249

    :cond_247
    const-string v9, "Edit NG rule"

    :goto_249
    if-nez p2, :cond_24e

    const-string v10, "\u65b0\u589e NG \u898f\u5247"

    goto :goto_250

    :cond_24e
    const-string v10, "\u7de8\u8f2f NG \u898f\u5247"

    :goto_250
    invoke-static {v6, v8, v9, v10}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "OK"

    const/4 v8, 0x0

    invoke-virtual {v0, v1, v8}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u30ad\u30e3\u30f3\u30bb\u30eb"

    invoke-static {v1}, Le/e/a/UiStrings;->translate(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v13

    invoke-static {v13}, Le/e/a/PlaybackSession;->showForm(Landroid/app/AlertDialog;)V

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    invoke-virtual {v12, v8}, Landroid/widget/EditText;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/4 v0, 0x0

    invoke-virtual {v12, v0}, Landroid/widget/EditText;->setBackgroundColor(I)V

    const v1, 0x800013

    invoke-virtual {v12, v1}, Landroid/widget/EditText;->setGravity(I)V

    invoke-static {v6}, Le/e/a/UiDialogs;->surface(Landroid/content/Context;)I

    move-result v1

    invoke-static {v6, v1, v15}, Le/e/a/PanelUi;->round(Landroid/content/Context;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v6, v2}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v8

    invoke-static {v6}, Le/e/a/ThemeChoice;->isNight(Landroid/content/Context;)Z

    move-result v9

    invoke-static {v9}, Le/e/a/DialogColors;->muted(Z)I

    move-result v9

    invoke-virtual {v1, v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v3, v0, v0, v0, v0}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/4 v8, -0x1

    invoke-virtual {v13, v8}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v0

    invoke-static {v0, v2}, Le/e/a/UiDialogs;->actionButton(Landroid/widget/Button;Z)V

    invoke-virtual {v13, v8}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v14

    new-instance v15, Le/e/a/FilterUi110$$ExternalSyntheticLambda7;

    move-object v0, v15

    move-object v1, v12

    move-object/from16 v2, v18

    move-object v3, v11

    move-object/from16 v8, v16

    move-object/from16 v9, p2

    move-object/from16 v10, p1

    move-object/from16 v11, p0

    move-object v12, v13

    move-object/from16 v13, p4

    invoke-direct/range {v0 .. v13}, Le/e/a/FilterUi110$$ExternalSyntheticLambda7;-><init>(Landroid/widget/EditText;[Ljava/lang/String;Landroid/widget/RadioGroup;[ILandroid/widget/EditText;Landroid/content/Context;Lorg/json/JSONObject;Landroid/widget/CheckBox;Lorg/json/JSONObject;Lorg/json/JSONArray;Landroid/app/Activity;Landroid/app/AlertDialog;Ljava/lang/Runnable;)V

    invoke-virtual {v14, v15}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    :cond_2c7
    move-object/from16 v16, v8

    const/4 v8, -0x1

    const/16 v12, 0xd

    const/4 v15, 0x2

    const/16 v17, 0x30

    new-instance v8, Landroid/widget/RadioButton;

    invoke-direct {v8, v6}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    add-int/lit8 v12, v10, 0x64

    invoke-virtual {v8, v12}, Landroid/widget/RadioButton;->setId(I)V

    new-instance v12, Landroid/text/SpannableString;

    new-instance v15, Ljava/lang/StringBuilder;

    move-object/from16 v19, v0

    aget-object v0, v18, v10

    invoke-static {v6, v0}, Le/e/a/FilterUi110;->mode(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v15, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    aget-object v13, v3, v10

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v12, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    invoke-virtual {v12}, Landroid/text/SpannableString;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v13, 0xa

    invoke-virtual {v0, v13}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    new-instance v15, Landroid/text/style/AbsoluteSizeSpan;

    move-object/from16 p3, v1

    const/4 v1, 0x1

    const/16 v13, 0xb

    invoke-direct {v15, v13, v1}, Landroid/text/style/AbsoluteSizeSpan;-><init>(IZ)V

    add-int/2addr v0, v1

    invoke-virtual {v12}, Landroid/text/SpannableString;->length()I

    move-result v1

    const/16 v13, 0x21

    invoke-virtual {v12, v15, v0, v1, v13}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    new-instance v1, Landroid/text/style/ForegroundColorSpan;

    invoke-static {v6}, Le/e/a/ThemeChoice;->isNight(Landroid/content/Context;)Z

    move-result v15

    invoke-static {v15}, Le/e/a/DialogColors;->muted(Z)I

    move-result v15

    invoke-direct {v1, v15}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v12}, Landroid/text/SpannableString;->length()I

    move-result v15

    invoke-virtual {v12, v1, v0, v15, v13}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    invoke-virtual {v8, v12}, Landroid/widget/RadioButton;->setText(Ljava/lang/CharSequence;)V

    const/high16 v0, 0x41600000    # 14.0f

    invoke-virtual {v8, v0}, Landroid/widget/RadioButton;->setTextSize(F)V

    const/4 v0, 0x5

    invoke-static {v6, v0}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v6, v0}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v0

    const/4 v12, 0x0

    invoke-virtual {v8, v12, v1, v12, v0}, Landroid/widget/RadioButton;->setPadding(IIII)V

    invoke-static {v8}, Le/e/a/PanelUi;->tint(Landroid/widget/CompoundButton;)V

    invoke-virtual {v11, v8}, Landroid/widget/RadioGroup;->addView(Landroid/view/View;)V

    aget-object v0, v18, v10

    const-string v1, "mode"

    invoke-virtual {v7, v1, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_35d

    const/4 v0, 0x1

    invoke-virtual {v8, v0}, Landroid/widget/RadioButton;->setChecked(Z)V

    goto :goto_35e

    :cond_35d
    const/4 v0, 0x1

    :goto_35e
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v1, p3

    move-object/from16 v8, v16

    move-object/from16 v0, v19

    goto/16 :goto_119

    :cond_368
    move-object/from16 v19, v0

    move-object/from16 p3, v1

    move-object/from16 v16, v8

    const/4 v0, 0x1

    const/16 v13, 0xd

    const/16 v17, 0x30

    invoke-static {v6, v12}, Le/e/a/FilterUi110;->category(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v6, v1}, Le/e/a/PanelUi;->button(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    aput-object v1, v15, v12

    aget-object v1, v15, v12

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setTextSize(F)V

    aget-object v1, v15, v12

    const/16 v3, 0x11

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setGravity(I)V

    aget-object v1, v15, v12

    const/4 v3, 0x4

    invoke-static {v6, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v8

    invoke-static {v6, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v3

    const/4 v14, 0x0

    invoke-virtual {v1, v8, v14, v3, v14}, Landroid/widget/Button;->setPadding(IIII)V

    aget-object v1, v15, v12

    invoke-virtual {v1, v14}, Landroid/widget/Button;->setIncludeFontPadding(Z)V

    aget-object v1, v15, v12

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x2c

    invoke-static {v6, v8}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v8

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-direct {v3, v14, v8, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v0, v15, v12

    new-instance v1, Le/e/a/FilterUi110$$ExternalSyntheticLambda5;

    invoke-direct {v1, v4, v12, v2}, Le/e/a/FilterUi110$$ExternalSyntheticLambda5;-><init>([IILjava/lang/Runnable;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v1, p3

    move-object/from16 v8, v16

    move-object/from16 v0, v19

    const/16 v3, 0xd

    const/4 v13, 0x0

    const/4 v14, -0x1

    goto/16 :goto_c3
.end method

.method static synthetic lambda$0(Landroid/widget/LinearLayout;[I[Landroid/widget/Button;Landroid/content/Context;)V
    .registers 10

    .line 26
    const/4 v0, 0x0

    aget v1, p1, v0

    const/16 v2, 0x8

    const/4 v3, 0x1

    if-ne v1, v3, :cond_a

    const/4 v1, 0x0

    goto :goto_c

    :cond_a
    const/16 v1, 0x8

    :goto_c
    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const/4 p0, 0x0

    :goto_10
    const/4 v1, 0x2

    if-lt p0, v1, :cond_14

    return-void

    :cond_14
    aget-object v1, p2, p0

    invoke-static {v1}, Le/e/a/Ui110;->flat(Landroid/widget/Button;)V

    aget-object v1, p2, p0

    aget v4, p1, v0

    if-ne p0, v4, :cond_24

    invoke-static {p3}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v4

    goto :goto_28

    :cond_24
    invoke-static {p3}, Le/e/a/PanelUi;->ink(Landroid/content/Context;)I

    move-result v4

    :goto_28
    invoke-virtual {v1, v4}, Landroid/widget/Button;->setTextColor(I)V

    aget v1, p1, v0

    if-ne p0, v1, :cond_3b

    invoke-static {p3}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v1

    const v4, 0xffffff

    and-int/2addr v1, v4

    const/high16 v4, 0x22000000

    or-int/2addr v1, v4

    goto :goto_3f

    :cond_3b
    invoke-static {p3}, Le/e/a/UiDialogs;->surface(Landroid/content/Context;)I

    move-result v1

    :goto_3f
    invoke-static {p3, v1, v2}, Le/e/a/PanelUi;->round(Landroid/content/Context;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-static {p3, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v4

    aget v5, p1, v0

    if-ne p0, v5, :cond_50

    invoke-static {p3}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v5

    goto :goto_58

    :cond_50
    invoke-static {p3}, Le/e/a/ThemeChoice;->isNight(Landroid/content/Context;)Z

    move-result v5

    invoke-static {v5}, Le/e/a/DialogColors;->muted(Z)I

    move-result v5

    :goto_58
    invoke-virtual {v1, v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    aget-object v4, p2, p0

    invoke-virtual {v4, v1}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    add-int/lit8 p0, p0, 0x1

    goto :goto_10
.end method

.method static synthetic lambda$1([IILjava/lang/Runnable;Landroid/view/View;)V
    .registers 4

    .line 26
    const/4 p3, 0x0

    aput p1, p0, p3

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method static synthetic lambda$2(Landroid/widget/EditText;Landroid/view/View;)V
    .registers 2

    .line 26
    const-string p1, ""

    invoke-virtual {p0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method static synthetic lambda$3(Landroid/widget/EditText;[Ljava/lang/String;Landroid/widget/RadioGroup;[ILandroid/widget/EditText;Landroid/content/Context;Lorg/json/JSONObject;Landroid/widget/CheckBox;Lorg/json/JSONObject;Lorg/json/JSONArray;Landroid/app/Activity;Landroid/app/AlertDialog;Ljava/lang/Runnable;Landroid/view/View;)V
    .registers 16

    .line 26
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p13

    invoke-virtual {p13}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p13

    invoke-virtual {p2}, Landroid/widget/RadioGroup;->getCheckedRadioButtonId()I

    move-result p2

    add-int/lit8 p2, p2, -0x64

    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    aget-object p1, p1, p2

    aget p2, p3, v0

    const/4 v1, 0x1

    if-ne p2, v1, :cond_27

    invoke-virtual {p4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    goto :goto_29

    :cond_27
    const-string p2, ""

    :goto_29
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_45

    const-string v1, "[0-9]+"

    invoke-virtual {p2, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_45

    const-string p0, "Enter a numeric user ID"

    const-string p1, "\u8acb\u8f38\u5165\u6578\u5b57\u4f7f\u7528\u8005 ID"

    const-string p2, "\u30e6\u30fc\u30b6\u30fcID\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044"

    invoke-static {p5, p2, p0, p1}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p4, p0}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_45
    invoke-virtual {p13}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result p4

    if-eqz p4, :cond_63

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p4

    if-eqz p4, :cond_63

    const-string p1, "Enter a value"

    const-string p2, "\u8acb\u8f38\u5165\u6587\u5b57"

    const-string p3, "\u6587\u5b57\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044"

    invoke-static {p5, p3, p1, p2}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_63
    :try_start_63
    const-string p4, "regex"

    invoke-virtual {p1, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p4

    if-eqz p4, :cond_6e

    invoke-static {p13}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    :cond_6e
    const-string p4, "userId"

    invoke-virtual {p6, p4, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p2

    const-string p4, "value"

    invoke-virtual {p2, p4, p13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p2

    const-string p4, "mode"

    invoke-virtual {p2, p4, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    const-string p2, "category"

    aget p3, p3, v0

    invoke-virtual {p1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object p1

    const-string p2, "enabled"

    invoke-virtual {p7}, Landroid/widget/CheckBox;->isChecked()Z

    move-result p3

    invoke-virtual {p1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    if-nez p8, :cond_9f

    const-string p1, "date"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p2

    invoke-virtual {p6, p1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    invoke-virtual {p9, p6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :cond_9f
    invoke-static {p10, p9}, Le/e/a/ContentFilter;->save(Landroid/content/Context;Lorg/json/JSONArray;)V

    invoke-virtual {p11}, Landroid/app/AlertDialog;->dismiss()V

    invoke-interface {p12}, Ljava/lang/Runnable;->run()V
    :try_end_a8
    .catch Ljava/util/regex/PatternSyntaxException; {:try_start_63 .. :try_end_a8} :catch_ab
    .catch Lorg/json/JSONException; {:try_start_63 .. :try_end_a8} :catch_a9

    goto :goto_b9

    :catch_a9
    move-exception p0

    goto :goto_b9

    :catch_ab
    move-exception p1

    const-string p1, "Invalid regular expression"

    const-string p2, "\u6b63\u898f\u8868\u793a\u5f0f\u7121\u6548"

    const-string p3, "\u6b63\u898f\u8868\u73fe\u304c\u4e0d\u6b63\u3067\u3059"

    invoke-static {p5, p3, p1, p2}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    :goto_b9
    return-void
.end method

.method static mode(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 7
    const-string v0, "regex"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "exact"

    if-eqz v1, :cond_d

    const-string v1, "\u6b63\u898f\u8868\u73fe"

    goto :goto_18

    :cond_d
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    const-string v1, "\u5b8c\u5168\u4e00\u81f4"

    goto :goto_18

    :cond_16
    const-string v1, "\u90e8\u5206\u4e00\u81f4"

    :goto_18
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_21

    const-string v3, "Regular expression"

    goto :goto_2c

    :cond_21
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2a

    const-string v3, "Exact match"

    goto :goto_2c

    :cond_2a
    const-string v3, "Partial match"

    :goto_2c
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_35

    const-string p1, "\u6b63\u898f\u8868\u793a\u5f0f"

    goto :goto_40

    :cond_35
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3e

    const-string p1, "\u5b8c\u5168\u76f8\u7b26"

    goto :goto_40

    :cond_3e
    const-string p1, "\u90e8\u5206\u76f8\u7b26"

    :goto_40
    invoke-static {p0, v1, v3, p1}, Le/e/a/FilterUi110;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static show(Landroid/preference/PreferenceActivity;)V
    .registers 2

    .line 9
    new-instance v0, Le/e/a/FilterUi110$Page;

    invoke-direct {v0, p0}, Le/e/a/FilterUi110$Page;-><init>(Landroid/preference/PreferenceActivity;)V

    invoke-virtual {v0}, Le/e/a/FilterUi110$Page;->show()V

    return-void
.end method

.method static tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 5
    invoke-static {p0, p1, p2, p3}, Le/e/a/PanelUi;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
