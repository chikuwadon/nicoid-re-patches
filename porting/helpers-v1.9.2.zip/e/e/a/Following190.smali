.class public final Le/e/a/Following190;
.super Ljava/lang/Object;
.source "Following190.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/Following190$Gestures;,
        Le/e/a/Following190$Pager;,
        Le/e/a/Following190$UserRows;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static attach(Landroid/app/Activity;)V
    .registers 22

    .line 12
    move-object/from16 v0, p0

    :try_start_2
    const-string v1, "A"

    invoke-static {v0, v1}, Le/e/a/Review181;->field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    .line 13
    const-string v2, "C"

    invoke-static {v0, v2}, Le/e/a/Review181;->field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/ListAdapter;

    .line 14
    invoke-virtual {v1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v3

    .line 15
    instance-of v4, v3, Landroid/widget/HeaderViewListAdapter;

    if-eqz v4, :cond_20

    check-cast v3, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {v3}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v3

    .line 16
    :cond_20
    instance-of v4, v3, Le/e/a/Following190$UserRows;

    if-eqz v4, :cond_2a

    check-cast v3, Le/e/a/Following190$UserRows;

    iget-object v3, v3, Le/e/a/Following190$UserRows;->original:Landroid/widget/ListAdapter;

    if-eq v3, v2, :cond_32

    :cond_2a
    new-instance v3, Le/e/a/Following190$UserRows;

    invoke-direct {v3, v2}, Le/e/a/Following190$UserRows;-><init>(Landroid/widget/ListAdapter;)V

    invoke-virtual {v1, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 17
    :cond_32
    invoke-virtual {v1}, Landroid/widget/ListView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    if-eqz v2, :cond_19b

    instance-of v3, v2, Le/e/a/Following190$Pager;

    if-eqz v3, :cond_40

    goto/16 :goto_19b

    .line 18
    :cond_40
    invoke-static/range {p0 .. p0}, Le/e/a/VideoDetails;->initializeCookies(Landroid/content/Context;)V

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v3

    invoke-virtual {v1}, Landroid/widget/ListView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 19
    invoke-static/range {p0 .. p0}, Le/e/a/PanelUi;->column(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v5

    const-string v6, "nicoid_following_tabs"

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setTag(Ljava/lang/Object;)V

    invoke-static {v5}, Le/e/a/ThemeChoice;->background(Landroid/view/View;)V

    const/4 v9, -0x1

    iput v9, v4, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v2, v5, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 20
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v2, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 21
    new-instance v12, Le/e/a/Following190$Pager;

    invoke-direct {v12, v0}, Le/e/a/Following190$Pager;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x3f800000    # 1.0f

    const/4 v14, 0x0

    invoke-direct {v2, v9, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v12, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v9, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v1, v2}, Le/e/a/Following190$Pager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 22
    const/4 v15, 0x3

    new-array v8, v15, [Landroid/widget/LinearLayout;

    .line 23
    const/4 v7, 0x1

    const/4 v2, 0x1

    :goto_8b
    if-lt v2, v15, :cond_172

    .line 24
    new-array v6, v15, [Landroid/widget/TextView;

    new-array v5, v15, [Landroid/view/View;

    new-array v4, v7, [Le/e/a/NetworkTask;

    .line 25
    new-instance v3, Le/e/a/Following190$$ExternalSyntheticLambda0;

    invoke-direct {v3, v0}, Le/e/a/Following190$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v1, v3}, Landroid/widget/ListView;->post(Ljava/lang/Runnable;)Z

    .line 26
    new-instance v2, Le/e/a/Following190$$ExternalSyntheticLambda1;

    move-object v1, v2

    move-object v9, v2

    move-object v2, v12

    move-object/from16 v16, v4

    move-object v4, v5

    move-object/from16 v17, v5

    move-object/from16 v5, p0

    move-object/from16 v18, v6

    const/16 v19, 0x1

    move-object/from16 v7, v16

    move-object/from16 v20, v8

    invoke-direct/range {v1 .. v8}, Le/e/a/Following190$$ExternalSyntheticLambda1;-><init>(Le/e/a/Following190$Pager;Ljava/lang/Runnable;[Landroid/view/View;Landroid/app/Activity;[Landroid/widget/TextView;[Le/e/a/NetworkTask;[Landroid/widget/LinearLayout;)V

    iput-object v9, v12, Le/e/a/Following190$Pager;->changed:Ljava/lang/Runnable;

    .line 31
    new-instance v1, Le/e/a/Following190$1;

    move-object/from16 v2, v16

    move-object/from16 v3, v20

    invoke-direct {v1, v2, v3}, Le/e/a/Following190$1;-><init>([Le/e/a/NetworkTask;[Landroid/widget/LinearLayout;)V

    invoke-virtual {v12, v1}, Le/e/a/Following190$Pager;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 32
    new-array v1, v15, [Ljava/lang/String;

    const-string v2, "\u30e6\u30fc\u30b6\u30fc"

    aput-object v2, v1, v14

    const-string v2, "\u30c1\u30e3\u30f3\u30cd\u30eb"

    aput-object v2, v1, v19

    const-string v2, "\u30de\u30a4\u30ea\u30b9\u30c8"

    const/4 v3, 0x2

    aput-object v2, v1, v3

    new-array v2, v15, [Ljava/lang/String;

    const-string v4, "Users"

    aput-object v4, v2, v14

    const-string v4, "Channels"

    aput-object v4, v2, v19

    const-string v4, "Mylists"

    aput-object v4, v2, v3

    new-array v4, v15, [Ljava/lang/String;

    const-string v5, "\u4f7f\u7528\u8005"

    aput-object v5, v4, v14

    const-string v5, "\u983b\u9053"

    aput-object v5, v4, v19

    const-string v5, "\u64ad\u653e\u6e05\u55ae"

    aput-object v5, v4, v3

    .line 33
    const/4 v5, 0x0

    :goto_ec
    if-lt v5, v15, :cond_f0

    .line 34
    goto/16 :goto_1a4

    .line 33
    :cond_f0
    invoke-static/range {p0 .. p0}, Le/e/a/PanelUi;->column(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v14, v11, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v7, v1, v5

    aget-object v8, v2, v5

    aget-object v9, v4, v5

    invoke-static {v0, v7, v8, v9}, Le/e/a/PanelUi;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xe

    invoke-static {v0, v7, v8}, Le/e/a/PanelUi;->text(Landroid/content/Context;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object v7

    aput-object v7, v18, v5

    aget-object v7, v18, v5

    const/16 v8, 0x11

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setGravity(I)V

    aget-object v7, v18, v5

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x30

    invoke-static {v0, v9}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x1

    invoke-direct {v8, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/view/View;

    invoke-direct {v7, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    aput-object v7, v17, v5

    aget-object v7, v17, v5

    if-nez v5, :cond_136

    invoke-static/range {p0 .. p0}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v8

    goto :goto_137

    :cond_136
    const/4 v8, 0x0

    :goto_137
    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundColor(I)V

    aget-object v7, v17, v5

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v0, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x1

    invoke-direct {v8, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v6, v18, v5

    if-nez v5, :cond_14f

    const/4 v7, 0x1

    goto :goto_150

    :cond_14f
    const/4 v7, 0x0

    :goto_150
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setSelected(Z)V

    aget-object v6, v18, v5

    if-nez v5, :cond_15c

    invoke-static/range {p0 .. p0}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v7

    goto :goto_160

    :cond_15c
    invoke-static/range {p0 .. p0}, Le/e/a/PanelUi;->ink(Landroid/content/Context;)I

    move-result v7

    :goto_160
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    aget-object v6, v18, v5

    new-instance v7, Le/e/a/Following190$$ExternalSyntheticLambda2;

    invoke-direct {v7, v12, v5}, Le/e/a/Following190$$ExternalSyntheticLambda2;-><init>(Le/e/a/Following190$Pager;I)V

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v5, v5, 0x1

    const/4 v11, -0x2

    goto/16 :goto_ec

    .line 23
    :cond_172
    move-object v3, v8

    const/16 v19, 0x1

    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    invoke-static/range {p0 .. p0}, Le/e/a/PanelUi;->column(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v5

    aput-object v5, v3, v2

    aget-object v5, v3, v2

    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v4, v5}, Le/e/a/Following190$Pager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v5, 0x8

    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->setVisibility(I)V
    :try_end_193
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_193} :catch_19c

    add-int/lit8 v2, v2, 0x1

    move-object v8, v3

    const/4 v7, 0x1

    const/4 v9, -0x1

    const/4 v11, -0x2

    goto/16 :goto_8b

    .line 17
    :cond_19b
    :goto_19b
    return-void

    .line 34
    :catch_19c
    move-exception v0

    const-string v1, "nicoid-following"

    const-string v2, "Unable to initialize following tabs"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1a4
    return-void
.end method

.method static synthetic lambda$0(Landroid/app/Activity;)V
    .registers 8

    .line 25
    const-string v0, "Following"

    const-string v1, "\u8ffd\u8e64\u4e2d"

    const-string v2, "\u30d5\u30a9\u30ed\u30fc\u4e2d"

    invoke-static {p0, v2, v0, v1}, Le/e/a/PanelUi;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    :try_start_d
    const-string v1, "L"

    invoke-static {p0, v1}, Le/e/a/Review181;->field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "b"

    const/4 v3, 0x1

    new-array v4, v3, [Ljava/lang/Class;

    const-class v5, Ljava/lang/CharSequence;

    const/4 v6, 0x0

    aput-object v5, v4, v6

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    new-array v2, v3, [Ljava/lang/Object;

    aput-object v0, v2, v6

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_2c} :catch_2d

    goto :goto_2e

    :catch_2d
    move-exception p0

    :goto_2e
    return-void
.end method

.method static synthetic lambda$1(Le/e/a/Following190$Pager;Ljava/lang/Runnable;[Landroid/view/View;Landroid/app/Activity;[Landroid/widget/TextView;[Le/e/a/NetworkTask;[Landroid/widget/LinearLayout;)V
    .registers 11

    .line 26
    iget p0, p0, Le/e/a/Following190$Pager;->selected:I

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    const/4 p1, 0x0

    const/4 v0, 0x0

    :goto_7
    const/4 v1, 0x3

    const/4 v2, 0x1

    if-lt v0, v1, :cond_48

    .line 27
    aget-object p2, p5, p1

    if-eqz p2, :cond_14

    aget-object p2, p5, p1

    invoke-virtual {p2}, Le/e/a/NetworkTask;->cancel()V

    .line 28
    :cond_14
    const/4 p2, 0x2

    aget-object p4, p6, p2

    invoke-virtual {p4}, Landroid/widget/LinearLayout;->getTag()Ljava/lang/Object;

    move-result-object p4

    instance-of p4, p4, Le/e/a/NetworkTask;

    if-eqz p4, :cond_2a

    aget-object p2, p6, p2

    invoke-virtual {p2}, Landroid/widget/LinearLayout;->getTag()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Le/e/a/NetworkTask;

    invoke-virtual {p2}, Le/e/a/NetworkTask;->cancel()V

    .line 29
    :cond_2a
    if-lez p0, :cond_47

    aget-object p2, p6, p0

    invoke-virtual {p2}, Landroid/widget/LinearLayout;->removeAllViews()V

    if-ne p0, v2, :cond_42

    new-instance p2, Le/e/a/NetworkTask;

    invoke-direct {p2}, Le/e/a/NetworkTask;-><init>()V

    aput-object p2, p5, p1

    aget-object p0, p6, p0

    aget-object p1, p5, p1

    invoke-static {p3, p0, p1}, Le/e/a/CreatorPage;->loadFollowingChannels(Landroid/app/Activity;Landroid/widget/LinearLayout;Le/e/a/NetworkTask;)V

    goto :goto_47

    :cond_42
    aget-object p0, p6, p0

    invoke-static {p3, p0, v2}, Le/e/a/CreatorPage;->loadMylists(Landroid/app/Activity;Landroid/widget/LinearLayout;I)V

    .line 30
    :cond_47
    :goto_47
    return-void

    .line 26
    :cond_48
    aget-object v1, p2, v0

    if-ne v0, p0, :cond_51

    invoke-static {p3}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v3

    goto :goto_52

    :cond_51
    const/4 v3, 0x0

    :goto_52
    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    aget-object v1, p4, v0

    if-ne v0, p0, :cond_5a

    goto :goto_5b

    :cond_5a
    const/4 v2, 0x0

    :goto_5b
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setSelected(Z)V

    aget-object v1, p4, v0

    if-ne v0, p0, :cond_67

    invoke-static {p3}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v2

    goto :goto_6b

    :cond_67
    invoke-static {p3}, Le/e/a/PanelUi;->ink(Landroid/content/Context;)I

    move-result v2

    :goto_6b
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_7
.end method

.method static synthetic lambda$2(Le/e/a/Following190$Pager;ILandroid/view/View;)V
    .registers 3

    .line 33
    invoke-virtual {p0, p1}, Le/e/a/Following190$Pager;->select(I)V

    return-void
.end method

.method static roundAvatar(Landroid/view/View;)V
    .registers 2

    .line 49
    new-instance v0, Le/e/a/Following190$2;

    invoke-direct {v0}, Le/e/a/Following190$2;-><init>()V

    invoke-virtual {p0, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->setClipToOutline(Z)V

    return-void
.end method

.method static sizeRow(Landroid/view/View;)V
    .registers 6

    .line 47
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/16 v1, 0x40

    invoke-static {v0, v1}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/16 v1, 0x10

    invoke-static {v0, v1}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/16 v3, 0xa

    invoke-static {v2, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v1}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v3

    invoke-virtual {p0, v0, v2, v1, v3}, Landroid/view/View;->setPadding(IIII)V

    return-void
.end method

.method static style(Landroid/view/View;)V
    .registers 5

    .line 50
    instance-of v0, p0, Landroid/widget/TextView;

    const/4 v1, 0x0

    if-eqz v0, :cond_31

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_1e

    const/4 v2, -0x2

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    instance-of v2, v0, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz v2, :cond_1b

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    move-object v2, v0

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    :cond_1b
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1e
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Le/e/a/PanelUi;->ink(Landroid/content/Context;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_31
    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_62

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/16 v3, 0x2c

    invoke-static {v2, v3}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v2

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    instance-of v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v2, :cond_51

    move-object v2, v0

    check-cast v2, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-virtual {v2, v1, v1, v1, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    :cond_51
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move-object v0, p0

    check-cast v0, Landroid/widget/ImageView;

    sget-object v2, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setAdjustViewBounds(Z)V

    invoke-static {p0}, Le/e/a/Following190;->roundAvatar(Landroid/view/View;)V

    :cond_62
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_79

    check-cast p0, Landroid/view/ViewGroup;

    :goto_68
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lt v1, v0, :cond_6f

    goto :goto_79

    :cond_6f
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Le/e/a/Following190;->style(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_68

    :cond_79
    :goto_79
    return-void
.end method
