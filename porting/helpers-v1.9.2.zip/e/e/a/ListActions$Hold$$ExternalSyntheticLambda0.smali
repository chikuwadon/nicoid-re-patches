.class public final synthetic Le/e/a/ListActions$Hold$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Le/e/a/ListActions$Hold;

.field public final synthetic f$1:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Le/e/a/ListActions$Hold;Landroid/view/View;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/ListActions$Hold$$ExternalSyntheticLambda0;->f$0:Le/e/a/ListActions$Hold;

    iput-object p2, p0, Le/e/a/ListActions$Hold$$ExternalSyntheticLambda0;->f$1:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Le/e/a/ListActions$Hold$$ExternalSyntheticLambda0;->f$0:Le/e/a/ListActions$Hold;

    iget-object v1, p0, Le/e/a/ListActions$Hold$$ExternalSyntheticLambda0;->f$1:Landroid/view/View;

    invoke-virtual {v0, v1}, Le/e/a/ListActions$Hold;->lambda$0$e-e-a-ListActions$Hold(Landroid/view/View;)V

    return-void
.end method
