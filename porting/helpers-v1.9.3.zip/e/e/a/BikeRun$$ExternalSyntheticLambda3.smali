.class public final synthetic Le/e/a/BikeRun$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Le/e/a/BikeRun$Track;


# direct methods
.method public synthetic constructor <init>(Le/e/a/BikeRun$Track;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/BikeRun$$ExternalSyntheticLambda3;->f$0:Le/e/a/BikeRun$Track;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Le/e/a/BikeRun$$ExternalSyntheticLambda3;->f$0:Le/e/a/BikeRun$Track;

    invoke-static {v0, p1}, Le/e/a/BikeRun;->lambda$1(Le/e/a/BikeRun$Track;Landroid/view/View;)V

    return-void
.end method
