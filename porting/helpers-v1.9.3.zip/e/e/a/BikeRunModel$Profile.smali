.class final Le/e/a/BikeRunModel$Profile;
.super Ljava/lang/Object;
.source "BikeRunModel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/BikeRunModel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Profile"
.end annotation


# instance fields
.field final down:F

.field final height:F

.field final rise:F

.field final step:F

.field final steps:Z

.field final width:F


# direct methods
.method constructor <init>(JJ)V
    .registers 8

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Random;

    const-wide v1, -0x61c8864680b583ebL

    mul-long v1, v1, p3

    xor-long/2addr p1, v1

    invoke-direct {v0, p1, p2}, Ljava/util/Random;-><init>(J)V

    const/16 p1, 0x1a4

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p2

    add-int/lit16 p2, p2, 0x17c

    int-to-float p2, p2

    iput p2, p0, Le/e/a/BikeRunModel$Profile;->rise:F

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/lit16 p1, p1, 0x17c

    int-to-float p1, p1

    iput p1, p0, Le/e/a/BikeRunModel$Profile;->down:F

    const/16 p1, 0x78

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/lit8 p1, p1, 0x46

    int-to-float p1, p1

    iput p1, p0, Le/e/a/BikeRunModel$Profile;->height:F

    const/16 p1, 0x3c

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/lit8 p1, p1, 0x2d

    int-to-float p1, p1

    iput p1, p0, Le/e/a/BikeRunModel$Profile;->step:F

    const/16 p1, 0xfa

    invoke-virtual {v0, p1}, Ljava/util/Random;->nextInt(I)I

    move-result p1

    add-int/lit16 p1, p1, 0x15e

    int-to-float p1, p1

    iput p1, p0, Le/e/a/BikeRunModel$Profile;->width:F

    const-wide/16 p1, 0x0

    cmp-long v1, p3, p1

    if-lez v1, :cond_53

    invoke-virtual {v0}, Ljava/util/Random;->nextBoolean()Z

    move-result p1

    if-eqz p1, :cond_53

    const/4 p1, 0x1

    goto :goto_54

    :cond_53
    const/4 p1, 0x0

    :goto_54
    iput-boolean p1, p0, Le/e/a/BikeRunModel$Profile;->steps:Z

    return-void
.end method


# virtual methods
.method at(F)F
    .registers 6

    .line 33
    const/4 v0, 0x0

    const/high16 v1, 0x44480000    # 800.0f

    cmpg-float v2, p1, v1

    if-gez v2, :cond_8

    return v0

    :cond_8
    iget v2, p0, Le/e/a/BikeRunModel$Profile;->rise:F

    add-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_19

    iget v0, p0, Le/e/a/BikeRunModel$Profile;->height:F

    neg-float v0, v0

    sub-float/2addr p1, v1

    mul-float v0, v0, p1

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->rise:F

    div-float/2addr v0, p1

    return v0

    :cond_19
    const/high16 v1, 0x45480000    # 3200.0f

    cmpg-float v2, p1, v1

    if-gez v2, :cond_23

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->height:F

    neg-float p1, p1

    return p1

    :cond_23
    iget v2, p0, Le/e/a/BikeRunModel$Profile;->down:F

    add-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_37

    iget v0, p0, Le/e/a/BikeRunModel$Profile;->height:F

    neg-float v0, v0

    iget v2, p0, Le/e/a/BikeRunModel$Profile;->height:F

    sub-float/2addr p1, v1

    mul-float v2, v2, p1

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->down:F

    div-float/2addr v2, p1

    add-float/2addr v0, v2

    return v0

    :cond_37
    iget-boolean v1, p0, Le/e/a/BikeRunModel$Profile;->steps:Z

    if-nez v1, :cond_3c

    return v0

    :cond_3c
    const v1, 0x458ca000    # 4500.0f

    cmpg-float v2, p1, v1

    if-gez v2, :cond_44

    return v0

    :cond_44
    iget v2, p0, Le/e/a/BikeRunModel$Profile;->width:F

    add-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_4f

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->step:F

    neg-float p1, p1

    return p1

    :cond_4f
    iget v2, p0, Le/e/a/BikeRunModel$Profile;->width:F

    const/high16 v3, 0x40000000    # 2.0f

    mul-float v2, v2, v3

    add-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_60

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->step:F

    neg-float p1, p1

    mul-float p1, p1, v3

    return p1

    :cond_60
    iget v2, p0, Le/e/a/BikeRunModel$Profile;->width:F

    const/high16 v3, 0x40400000    # 3.0f

    mul-float v2, v2, v3

    add-float/2addr v2, v1

    cmpg-float p1, p1, v2

    if-gez p1, :cond_6f

    iget p1, p0, Le/e/a/BikeRunModel$Profile;->step:F

    neg-float p1, p1

    return p1

    :cond_6f
    return v0
.end method
