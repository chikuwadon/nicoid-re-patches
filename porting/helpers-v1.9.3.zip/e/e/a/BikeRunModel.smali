.class public final Le/e/a/BikeRunModel;
.super Ljava/lang/Object;
.source "BikeRunModel.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/BikeRunModel$Hazard;,
        Le/e/a/BikeRunModel$Profile;
    }
.end annotation


# static fields
.field public static final EDGE_GRACE:F = 0.1f

.field public static final GRAVITY:F = 1600.0f

.field public static final JUMP:F = -650.0f

.field public static final RIDER_X:F = 120.0f

.field private static final SECTION:F = 6400.0f

.field public static final START_SPEED:F = 440.0f


# instance fields
.field public distance:F

.field private falling:Z

.field private gapTime:F

.field public final hazards:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Le/e/a/BikeRunModel$Hazard;",
            ">;"
        }
    .end annotation
.end field

.field private jumpsUsed:I

.field public over:Z

.field private final profiles:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/Long;",
            "Le/e/a/BikeRunModel$Profile;",
            ">;"
        }
    .end annotation
.end field

.field private final random:Ljava/util/Random;

.field public spawn:F

.field public started:Z

.field private terrainSeed:J

.field public velocity:F

.field public y:F


# direct methods
.method public constructor <init>(J)V
    .registers 7

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    .line 21
    new-instance v0, Le/e/a/BikeRunModel$1;

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v2, 0x1

    const/16 v3, 0x8

    invoke-direct {v0, p0, v3, v1, v2}, Le/e/a/BikeRunModel$1;-><init>(Le/e/a/BikeRunModel;IFZ)V

    iput-object v0, p0, Le/e/a/BikeRunModel;->profiles:Ljava/util/LinkedHashMap;

    .line 27
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0, p1, p2}, Ljava/util/Random;-><init>(J)V

    iput-object v0, p0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {p0}, Le/e/a/BikeRunModel;->reset()V

    return-void
.end method


# virtual methods
.method public flatSpan(FF)Z
    .registers 8

    .line 44
    invoke-virtual {p0, p1}, Le/e/a/BikeRunModel;->terrain(F)F

    move-result v0

    .line 45
    const/high16 v1, 0x40800000    # 4.0f

    :cond_6
    add-float/2addr p1, v1

    const/4 v2, 0x0

    const v3, 0x3c23d70a    # 0.01f

    cmpg-float v4, p1, p2

    if-ltz v4, :cond_1f

    .line 46
    invoke-virtual {p0, p2}, Le/e/a/BikeRunModel;->terrain(F)F

    move-result p1

    sub-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    cmpg-float p1, p1, v3

    if-gtz p1, :cond_1e

    const/4 p1, 0x1

    return p1

    :cond_1e
    return v2

    .line 45
    :cond_1f
    invoke-virtual {p0, p1}, Le/e/a/BikeRunModel;->terrain(F)F

    move-result v4

    sub-float/2addr v4, v0

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v3, v4, v3

    if-lez v3, :cond_6

    return v2
.end method

.method public groundAt(F)F
    .registers 3

    .line 54
    iget v0, p0, Le/e/a/BikeRunModel;->distance:F

    add-float/2addr v0, p1

    invoke-virtual {p0, v0}, Le/e/a/BikeRunModel;->terrain(F)F

    move-result p1

    return p1
.end method

.method public placement(F)F
    .registers 7

    .line 49
    invoke-virtual {p0}, Le/e/a/BikeRunModel;->speed()F

    move-result v0

    const v1, 0x3dcccccd    # 0.1f

    mul-float v0, v0, v1

    const/high16 v2, 0x43700000    # 240.0f

    add-float/2addr v0, v2

    invoke-virtual {p0}, Le/e/a/BikeRunModel;->speed()F

    move-result v2

    mul-float v2, v2, v1

    const/high16 v1, 0x43200000    # 160.0f

    add-float/2addr v2, v1

    .line 50
    const/high16 v1, 0x443e0000    # 760.0f

    :goto_17
    const v3, 0x46156000    # 9560.0f

    cmpg-float v3, v1, v3

    if-ltz v3, :cond_21

    .line 52
    const/high16 p1, 0x7fc00000    # Float.NaN

    return p1

    .line 51
    :cond_21
    iget v3, p0, Le/e/a/BikeRunModel;->distance:F

    add-float/2addr v3, v1

    sub-float/2addr v3, v0

    iget v4, p0, Le/e/a/BikeRunModel;->distance:F

    add-float/2addr v4, v1

    add-float/2addr v4, p1

    add-float/2addr v4, v2

    invoke-virtual {p0, v3, v4}, Le/e/a/BikeRunModel;->flatSpan(FF)Z

    move-result v3

    if-eqz v3, :cond_31

    return v1

    .line 50
    :cond_31
    const/high16 v3, 0x41a00000    # 20.0f

    add-float/2addr v1, v3

    goto :goto_17
.end method

.method public reset()V
    .registers 3

    .line 28
    iget-object v0, p0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    move-result-wide v0

    iput-wide v0, p0, Le/e/a/BikeRunModel;->terrainSeed:J

    iget-object v0, p0, Le/e/a/BikeRunModel;->profiles:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v0, p0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, 0x0

    iput v0, p0, Le/e/a/BikeRunModel;->gapTime:F

    iput v0, p0, Le/e/a/BikeRunModel;->distance:F

    iput v0, p0, Le/e/a/BikeRunModel;->velocity:F

    iput v0, p0, Le/e/a/BikeRunModel;->y:F

    const/high16 v0, 0x442f0000    # 700.0f

    iput v0, p0, Le/e/a/BikeRunModel;->spawn:F

    const/4 v0, 0x0

    iput v0, p0, Le/e/a/BikeRunModel;->jumpsUsed:I

    iput-boolean v0, p0, Le/e/a/BikeRunModel;->falling:Z

    iput-boolean v0, p0, Le/e/a/BikeRunModel;->over:Z

    iput-boolean v0, p0, Le/e/a/BikeRunModel;->started:Z

    return-void
.end method

.method public score()I
    .registers 3

    .line 111
    iget v0, p0, Le/e/a/BikeRunModel;->distance:F

    const/high16 v1, 0x41200000    # 10.0f

    div-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method public slopeAt(F)F
    .registers 4

    .line 55
    const/high16 v0, 0x40800000    # 4.0f

    add-float v1, p1, v0

    invoke-virtual {p0, v1}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result v1

    sub-float/2addr p1, v0

    invoke-virtual {p0, p1}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result p1

    sub-float/2addr v1, p1

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/high16 v0, 0x41000000    # 8.0f

    cmpl-float p1, p1, v0

    if-lez p1, :cond_1a

    const/4 p1, 0x0

    goto :goto_1c

    :cond_1a
    div-float p1, v1, v0

    :goto_1c
    return p1
.end method

.method public speed()F
    .registers 3

    .line 56
    iget v0, p0, Le/e/a/BikeRunModel;->distance:F

    const/high16 v1, 0x42820000    # 65.0f

    div-float/2addr v0, v1

    const/high16 v1, 0x438c0000    # 280.0f

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v1, 0x43dc0000    # 440.0f

    add-float/2addr v0, v1

    return v0
.end method

.method public step(F)V
    .registers 19

    .line 63
    move-object/from16 v0, p0

    move/from16 v1, p1

    iget-boolean v2, v0, Le/e/a/BikeRunModel;->started:Z

    if-eqz v2, :cond_229

    iget-boolean v2, v0, Le/e/a/BikeRunModel;->over:Z

    if-nez v2, :cond_229

    const/4 v2, 0x0

    cmpg-float v3, v1, v2

    if-gtz v3, :cond_13

    goto/16 :goto_229

    .line 64
    :cond_13
    const v3, 0x3d0f5c29    # 0.035f

    invoke-static {v1, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    .line 65
    const/high16 v3, 0x42f00000    # 120.0f

    invoke-virtual {v0, v3}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result v4

    .line 66
    invoke-virtual/range {p0 .. p0}, Le/e/a/BikeRunModel;->speed()F

    move-result v5

    mul-float v5, v5, v1

    .line 67
    iget v6, v0, Le/e/a/BikeRunModel;->distance:F

    add-float/2addr v6, v5

    iput v6, v0, Le/e/a/BikeRunModel;->distance:F

    iget v6, v0, Le/e/a/BikeRunModel;->spawn:F

    sub-float/2addr v6, v5

    iput v6, v0, Le/e/a/BikeRunModel;->spawn:F

    .line 68
    invoke-virtual {v0, v3}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result v6

    sub-float/2addr v4, v6

    .line 70
    const/high16 v6, 0x41a00000    # 20.0f

    const/high16 v7, 0x41200000    # 10.0f

    const/4 v8, 0x1

    cmpl-float v6, v4, v6

    if-lez v6, :cond_49

    iget v6, v0, Le/e/a/BikeRunModel;->y:F

    neg-float v9, v4

    add-float/2addr v9, v7

    cmpl-float v6, v6, v9

    if-lez v6, :cond_49

    iput-boolean v8, v0, Le/e/a/BikeRunModel;->over:Z

    return-void

    .line 72
    :cond_49
    iget-boolean v6, v0, Le/e/a/BikeRunModel;->falling:Z

    if-nez v6, :cond_5f

    iget v6, v0, Le/e/a/BikeRunModel;->y:F

    cmpg-float v6, v6, v2

    if-ltz v6, :cond_5f

    iget v6, v0, Le/e/a/BikeRunModel;->velocity:F

    cmpg-float v6, v6, v2

    if-ltz v6, :cond_5f

    const/high16 v6, -0x3e600000    # -20.0f

    cmpg-float v6, v4, v6

    if-gez v6, :cond_84

    .line 73
    :cond_5f
    iget v6, v0, Le/e/a/BikeRunModel;->y:F

    add-float/2addr v6, v4

    iput v6, v0, Le/e/a/BikeRunModel;->y:F

    .line 74
    iget v4, v0, Le/e/a/BikeRunModel;->velocity:F

    const/high16 v6, 0x44c80000    # 1600.0f

    mul-float v6, v6, v1

    add-float/2addr v4, v6

    iput v4, v0, Le/e/a/BikeRunModel;->velocity:F

    iget v4, v0, Le/e/a/BikeRunModel;->y:F

    iget v6, v0, Le/e/a/BikeRunModel;->velocity:F

    mul-float v6, v6, v1

    add-float/2addr v4, v6

    iput v4, v0, Le/e/a/BikeRunModel;->y:F

    .line 75
    iget-boolean v4, v0, Le/e/a/BikeRunModel;->falling:Z

    if-nez v4, :cond_84

    iget v4, v0, Le/e/a/BikeRunModel;->y:F

    cmpl-float v4, v4, v2

    if-ltz v4, :cond_84

    iput v2, v0, Le/e/a/BikeRunModel;->y:F

    iput v2, v0, Le/e/a/BikeRunModel;->velocity:F

    .line 77
    :cond_84
    iget v4, v0, Le/e/a/BikeRunModel;->spawn:F

    const/4 v6, 0x0

    cmpg-float v4, v4, v2

    if-gtz v4, :cond_158

    .line 78
    iget-object v4, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {v4}, Ljava/util/Random;->nextBoolean()Z

    move-result v13

    .line 80
    iget v4, v0, Le/e/a/BikeRunModel;->distance:F

    const/high16 v9, 0x447a0000    # 1000.0f

    cmpl-float v4, v4, v9

    if-lez v4, :cond_a4

    iget-object v4, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    const/4 v9, 0x4

    invoke-virtual {v4, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    if-nez v4, :cond_a4

    const/4 v4, 0x1

    goto :goto_a5

    :cond_a4
    const/4 v4, 0x0

    .line 81
    :goto_a5
    const/16 v9, 0x28

    if-eqz v13, :cond_be

    if-eqz v4, :cond_b5

    invoke-virtual/range {p0 .. p0}, Le/e/a/BikeRunModel;->speed()F

    move-result v10

    const v11, 0x3f733333    # 0.95f

    mul-float v10, v10, v11

    goto :goto_c9

    :cond_b5
    iget-object v10, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {v10, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v10

    add-int/lit8 v10, v10, 0x73

    goto :goto_c8

    :cond_be
    iget-object v10, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    const/16 v11, 0x16

    invoke-virtual {v10, v11}, Ljava/util/Random;->nextInt(I)I

    move-result v10

    add-int/lit8 v10, v10, 0x24

    :goto_c8
    int-to-float v10, v10

    .line 82
    :goto_c9
    if-eqz v13, :cond_cd

    const/4 v11, 0x0

    goto :goto_e2

    :cond_cd
    iget-object v11, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    if-eqz v4, :cond_da

    const/16 v12, 0x10

    invoke-virtual {v11, v12}, Ljava/util/Random;->nextInt(I)I

    move-result v11

    add-int/lit16 v11, v11, 0xa5

    goto :goto_e2

    :cond_da
    const/16 v12, 0x1b

    invoke-virtual {v11, v12}, Ljava/util/Random;->nextInt(I)I

    move-result v11

    add-int/lit8 v11, v11, 0x1c

    :goto_e2
    int-to-float v11, v11

    .line 83
    if-nez v13, :cond_f1

    if-nez v4, :cond_f1

    iget-object v4, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {v4}, Ljava/util/Random;->nextBoolean()Z

    move-result v4

    if-eqz v4, :cond_f1

    const/4 v14, 0x1

    goto :goto_f2

    :cond_f1
    const/4 v14, 0x0

    .line 84
    :goto_f2
    if-eqz v14, :cond_117

    iget v4, v0, Le/e/a/BikeRunModel;->distance:F

    const v10, 0x451c4000    # 2500.0f

    cmpl-float v4, v4, v10

    if-lez v4, :cond_108

    iget-object v4, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    const/16 v9, 0x46

    invoke-virtual {v4, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/lit8 v4, v4, 0x64

    goto :goto_110

    :cond_108
    iget-object v4, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    invoke-virtual {v4, v9}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/lit8 v4, v4, 0x3c

    :goto_110
    int-to-float v10, v4

    const/high16 v4, 0x41f00000    # 30.0f

    move v4, v10

    const/high16 v12, 0x41f00000    # 30.0f

    goto :goto_119

    :cond_117
    move v4, v10

    move v12, v11

    .line 86
    :goto_119
    invoke-virtual {v0, v4}, Le/e/a/BikeRunModel;->placement(F)F

    move-result v15

    .line 87
    invoke-static {v15}, Ljava/lang/Float;->isNaN(F)Z

    move-result v9

    if-eqz v9, :cond_128

    const/high16 v1, 0x42c80000    # 100.0f

    iput v1, v0, Le/e/a/BikeRunModel;->spawn:F

    return-void

    .line 88
    :cond_128
    iget-object v11, v0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    new-instance v10, Le/e/a/BikeRunModel$Hazard;

    add-float v16, v15, v5

    move-object v9, v10

    move-object v7, v10

    move/from16 v10, v16

    move-object v3, v11

    move v11, v4

    invoke-direct/range {v9 .. v14}, Le/e/a/BikeRunModel$Hazard;-><init>(FFFZZ)V

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 90
    const/high16 v3, 0x443e0000    # 760.0f

    sub-float/2addr v15, v3

    iget-object v3, v0, Le/e/a/BikeRunModel;->random:Ljava/util/Random;

    const/16 v7, 0xdc

    invoke-virtual {v3, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    add-int/lit16 v3, v3, 0x1b8

    int-to-float v3, v3

    invoke-virtual/range {p0 .. p0}, Le/e/a/BikeRunModel;->speed()F

    move-result v7

    const/high16 v9, 0x3fa00000    # 1.25f

    mul-float v7, v7, v9

    add-float/2addr v4, v7

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    add-float/2addr v15, v3

    iput v15, v0, Le/e/a/BikeRunModel;->spawn:F

    .line 92
    :cond_158
    nop

    .line 93
    iget-object v3, v0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v8

    const/4 v4, 0x0

    :goto_161
    if-gez v3, :cond_1ab

    .line 105
    if-eqz v4, :cond_173

    iget v3, v0, Le/e/a/BikeRunModel;->y:F

    cmpl-float v3, v3, v2

    if-ltz v3, :cond_173

    iget v3, v0, Le/e/a/BikeRunModel;->velocity:F

    cmpl-float v3, v3, v2

    if-ltz v3, :cond_173

    iput-boolean v8, v0, Le/e/a/BikeRunModel;->falling:Z

    .line 106
    :cond_173
    if-eqz v4, :cond_179

    iget v3, v0, Le/e/a/BikeRunModel;->gapTime:F

    add-float/2addr v3, v1

    goto :goto_17a

    :cond_179
    const/4 v3, 0x0

    :goto_17a
    iput v3, v0, Le/e/a/BikeRunModel;->gapTime:F

    .line 107
    if-nez v4, :cond_190

    iget-boolean v1, v0, Le/e/a/BikeRunModel;->falling:Z

    if-nez v1, :cond_190

    iget v1, v0, Le/e/a/BikeRunModel;->y:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_190

    iget v1, v0, Le/e/a/BikeRunModel;->velocity:F

    cmpl-float v1, v1, v2

    if-nez v1, :cond_190

    iput v6, v0, Le/e/a/BikeRunModel;->jumpsUsed:I

    .line 108
    :cond_190
    iget-boolean v1, v0, Le/e/a/BikeRunModel;->falling:Z

    if-eqz v1, :cond_19e

    iget v1, v0, Le/e/a/BikeRunModel;->y:F

    const/high16 v3, 0x435c0000    # 220.0f

    cmpl-float v1, v1, v3

    if-lez v1, :cond_19e

    iput-boolean v8, v0, Le/e/a/BikeRunModel;->over:Z

    .line 109
    :cond_19e
    iget-boolean v1, v0, Le/e/a/BikeRunModel;->falling:Z

    if-eqz v1, :cond_1aa

    iget v1, v0, Le/e/a/BikeRunModel;->y:F

    cmpg-float v1, v1, v2

    if-gez v1, :cond_1aa

    iput-boolean v6, v0, Le/e/a/BikeRunModel;->falling:Z

    .line 110
    :cond_1aa
    return-void

    .line 94
    :cond_1ab
    iget-object v7, v0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Le/e/a/BikeRunModel$Hazard;

    iget v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    sub-float/2addr v9, v5

    iput v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    .line 95
    iget-boolean v9, v7, Le/e/a/BikeRunModel$Hazard;->gap:Z

    if-eqz v9, :cond_1dc

    .line 97
    iget v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    const/high16 v10, 0x41600000    # 14.0f

    add-float/2addr v9, v10

    const/high16 v11, 0x42f00000    # 120.0f

    cmpl-float v9, v11, v9

    if-lez v9, :cond_1d7

    iget v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    iget v12, v7, Le/e/a/BikeRunModel$Hazard;->width:F

    add-float/2addr v9, v12

    sub-float/2addr v9, v10

    cmpg-float v9, v11, v9

    if-gez v9, :cond_1d7

    .line 98
    const/4 v4, 0x1

    const/high16 v10, 0x42f00000    # 120.0f

    const/high16 v12, 0x41200000    # 10.0f

    goto :goto_217

    .line 97
    :cond_1d7
    const/high16 v10, 0x42f00000    # 120.0f

    const/high16 v12, 0x41200000    # 10.0f

    goto :goto_217

    .line 99
    :cond_1dc
    iget v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    iget v10, v7, Le/e/a/BikeRunModel$Hazard;->width:F

    const/high16 v11, 0x40000000    # 2.0f

    div-float/2addr v10, v11

    add-float/2addr v9, v10

    invoke-virtual {v0, v9}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result v9

    const/high16 v10, 0x42f00000    # 120.0f

    invoke-virtual {v0, v10}, Le/e/a/BikeRunModel;->groundAt(F)F

    move-result v11

    sub-float/2addr v9, v11

    .line 101
    iget v11, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    const/high16 v12, 0x41000000    # 8.0f

    add-float/2addr v11, v12

    const/high16 v13, 0x43060000    # 134.0f

    cmpl-float v11, v13, v11

    if-lez v11, :cond_215

    iget v11, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    iget v13, v7, Le/e/a/BikeRunModel$Hazard;->width:F

    add-float/2addr v11, v13

    sub-float/2addr v11, v12

    const/high16 v12, 0x42d40000    # 106.0f

    cmpg-float v11, v12, v11

    if-gez v11, :cond_215

    iget v11, v0, Le/e/a/BikeRunModel;->y:F

    iget v12, v7, Le/e/a/BikeRunModel$Hazard;->height:F

    sub-float/2addr v9, v12

    const/high16 v12, 0x41200000    # 10.0f

    add-float/2addr v9, v12

    cmpl-float v9, v11, v9

    if-lez v9, :cond_217

    iput-boolean v8, v0, Le/e/a/BikeRunModel;->over:Z

    goto :goto_217

    :cond_215
    const/high16 v12, 0x41200000    # 10.0f

    .line 103
    :cond_217
    :goto_217
    iget v9, v7, Le/e/a/BikeRunModel$Hazard;->x:F

    iget v7, v7, Le/e/a/BikeRunModel$Hazard;->width:F

    add-float/2addr v9, v7

    cmpg-float v7, v9, v2

    if-gez v7, :cond_225

    iget-object v7, v0, Le/e/a/BikeRunModel;->hazards:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 93
    :cond_225
    add-int/lit8 v3, v3, -0x1

    goto/16 :goto_161

    .line 63
    :cond_229
    :goto_229
    return-void
.end method

.method public tap()V
    .registers 4

    .line 58
    iget-boolean v0, p0, Le/e/a/BikeRunModel;->over:Z

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Le/e/a/BikeRunModel;->reset()V

    .line 59
    :cond_7
    const/4 v0, 0x1

    iput-boolean v0, p0, Le/e/a/BikeRunModel;->started:Z

    .line 60
    iget v1, p0, Le/e/a/BikeRunModel;->jumpsUsed:I

    const/4 v2, 0x2

    if-ge v1, v2, :cond_1c

    const v1, -0x3bdd8000    # -650.0f

    iput v1, p0, Le/e/a/BikeRunModel;->velocity:F

    const/4 v1, 0x0

    iput v1, p0, Le/e/a/BikeRunModel;->gapTime:F

    iget v1, p0, Le/e/a/BikeRunModel;->jumpsUsed:I

    add-int/2addr v1, v0

    iput v1, p0, Le/e/a/BikeRunModel;->jumpsUsed:I

    .line 61
    :cond_1c
    return-void
.end method

.method public terrain(F)F
    .registers 8

    .line 37
    const/high16 v0, 0x44480000    # 800.0f

    cmpg-float v0, p1, v0

    if-gtz v0, :cond_8

    const/4 p1, 0x0

    return p1

    .line 38
    :cond_8
    const/high16 v0, 0x45c80000    # 6400.0f

    div-float v1, p1, v0

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-long v1, v1

    iget-object v3, p0, Le/e/a/BikeRunModel;->profiles:Ljava/util/LinkedHashMap;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/BikeRunModel$Profile;

    .line 39
    if-nez v3, :cond_30

    new-instance v3, Le/e/a/BikeRunModel$Profile;

    iget-wide v4, p0, Le/e/a/BikeRunModel;->terrainSeed:J

    invoke-direct {v3, v4, v5, v1, v2}, Le/e/a/BikeRunModel$Profile;-><init>(JJ)V

    iget-object v4, p0, Le/e/a/BikeRunModel;->profiles:Ljava/util/LinkedHashMap;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v4, v5, v3}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    :cond_30
    long-to-float v1, v1

    mul-float v1, v1, v0

    sub-float/2addr p1, v1

    invoke-virtual {v3, p1}, Le/e/a/BikeRunModel$Profile;->at(F)F

    move-result p1

    return p1
.end method
