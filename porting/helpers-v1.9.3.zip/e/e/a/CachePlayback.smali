.class public final Le/e/a/CachePlayback;
.super Ljava/lang/Object;
.source "CachePlayback.java"


# static fields
.field private static final TOKEN:Ljava/lang/String;

.field private static final roots:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static server:Ljava/net/ServerSocket;

.field private static final workers:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 13
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Le/e/a/CachePlayback;->TOKEN:Ljava/lang/String;

    .line 14
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Le/e/a/CachePlayback;->roots:Ljava/util/Map;

    .line 15
    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v7, Ljava/util/concurrent/SynchronousQueue;

    invoke-direct {v7}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    new-instance v8, Le/e/a/CachePlayback$$ExternalSyntheticLambda1;

    invoke-direct {v8}, Le/e/a/CachePlayback$$ExternalSyntheticLambda1;-><init>()V

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-wide/16 v4, 0x1e

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    sput-object v0, Le/e/a/CachePlayback;->workers:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static dataSource(Landroid/media/MediaPlayer;Ljava/lang/String;)V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 18
    invoke-static {p1}, Le/e/a/CachePlayback;->url(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    return-void
.end method

.method public static fromFile(Ljava/io/File;)Landroid/net/Uri;
    .registers 2

    .line 17
    invoke-static {p0}, Le/e/a/CacheFolders;->virtual(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le/e/a/CachePlayback;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    goto :goto_13

    :cond_f
    invoke-static {p0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    :goto_13
    return-object p0
.end method

.method static synthetic lambda$0(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 3

    .line 15
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "nicoid-cache-reader"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 p0, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/Thread;->setDaemon(Z)V

    return-object v0
.end method

.method static synthetic lambda$1()V
    .registers 3

    .line 28
    :goto_0
    sget-object v0, Le/e/a/CachePlayback;->server:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->isClosed()Z

    move-result v0

    if-eqz v0, :cond_9

    :goto_8
    goto :goto_21

    :cond_9
    :try_start_9
    sget-object v0, Le/e/a/CachePlayback;->server:Ljava/net/ServerSocket;

    invoke-virtual {v0}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v0
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_f} :catch_1f

    :try_start_f
    sget-object v1, Le/e/a/CachePlayback;->workers:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Le/e/a/CachePlayback$$ExternalSyntheticLambda2;

    invoke-direct {v2, v0}, Le/e/a/CachePlayback$$ExternalSyntheticLambda2;-><init>(Ljava/net/Socket;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V
    :try_end_19
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_f .. :try_end_19} :catch_1a
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_19} :catch_1f

    goto :goto_0

    :catch_1a
    move-exception v1

    :try_start_1b
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_1e
    .catch Ljava/io/IOException; {:try_start_1b .. :try_end_1e} :catch_1f

    goto :goto_0

    :catch_1f
    move-exception v0

    goto :goto_8

    :goto_21
    return-void
.end method

.method static synthetic lambda$2(Ljava/net/Socket;)V
    .registers 1

    .line 28
    invoke-static {p0}, Le/e/a/CachePlayback;->serve(Ljava/net/Socket;)V

    return-void
.end method

.method public static parse(Ljava/lang/String;)Landroid/net/Uri;
    .registers 1

    .line 16
    invoke-static {p0}, Le/e/a/CachePlayback;->url(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method private static reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    .registers 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 45
    const/16 v0, 0xc8

    const/16 v1, 0x1a0

    if-ne p1, v0, :cond_9

    const-string v0, "OK"

    goto :goto_1e

    :cond_9
    const/16 v0, 0xce

    if-ne p1, v0, :cond_10

    const-string v0, "Partial Content"

    goto :goto_1e

    :cond_10
    if-ne p1, v1, :cond_15

    const-string v0, "Range Not Satisfiable"

    goto :goto_1e

    :cond_15
    const/16 v0, 0x195

    if-ne p1, v0, :cond_1c

    const-string v0, "Method Not Allowed"

    goto :goto_1e

    :cond_1c
    const-string v0, "Not Found"

    .line 46
    :goto_1e
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "HTTP/1.1 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\r\nContent-Type: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p8

    const-string v0, "\r\nContent-Length: "

    invoke-virtual {p8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p8

    invoke-virtual {p8, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p8

    const-string v0, "\r\nAccept-Ranges: bytes\r\nConnection: close\r\n"

    invoke-virtual {p8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p8

    invoke-virtual {p8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p8

    .line 47
    const-string v0, "\r\n"

    if-eqz p9, :cond_88

    new-instance p9, Ljava/lang/StringBuilder;

    invoke-static {p8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p8

    invoke-direct {p9, p8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p8, "Content-Range: bytes "

    invoke-virtual {p9, p8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p8

    invoke-virtual {p8, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p8

    const-string p9, "-"

    invoke-virtual {p8, p9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p8

    add-long/2addr p2, p4

    const-wide/16 p4, 0x1

    sub-long/2addr p2, p4

    invoke-virtual {p8, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string p3, "/"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p6, p7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p8

    .line 48
    :cond_88
    if-ne p1, v1, :cond_a5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-static {p8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p2, "Content-Range: bytes */"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p6, p7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p8

    .line 49
    :cond_a5
    invoke-virtual {p0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-static {p8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget-object p2, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/io/OutputStream;->write([B)V

    .line 50
    return-void
.end method

.method private static serve(Ljava/net/Socket;)V
    .registers 25

    .line 31
    move-object/from16 v11, p0

    const-string v0, "/"

    const/16 v1, 0x3a98

    :try_start_6
    invoke-virtual {v11, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v3

    sget-object v4, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v2, v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 32
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_264

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v4, 0x1000

    if-le v3, v4, :cond_29

    goto/16 :goto_264

    :cond_29
    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    array-length v3, v2
    :try_end_30
    .catchall {:try_start_6 .. :try_end_30} :catchall_26e

    const/4 v5, 0x3

    if-eq v3, v5, :cond_39

    .line 42
    if-eqz v11, :cond_38

    :try_start_35
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_38
    .catchall {:try_start_35 .. :try_end_38} :catchall_26a

    .line 32
    :cond_38
    return-void

    :cond_39
    const/4 v13, 0x0

    :try_start_3a
    aget-object v3, v2, v13

    const-string v6, "HEAD"

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_64

    aget-object v3, v2, v13

    const-string v6, "GET"

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_64

    const-string v9, "text/plain"

    const/4 v10, 0x0

    const/16 v2, 0x195

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    move-object/from16 v1, p0

    invoke-static/range {v1 .. v10}, Le/e/a/CachePlayback;->reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    :try_end_5e
    .catchall {:try_start_3a .. :try_end_5e} :catchall_26e

    .line 42
    if-eqz v11, :cond_63

    :try_start_60
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_63
    .catchall {:try_start_60 .. :try_end_63} :catchall_26a

    .line 32
    :cond_63
    return-void

    .line 33
    :cond_64
    const/4 v3, 0x0

    const/4 v6, 0x0

    :cond_66
    :goto_66
    :try_start_66
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v7, :cond_9e

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_75

    goto :goto_9e

    :cond_75
    add-int/2addr v3, v9

    const/16 v9, 0x40

    if-gt v3, v9, :cond_98

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v9

    if-le v9, v4, :cond_81

    goto :goto_98

    :cond_81
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "range:"

    invoke-virtual {v9, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_66

    invoke-virtual {v7, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6
    :try_end_97
    .catchall {:try_start_66 .. :try_end_97} :catchall_26e

    goto :goto_66

    .line 42
    :cond_98
    :goto_98
    if-eqz v11, :cond_9d

    :try_start_9a
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_9d
    .catchall {:try_start_9a .. :try_end_9d} :catchall_26a

    .line 33
    :cond_9d
    return-void

    .line 34
    :cond_9e
    :goto_9e
    :try_start_9e
    aget-object v1, v2, v9

    const/4 v15, -0x1

    invoke-virtual {v1, v0, v15}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-ne v2, v3, :cond_b9

    aget-object v2, v1, v5

    const-string v5, "\\?"

    invoke-virtual {v2, v5, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v13

    invoke-static {v2}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_bb

    :cond_b9
    const-string v2, ""

    .line 35
    :goto_bb
    array-length v5, v1

    if-ne v5, v3, :cond_d3

    aget-object v3, v1, v9

    sget-object v5, Le/e/a/CachePlayback;->TOKEN:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_d3

    sget-object v3, Le/e/a/CachePlayback;->roots:Ljava/util/Map;

    aget-object v1, v1, v4

    invoke-interface {v3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_d4

    :cond_d3
    const/4 v1, 0x0

    .line 36
    :goto_d4
    if-eqz v1, :cond_24e

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_24e

    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_24e

    const-string v0, "\\"

    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_24e

    const-string v0, ".."

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f4

    goto/16 :goto_24e

    .line 37
    :cond_f4
    new-instance v0, Le/e/a/CacheFile;

    invoke-direct {v0, v1, v2}, Le/e/a/CacheFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v1

    if-nez v1, :cond_115

    const-string v9, "text/plain"

    const/4 v10, 0x0

    const/16 v2, 0x194

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    move-object/from16 v1, p0

    invoke-static/range {v1 .. v10}, Le/e/a/CachePlayback;->reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    :try_end_10f
    .catchall {:try_start_9e .. :try_end_10f} :catchall_26e

    .line 42
    if-eqz v11, :cond_114

    :try_start_111
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_114
    .catchall {:try_start_111 .. :try_end_114} :catchall_26a

    .line 37
    :cond_114
    return-void

    .line 38
    :cond_115
    :try_start_115
    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v16
    :try_end_119
    .catchall {:try_start_115 .. :try_end_119} :catchall_26e

    const-wide/16 v18, 0x1

    sub-long v9, v16, v18

    .line 39
    const/16 v3, 0xce

    const-wide/16 v12, 0x0

    if-eqz v6, :cond_1b7

    :try_start_123
    const-string v5, "bytes="

    invoke-virtual {v6, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_19a

    const-string v5, ","

    invoke-virtual {v6, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_19a

    invoke-virtual {v6, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    const-string v6, "-"

    invoke-virtual {v5, v6, v15}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v5

    array-length v6, v5

    if-ne v6, v4, :cond_194

    const/4 v4, 0x0

    aget-object v6, v5, v4

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_162

    const/4 v1, 0x1

    aget-object v4, v5, v1

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    cmp-long v6, v4, v12

    if-lez v6, :cond_15c

    sub-long v4, v16, v4

    invoke-static {v12, v13, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    const/4 v1, 0x1

    goto :goto_17d

    :cond_15c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    :goto_161
    throw v0

    :cond_162
    const/4 v4, 0x0

    aget-object v6, v5, v4

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v1, 0x1

    aget-object v4, v5, v1

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_17c

    aget-object v4, v5, v1

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    invoke-static {v9, v10, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v9

    :cond_17c
    move-wide v4, v6

    :goto_17d
    cmp-long v6, v4, v12

    if-ltz v6, :cond_18e

    cmp-long v6, v4, v16

    if-gez v6, :cond_18e

    cmp-long v6, v9, v4

    if-ltz v6, :cond_18e

    move-wide/from16 v20, v4

    const/16 v4, 0xce

    goto :goto_1bc

    :cond_18e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    goto :goto_161

    :cond_194
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    goto :goto_161

    :cond_19a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V
    :try_end_19f
    .catch Ljava/lang/RuntimeException; {:try_start_123 .. :try_end_19f} :catch_1a0
    .catchall {:try_start_123 .. :try_end_19f} :catchall_26e

    goto :goto_161

    :catch_1a0
    move-exception v0

    :try_start_1a1
    const-string v9, "text/plain"

    const/4 v10, 0x0

    const/16 v2, 0x1a0

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    move-object/from16 v1, p0

    move-wide/from16 v7, v16

    invoke-static/range {v1 .. v10}, Le/e/a/CachePlayback;->reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    :try_end_1b1
    .catchall {:try_start_1a1 .. :try_end_1b1} :catchall_26e

    .line 42
    if-eqz v11, :cond_1b6

    :try_start_1b3
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_1b6
    .catchall {:try_start_1b3 .. :try_end_1b6} :catchall_26a

    .line 39
    :cond_1b6
    return-void

    :cond_1b7
    const/4 v1, 0x1

    const/16 v4, 0xc8

    move-wide/from16 v20, v12

    .line 40
    :goto_1bc
    sub-long v9, v9, v20

    add-long v9, v9, v18

    :try_start_1c0
    invoke-static {v12, v13, v9, v10}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v22

    invoke-static {v2}, Le/e/a/CacheFolders;->mime(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-ne v4, v3, :cond_1cc

    const/4 v10, 0x1

    goto :goto_1cd

    :cond_1cc
    const/4 v10, 0x0

    :goto_1cd
    move-object/from16 v1, p0

    move v2, v4

    move-wide/from16 v3, v20

    move-wide/from16 v5, v22

    move-wide/from16 v7, v16

    invoke-static/range {v1 .. v10}, Le/e/a/CachePlayback;->reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    :try_end_1d9
    .catchall {:try_start_1c0 .. :try_end_1d9} :catchall_26e

    .line 41
    if-eqz v14, :cond_1e1

    .line 42
    if-eqz v11, :cond_1e0

    :try_start_1dd
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_1e0
    .catchall {:try_start_1dd .. :try_end_1e0} :catchall_26a

    .line 41
    :cond_1e0
    return-void

    :cond_1e1
    :try_start_1e1
    new-instance v1, Le/e/a/CacheInputStream;

    invoke-direct {v1, v0}, Le/e/a/CacheInputStream;-><init>(Ljava/io/File;)V
    :try_end_1e6
    .catchall {:try_start_1e1 .. :try_end_1e6} :catchall_242

    move-wide/from16 v2, v20

    :goto_1e8
    cmp-long v0, v2, v12

    if-gtz v0, :cond_220

    const/high16 v0, 0x10000

    :try_start_1ee
    new-array v2, v0, [B

    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    move-wide/from16 v4, v22

    :goto_1f6
    cmp-long v6, v4, v12

    if-gtz v6, :cond_207

    invoke-virtual {v3}, Ljava/io/OutputStream;->flush()V
    :try_end_1fd
    .catchall {:try_start_1ee .. :try_end_1fd} :catchall_23a

    :try_start_1fd
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_200
    .catchall {:try_start_1fd .. :try_end_200} :catchall_242

    .line 42
    if-eqz v11, :cond_28b

    :try_start_202
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_205
    .catchall {:try_start_202 .. :try_end_205} :catchall_26a

    goto/16 :goto_28b

    .line 41
    :cond_207
    int-to-long v6, v0

    :try_start_208
    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    long-to-int v7, v6

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v6, v7}, Ljava/io/InputStream;->read([BII)I

    move-result v7

    if-ltz v7, :cond_21a

    invoke-virtual {v3, v2, v6, v7}, Ljava/io/OutputStream;->write([BII)V

    int-to-long v7, v7

    sub-long/2addr v4, v7

    goto :goto_1f6

    :cond_21a
    new-instance v0, Ljava/io/EOFException;

    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    :goto_21f
    throw v0

    :cond_220
    const/4 v6, 0x0

    invoke-virtual {v1, v2, v3}, Ljava/io/InputStream;->skip(J)J

    move-result-wide v4

    cmp-long v0, v4, v12

    if-gtz v0, :cond_238

    invoke-virtual {v1}, Ljava/io/InputStream;->read()I

    move-result v0

    if-eq v0, v15, :cond_232

    move-wide/from16 v4, v18

    goto :goto_238

    :cond_232
    new-instance v0, Ljava/io/EOFException;

    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V
    :try_end_237
    .catchall {:try_start_208 .. :try_end_237} :catchall_23a

    goto :goto_21f

    :cond_238
    :goto_238
    sub-long/2addr v2, v4

    goto :goto_1e8

    :catchall_23a
    move-exception v0

    move-object v12, v0

    :try_start_23c
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    throw v12
    :try_end_240
    .catchall {:try_start_23c .. :try_end_240} :catchall_240

    :catchall_240
    move-exception v0

    goto :goto_244

    :catchall_242
    move-exception v0

    const/4 v12, 0x0

    :goto_244
    if-eqz v12, :cond_24c

    if-eq v12, v0, :cond_24d

    :try_start_248
    invoke-virtual {v12, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_24d

    :cond_24c
    move-object v12, v0

    :cond_24d
    :goto_24d
    throw v12

    .line 36
    :cond_24e
    :goto_24e
    const-string v9, "text/plain"

    const/4 v10, 0x0

    const/16 v2, 0x194

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    move-object/from16 v1, p0

    invoke-static/range {v1 .. v10}, Le/e/a/CachePlayback;->reply(Ljava/net/Socket;IJJJLjava/lang/String;Z)V
    :try_end_25e
    .catchall {:try_start_248 .. :try_end_25e} :catchall_26e

    .line 42
    if-eqz v11, :cond_263

    :try_start_260
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V

    .line 36
    :cond_263
    return-void

    .line 42
    :cond_264
    :goto_264
    if-eqz v11, :cond_26d

    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V
    :try_end_269
    .catchall {:try_start_260 .. :try_end_269} :catchall_26a

    goto :goto_26d

    :catchall_26a
    move-exception v0

    const/4 v12, 0x0

    goto :goto_277

    .line 32
    :cond_26d
    :goto_26d
    return-void

    .line 42
    :catchall_26e
    move-exception v0

    move-object v12, v0

    if-eqz v11, :cond_275

    :try_start_272
    invoke-virtual/range {p0 .. p0}, Ljava/net/Socket;->close()V

    :cond_275
    throw v12
    :try_end_276
    .catchall {:try_start_272 .. :try_end_276} :catchall_276

    :catchall_276
    move-exception v0

    :goto_277
    if-eqz v12, :cond_27f

    if-eq v12, v0, :cond_280

    :try_start_27b
    invoke-virtual {v12, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_280

    :cond_27f
    move-object v12, v0

    :cond_280
    :goto_280
    throw v12
    :try_end_281
    .catch Ljava/io/IOException; {:try_start_27b .. :try_end_281} :catch_283
    .catch Ljava/lang/RuntimeException; {:try_start_27b .. :try_end_281} :catch_281

    :catch_281
    move-exception v0

    goto :goto_284

    :catch_283
    move-exception v0

    :goto_284
    const-string v0, "nicoid-cache"

    const-string v1, "Cached playback request failed"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    :cond_28b
    :goto_28b
    return-void
.end method

.method private static declared-synchronized start()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-class v0, Le/e/a/CachePlayback;

    monitor-enter v0

    .line 27
    :try_start_3
    sget-object v1, Le/e/a/CachePlayback;->server:Ljava/net/ServerSocket;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_2e

    if-eqz v1, :cond_9

    monitor-exit v0

    return-void

    :cond_9
    :try_start_9
    new-instance v1, Ljava/net/ServerSocket;

    const-string v2, "127.0.0.1"

    invoke-static {v2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v2

    const/4 v3, 0x0

    const/16 v4, 0x8

    invoke-direct {v1, v3, v4, v2}, Ljava/net/ServerSocket;-><init>(IILjava/net/InetAddress;)V

    sput-object v1, Le/e/a/CachePlayback;->server:Ljava/net/ServerSocket;

    .line 28
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Le/e/a/CachePlayback$$ExternalSyntheticLambda0;

    invoke-direct {v2}, Le/e/a/CachePlayback$$ExternalSyntheticLambda0;-><init>()V

    const-string v3, "nicoid-cache-server"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V
    :try_end_2c
    .catchall {:try_start_9 .. :try_end_2c} :catchall_2e

    .line 29
    monitor-exit v0

    return-void

    .line 26
    :catchall_2e
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public static url(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 20
    if-nez p0, :cond_4

    const/4 p0, 0x0

    return-object p0

    :cond_4
    invoke-static {p0}, Le/e/a/PlaybackUrls;->directHls(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "file://"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    goto :goto_1a

    :cond_19
    move-object v0, p0

    .line 21
    :goto_1a
    if-eqz v0, :cond_95

    const-string v1, "/@nicoid-cache/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const-string v2, "/"

    if-nez v1, :cond_35

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_95

    const-string v1, "/nicoid/nicoid_cache/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_35

    goto :goto_95

    .line 22
    :cond_35
    new-instance p0, Le/e/a/CacheFile;

    invoke-direct {p0, v0}, Le/e/a/CacheFile;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-static {v1}, Ljava/util/UUID;->nameUUIDFromBytes([B)Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v3, Le/e/a/CachePlayback;->roots:Ljava/util/Map;

    invoke-interface {v3, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    :try_start_51
    invoke-static {}, Le/e/a/CachePlayback;->start()V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "http://127.0.0.1:"

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Le/e/a/CachePlayback;->server:Ljava/net/ServerSocket;

    invoke-virtual {v3}, Ljava/net/ServerSocket;->getLocalPort()I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v3, Le/e/a/CachePlayback;->TOKEN:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_8b
    .catch Ljava/io/IOException; {:try_start_51 .. :try_end_8b} :catch_8c

    return-object p0

    .line 24
    :catch_8c
    move-exception p0

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot open cache player"

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    .line 21
    :cond_95
    :goto_95
    return-object p0
.end method
