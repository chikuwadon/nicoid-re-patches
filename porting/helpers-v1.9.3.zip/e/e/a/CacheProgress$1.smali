.class Le/e/a/CacheProgress$1;
.super Ljava/lang/Object;
.source "CacheProgress.java"

# interfaces
.implements Le/e/a/CacheTransferPlan$Fetch;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le/e/a/CacheProgress;->measure(Ljava/lang/String;Ljava/lang/Object;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$cookie:Ljava/lang/String;

.field private final synthetic val$session:I


# direct methods
.method constructor <init>(ILjava/lang/String;)V
    .registers 3

    .line 55
    iput p1, p0, Le/e/a/CacheProgress$1;->val$session:I

    iput-object p2, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public assets(I)V
    .registers 4

    .line 55
    iget v0, p0, Le/e/a/CacheProgress$1;->val$session:I

    # getter for: Le/e/a/CacheProgress;->generation:I
    invoke-static {}, Le/e/a/CacheProgress;->access$7()I

    move-result v1

    if-ne v0, v1, :cond_b

    invoke-static {p1}, Le/e/a/CacheProgress;->access$8(I)V

    :cond_b
    return-void
.end method

.method public length(Ljava/net/URL;)J
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 65
    iget v0, p0, Le/e/a/CacheProgress$1;->val$session:I

    # getter for: Le/e/a/CacheProgress;->generation:I
    invoke-static {}, Le/e/a/CacheProgress;->access$7()I

    move-result v1

    if-ne v0, v1, :cond_95

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v0

    if-nez v0, :cond_95

    .line 66
    const-string v0, "https"

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8d

    .line 67
    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    .line 68
    const/16 v0, 0x1f40

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 69
    const-string v0, "Range"

    const-string v1, "bytes=0-0"

    invoke-virtual {p1, v0, v1}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    iget-object v0, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    if-eqz v0, :cond_46

    iget-object v0, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_46

    const-string v0, "Cookie"

    iget-object v1, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    :cond_46
    :try_start_46
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const-wide/16 v1, -0x1

    const/16 v3, 0xc8

    if-lt v0, v3, :cond_84

    const/16 v4, 0x12c

    if-lt v0, v4, :cond_55

    goto :goto_84

    .line 72
    :cond_55
    const-string v4, "Content-Range"

    invoke-virtual {p1, v4}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_7a

    const-string v5, "/"

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_63
    .catchall {:try_start_46 .. :try_end_63} :catchall_88

    if-eqz v5, :cond_7a

    const/16 v5, 0x2f

    :try_start_67
    invoke-virtual {v4, v5}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v5

    add-int/lit8 v5, v5, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_75
    .catch Ljava/lang/NumberFormatException; {:try_start_67 .. :try_end_75} :catch_79
    .catchall {:try_start_67 .. :try_end_75} :catchall_88

    .line 74
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-wide v0

    .line 72
    :catch_79
    move-exception v4

    .line 73
    :cond_7a
    if-ne v0, v3, :cond_80

    :try_start_7c
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getContentLengthLong()J

    move-result-wide v1
    :try_end_80
    .catchall {:try_start_7c .. :try_end_80} :catchall_88

    .line 74
    :cond_80
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 73
    return-wide v1

    .line 74
    :cond_84
    :goto_84
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 71
    return-wide v1

    .line 74
    :catchall_88
    move-exception v0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0

    .line 66
    :cond_8d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid media URL"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 65
    :cond_95
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1
.end method

.method public text(Ljava/net/URL;)Ljava/lang/String;
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 56
    iget v0, p0, Le/e/a/CacheProgress$1;->val$session:I

    # getter for: Le/e/a/CacheProgress;->generation:I
    invoke-static {}, Le/e/a/CacheProgress;->access$7()I

    move-result v1

    if-ne v0, v1, :cond_a9

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v0

    if-nez v0, :cond_a9

    .line 57
    const-string v0, "https"

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a1

    .line 58
    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/16 v0, 0x1f40

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 59
    iget-object v0, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    if-eqz v0, :cond_3f

    iget-object v0, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3f

    const-string v0, "Cookie"

    iget-object v1, p0, Le/e/a/CacheProgress$1;->val$cookie:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    :cond_3f
    const/4 v0, 0x0

    :try_start_40
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1
    :try_end_44
    .catchall {:try_start_40 .. :try_end_44} :catchall_91

    :try_start_44
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_49
    .catchall {:try_start_44 .. :try_end_49} :catchall_81

    .line 61
    const/16 v3, 0x2000

    :try_start_4b
    new-array v3, v3, [B

    :goto_4d
    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_66

    const-string v3, "UTF-8"

    invoke-virtual {v2, v3}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_5a
    .catchall {:try_start_4b .. :try_end_5a} :catchall_7c

    .line 62
    :try_start_5a
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5d
    .catchall {:try_start_5a .. :try_end_5d} :catchall_81

    if-eqz v1, :cond_62

    :try_start_5f
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_62
    .catchall {:try_start_5f .. :try_end_62} :catchall_91

    :cond_62
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object v3

    .line 61
    :cond_66
    :try_start_66
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v5

    add-int/2addr v5, v4

    const/high16 v6, 0x400000

    if-gt v5, v6, :cond_74

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v5, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_4d

    :cond_74
    new-instance v0, Ljava/io/IOException;

    const-string v3, "Playlist too large"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_7c
    .catchall {:try_start_66 .. :try_end_7c} :catchall_7c

    .line 62
    :catchall_7c
    move-exception v0

    :try_start_7d
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V

    throw v0
    :try_end_81
    .catchall {:try_start_7d .. :try_end_81} :catchall_81

    :catchall_81
    move-exception v2

    if-nez v0, :cond_86

    move-object v0, v2

    goto :goto_8b

    :cond_86
    if-eq v0, v2, :cond_8b

    :try_start_88
    invoke-virtual {v0, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_8b
    :goto_8b
    if-eqz v1, :cond_90

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    :cond_90
    throw v0
    :try_end_91
    .catchall {:try_start_88 .. :try_end_91} :catchall_91

    :catchall_91
    move-exception v1

    if-eqz v0, :cond_9a

    if-eq v0, v1, :cond_9b

    :try_start_96
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_9b

    :cond_9a
    move-object v0, v1

    :cond_9b
    :goto_9b
    throw v0
    :try_end_9c
    .catchall {:try_start_96 .. :try_end_9c} :catchall_9c

    :catchall_9c
    move-exception v0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0

    .line 57
    :cond_a1
    new-instance p1, Ljava/io/IOException;

    const-string v0, "Invalid media URL"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 56
    :cond_a9
    new-instance p1, Ljava/io/InterruptedIOException;

    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    throw p1
.end method
