.class public final synthetic Le/e/a/CacheRetry$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/CacheRetry$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Le/e/a/CacheRetry$$ExternalSyntheticLambda3;->f$0:Landroid/app/Activity;

    invoke-static {v0}, Le/e/a/CacheRetry;->lambda$3(Landroid/app/Activity;)V

    return-void
.end method
