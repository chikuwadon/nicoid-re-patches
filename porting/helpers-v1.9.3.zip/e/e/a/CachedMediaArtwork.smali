.class public final Le/e/a/CachedMediaArtwork;
.super Ljava/lang/Object;
.source "CachedMediaArtwork.java"


# static fields
.field private static final ART:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private static final CURRENT:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/media/session/MediaSession;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private static final MAIN:Landroid/os/Handler;

.field private static final WORKER:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 20
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Le/e/a/CachedMediaArtwork;->MAIN:Landroid/os/Handler;

    .line 21
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Le/e/a/CachedMediaArtwork;->WORKER:Ljava/util/concurrent/ExecutorService;

    .line 22
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    .line 23
    new-instance v0, Le/e/a/CachedMediaArtwork$1;

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v2, 0x1

    const/16 v3, 0x8

    invoke-direct {v0, v3, v1, v2}, Le/e/a/CachedMediaArtwork$1;-><init>(IFZ)V

    sput-object v0, Le/e/a/CachedMediaArtwork;->ART:Ljava/util/Map;

    .line 25
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 62
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$0(Ljava/lang/String;Landroid/media/session/MediaSession;Ljava/lang/Object;Landroid/media/MediaMetadata;Ljava/lang/String;)V
    .registers 12

    .line 39
    const/4 v0, 0x0

    if-nez p0, :cond_5

    move-object p0, v0

    goto :goto_9

    :cond_5
    invoke-static {p0}, Le/e/a/CachedMediaArtwork;->read(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    .line 40
    :goto_9
    if-eqz p0, :cond_17

    .line 41
    nop

    .line 42
    sget-object p4, Le/e/a/CachedMediaArtwork;->MAIN:Landroid/os/Handler;

    new-instance v0, Le/e/a/CachedMediaArtwork$$ExternalSyntheticLambda1;

    invoke-direct {v0, p1, p2, p3, p0}, Le/e/a/CachedMediaArtwork$$ExternalSyntheticLambda1;-><init>(Landroid/media/session/MediaSession;Ljava/lang/Object;Landroid/media/MediaMetadata;Landroid/graphics/Bitmap;)V

    invoke-virtual {p4, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_5f

    .line 51
    :cond_17
    if-eqz p4, :cond_5f

    invoke-virtual {p4}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_5f

    .line 52
    sget-object p0, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    monitor-enter p0

    :try_start_22
    sget-object v1, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-eq v1, p2, :cond_2c

    monitor-exit p0

    return-void

    :cond_2c
    monitor-exit p0
    :try_end_2d
    .catchall {:try_start_22 .. :try_end_2d} :catchall_5c

    .line 55
    :try_start_2d
    const-string p0, "e.e.a.FeedbackMedia"

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const-string p2, "lambda$apply$1"

    const/4 v1, 0x3

    new-array v2, v1, [Ljava/lang/Class;

    const-class v3, Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-class v3, Landroid/media/session/MediaSession;

    const/4 v5, 0x1

    aput-object v3, v2, v5

    const-class v3, Landroid/media/MediaMetadata;

    const/4 v6, 0x2

    aput-object v3, v2, v6

    invoke-virtual {p0, p2, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    .line 56
    invoke-virtual {p0, v5}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    new-array p2, v1, [Ljava/lang/Object;

    aput-object p4, p2, v4

    aput-object p1, p2, v5

    aput-object p3, p2, v6

    invoke-virtual {p0, v0, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_59
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_59} :catch_5a

    goto :goto_5b

    .line 57
    :catch_5a
    move-exception p0

    :goto_5b
    goto :goto_60

    .line 52
    :catchall_5c
    move-exception p1

    :try_start_5d
    monitor-exit p0
    :try_end_5e
    .catchall {:try_start_5d .. :try_end_5e} :catchall_5c

    throw p1

    .line 51
    :cond_5f
    :goto_5f
    nop

    .line 59
    :goto_60
    return-void
.end method

.method static synthetic lambda$1(Landroid/media/session/MediaSession;Ljava/lang/Object;Landroid/media/MediaMetadata;Landroid/graphics/Bitmap;)V
    .registers 6

    .line 43
    sget-object v0, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    monitor-enter v0

    :try_start_3
    sget-object v1, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-eq v1, p1, :cond_d

    monitor-exit v0

    return-void

    :cond_d
    monitor-exit v0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_2b

    .line 45
    :try_start_e
    new-instance p1, Landroid/media/MediaMetadata$Builder;

    invoke-direct {p1, p2}, Landroid/media/MediaMetadata$Builder;-><init>(Landroid/media/MediaMetadata;)V

    .line 46
    const-string p2, "android.media.metadata.ART"

    invoke-virtual {p1, p2, p3}, Landroid/media/MediaMetadata$Builder;->putBitmap(Ljava/lang/String;Landroid/graphics/Bitmap;)Landroid/media/MediaMetadata$Builder;

    move-result-object p1

    .line 47
    const-string p2, "android.media.metadata.ALBUM_ART"

    invoke-virtual {p1, p2, p3}, Landroid/media/MediaMetadata$Builder;->putBitmap(Ljava/lang/String;Landroid/graphics/Bitmap;)Landroid/media/MediaMetadata$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/MediaMetadata$Builder;->build()Landroid/media/MediaMetadata;

    move-result-object p1

    .line 45
    nop

    .line 48
    invoke-virtual {p0, p1}, Landroid/media/session/MediaSession;->setMetadata(Landroid/media/MediaMetadata;)V
    :try_end_27
    .catch Ljava/lang/RuntimeException; {:try_start_e .. :try_end_27} :catch_28

    goto :goto_29

    .line 49
    :catch_28
    move-exception p0

    :goto_29
    nop

    .line 50
    return-void

    .line 43
    :catchall_2b
    move-exception p0

    :try_start_2c
    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_2c .. :try_end_2d} :catchall_2b

    throw p0
.end method

.method static read(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 9

    .line 64
    sget-object v0, Le/e/a/CachedMediaArtwork;->ART:Ljava/util/Map;

    monitor-enter v0

    :try_start_3
    sget-object v1, Le/e/a/CachedMediaArtwork;->ART:Ljava/util/Map;

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Bitmap;

    if-eqz v1, :cond_15

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v2

    if-nez v2, :cond_15

    monitor-exit v0

    return-object v1

    :cond_15
    monitor-exit v0
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_89

    .line 65
    const/4 v0, 0x0

    :try_start_17
    new-instance v1, Le/e/a/CacheInputStream;

    new-instance v2, Le/e/a/CacheFile;

    invoke-direct {v2, p0}, Le/e/a/CacheFile;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v2}, Le/e/a/CacheInputStream;-><init>(Ljava/io/File;)V
    :try_end_21
    .catchall {:try_start_17 .. :try_end_21} :catchall_7c

    .line 66
    :try_start_21
    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v2
    :try_end_25
    .catchall {:try_start_21 .. :try_end_25} :catchall_72

    if-nez v2, :cond_2b

    .line 70
    :try_start_27
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_2a
    .catchall {:try_start_27 .. :try_end_2a} :catchall_7c

    .line 66
    return-object v0

    .line 67
    :cond_2b
    :try_start_2b
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 68
    const/16 v4, 0x280

    if-le v3, v4, :cond_62

    const/high16 v4, 0x44200000    # 640.0f

    int-to-float v3, v3

    div-float/2addr v4, v3

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    int-to-float v3, v3

    mul-float v3, v3, v4

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    const/4 v5, 0x1

    invoke-static {v5, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v6

    int-to-float v6, v6

    mul-float v6, v6, v4

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static {v2, v3, v4, v5}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 69
    :cond_62
    sget-object v3, Le/e/a/CachedMediaArtwork;->ART:Ljava/util/Map;

    monitor-enter v3
    :try_end_65
    .catchall {:try_start_2b .. :try_end_65} :catchall_72

    :try_start_65
    sget-object v4, Le/e/a/CachedMediaArtwork;->ART:Ljava/util/Map;

    invoke-interface {v4, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v3
    :try_end_6b
    .catchall {:try_start_65 .. :try_end_6b} :catchall_6f

    .line 70
    :try_start_6b
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_6e
    .catchall {:try_start_6b .. :try_end_6e} :catchall_7c

    return-object v2

    .line 69
    :catchall_6f
    move-exception p0

    :try_start_70
    monitor-exit v3
    :try_end_71
    .catchall {:try_start_70 .. :try_end_71} :catchall_6f

    :try_start_71
    throw p0
    :try_end_72
    .catchall {:try_start_71 .. :try_end_72} :catchall_72

    .line 70
    :catchall_72
    move-exception p0

    :try_start_73
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    throw p0
    :try_end_77
    .catchall {:try_start_73 .. :try_end_77} :catchall_77

    :catchall_77
    move-exception v1

    move-object v7, v1

    move-object v1, p0

    move-object p0, v7

    goto :goto_7e

    :catchall_7c
    move-exception p0

    move-object v1, v0

    :goto_7e
    if-eqz v1, :cond_86

    if-eq v1, p0, :cond_85

    :try_start_82
    invoke-virtual {v1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_85
    move-object p0, v1

    :cond_86
    throw p0
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_82 .. :try_end_87} :catch_87

    :catch_87
    move-exception p0

    return-object v0

    .line 64
    :catchall_89
    move-exception p0

    :try_start_8a
    monitor-exit v0
    :try_end_8b
    .catchall {:try_start_8a .. :try_end_8b} :catchall_89

    throw p0
.end method

.method public static request(Landroid/media/session/MediaSession;Landroid/media/MediaMetadata;Ljava/lang/Object;Ljava/lang/String;)V
    .registers 11

    .line 28
    new-instance v3, Ljava/lang/Object;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 29
    sget-object v0, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    monitor-enter v0

    :try_start_8
    sget-object v1, Le/e/a/CachedMediaArtwork;->CURRENT:Ljava/util/Map;

    invoke-interface {v1, p0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0
    :try_end_e
    .catchall {:try_start_8 .. :try_end_e} :catchall_77

    .line 30
    const-string v0, "android.media.metadata.ART"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_17

    return-void

    .line 31
    :cond_17
    nop

    .line 33
    :try_start_18
    instance-of v0, p2, Landroid/content/Context;

    if-eqz v0, :cond_20

    move-object v0, p2

    check-cast v0, Landroid/content/Context;

    goto :goto_28

    :cond_20
    const-string v0, "A1"

    invoke-static {p2, v0}, Le/e/a/CachedMediaArtwork;->field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    .line 34
    :goto_28
    instance-of v1, p2, Landroid/content/Context;

    if-eqz v1, :cond_2f

    const-string v1, "f"

    goto :goto_31

    :cond_2f
    const-string v1, "b0"

    :goto_31
    invoke-static {p2, v1}, Le/e/a/CachedMediaArtwork;->field(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    .line 35
    const-string v1, "(?:sm|so|nm|ss)[0-9]+"

    invoke-virtual {p2, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_65

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-static {v0}, Le/e/a/CacheFolders;->root(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, "/nicoid/nicoid_cache/"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, ".thm"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_62} :catch_64

    .line 36
    move-object v1, p2

    goto :goto_67

    :catch_64
    move-exception p2

    .line 37
    :cond_65
    const/4 p2, 0x0

    move-object v1, p2

    :goto_67
    nop

    .line 38
    sget-object p2, Le/e/a/CachedMediaArtwork;->WORKER:Ljava/util/concurrent/ExecutorService;

    new-instance v6, Le/e/a/CachedMediaArtwork$$ExternalSyntheticLambda0;

    move-object v0, v6

    move-object v2, p0

    move-object v4, p1

    move-object v5, p3

    invoke-direct/range {v0 .. v5}, Le/e/a/CachedMediaArtwork$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;Landroid/media/session/MediaSession;Ljava/lang/Object;Landroid/media/MediaMetadata;Ljava/lang/String;)V

    invoke-interface {p2, v6}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 60
    return-void

    .line 29
    :catchall_77
    move-exception p0

    :try_start_78
    monitor-exit v0
    :try_end_79
    .catchall {:try_start_78 .. :try_end_79} :catchall_77

    throw p0
.end method
