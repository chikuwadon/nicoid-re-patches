.class final Le/e/a/CastRelay$Session;
.super Ljava/lang/Object;
.source "CastRelay.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/CastRelay;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Session"
.end annotation


# instance fields
.field volatile closed:Z

.field final connections:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/net/HttpURLConnection;",
            ">;"
        }
    .end annotation
.end field

.field final hls:Le/e/a/CastHls;

.field final master:Ljava/net/URL;

.field final sockets:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/net/Socket;",
            ">;"
        }
    .end annotation
.end field

.field final workers:Ljava/util/concurrent/ThreadPoolExecutor;


# direct methods
.method constructor <init>(Ljava/net/URL;Ljava/lang/String;)V
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 57
    new-instance v7, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 58
    new-instance v6, Ljava/util/concurrent/ArrayBlockingQueue;

    const/16 v0, 0x10

    invoke-direct {v6, v0}, Ljava/util/concurrent/ArrayBlockingQueue;-><init>(I)V

    .line 57
    const/4 v1, 0x4

    const/4 v2, 0x4

    const-wide/16 v3, 0x1e

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V

    iput-object v7, p0, Le/e/a/CastRelay$Session;->workers:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 59
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    .line 60
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Le/e/a/CastRelay$Session;->connections:Ljava/util/Set;

    .line 63
    invoke-static {p1}, Le/e/a/CastHls;->validate(Ljava/net/URL;)V

    iput-object p1, p0, Le/e/a/CastRelay$Session;->master:Ljava/net/URL;

    new-instance p1, Le/e/a/CastHls;

    invoke-direct {p1, p2}, Le/e/a/CastHls;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Le/e/a/CastRelay$Session;->hls:Le/e/a/CastHls;

    .line 64
    iget-object p1, p0, Le/e/a/CastRelay$Session;->workers:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    .line 65
    return-void
.end method

.method private release(Ljava/net/HttpURLConnection;)V
    .registers 3

    .line 179
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Le/e/a/CastRelay$Session;->connections:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_b

    .line 180
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 181
    return-void

    .line 179
    :catchall_b
    move-exception p1

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw p1
.end method

.method private serve(Ljava/lang/Object;Ljava/net/Socket;)V
    .registers 24

    .line 80
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    const/4 v3, 0x0

    :try_start_5
    new-instance v4, Ljava/io/BufferedOutputStream;

    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-direct {v4, v0}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_e
    .catchall {:try_start_5 .. :try_end_e} :catchall_1d1

    .line 81
    const/16 v0, 0x3a98

    :try_start_10
    invoke-virtual {v2, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 82
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v5, Ljava/io/InputStreamReader;

    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v6

    sget-object v7, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v5, v6, v7}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v0, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 83
    # invokes: Le/e/a/CastRelay;->line(Ljava/io/BufferedReader;)Ljava/lang/String;
    invoke-static {v0}, Le/e/a/CastRelay;->access$1(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v5

    .line 84
    const/4 v6, 0x0

    if-nez v5, :cond_2d

    new-array v7, v6, [Ljava/lang/String;

    goto :goto_33

    :cond_2d
    const-string v7, " "

    invoke-virtual {v5, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    .line 85
    :goto_33
    array-length v8, v7

    const/4 v9, 0x3

    const-wide/16 v10, 0x0

    if-eq v8, v9, :cond_51

    const/16 v0, 0x190

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v0, v3, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_3e
    .catchall {:try_start_10 .. :try_end_3e} :catchall_1cb

    .line 109
    :try_start_3e
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_41
    .catchall {:try_start_3e .. :try_end_41} :catchall_1d1

    if-eqz v2, :cond_46

    :try_start_43
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_46
    .catchall {:try_start_43 .. :try_end_46} :catchall_1dc

    .line 110
    :cond_46
    monitor-enter p0

    :try_start_47
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 85
    return-void

    .line 110
    :catchall_4e
    move-exception v0

    monitor-exit p0
    :try_end_50
    .catchall {:try_start_47 .. :try_end_50} :catchall_4e

    throw v0

    .line 86
    :cond_51
    :try_start_51
    aget-object v8, v7, v6

    const/4 v9, 0x1

    aget-object v7, v7, v9

    .line 87
    const/16 v12, 0x3f

    invoke-virtual {v7, v12}, Ljava/lang/String;->indexOf(I)I

    move-result v13

    if-ltz v13, :cond_66

    invoke-virtual {v7, v12}, Ljava/lang/String;->indexOf(I)I

    move-result v12

    invoke-virtual {v7, v6, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    .line 88
    :cond_66
    new-instance v12, Ljava/lang/StringBuilder;

    const-string v13, "Cast relay: "

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v13, "OPTIONS"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_78

    const-string v13, "preflight request"

    goto :goto_90

    :cond_78
    const-string v13, "HEAD"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_83

    const-string v13, "metadata request"

    goto :goto_90

    :cond_83
    const-string v13, "GET"

    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_8e

    const-string v13, "media request"

    goto :goto_90

    :cond_8e
    const-string v13, "unsupported request"

    :goto_90
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Le/e/a/CastDiagnostics;->record(Ljava/lang/String;)V

    .line 89
    const-string v12, "HEAD"

    invoke-virtual {v12, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    .line 90
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    .line 91
    move-object v13, v3

    :goto_a6
    # invokes: Le/e/a/CastRelay;->line(Ljava/io/BufferedReader;)Ljava/lang/String;
    invoke-static {v0}, Le/e/a/CastRelay;->access$1(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v15

    if-eqz v15, :cond_e6

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_b3

    goto :goto_e6

    .line 92
    :cond_b3
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v14

    add-int/2addr v5, v14

    const v14, 0x8000

    if-gt v5, v14, :cond_de

    .line 93
    const-string v17, "Range:"

    const/16 v18, 0x0

    const/16 v19, 0x6

    const/16 v16, 0x1

    const/16 v20, 0x0

    move-object v14, v15

    move-object v6, v15

    move/from16 v15, v16

    move/from16 v16, v20

    invoke-virtual/range {v14 .. v19}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    move-result v14

    if-eqz v14, :cond_dc

    const/4 v13, 0x6

    invoke-virtual {v6, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    :cond_dc
    const/4 v6, 0x0

    goto :goto_a6

    .line 92
    :cond_de
    new-instance v0, Ljava/io/IOException;

    const-string v3, "Oversized Cast request"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 95
    :cond_e6
    :goto_e6
    const-string v0, "OPTIONS"

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_106

    const/16 v0, 0xcc

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v0, v3, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_f3
    .catchall {:try_start_51 .. :try_end_f3} :catchall_1cb

    .line 109
    :try_start_f3
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_f6
    .catchall {:try_start_f3 .. :try_end_f6} :catchall_1d1

    if-eqz v2, :cond_fb

    :try_start_f8
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_fb
    .catchall {:try_start_f8 .. :try_end_fb} :catchall_1dc

    .line 110
    :cond_fb
    monitor-enter p0

    :try_start_fc
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 95
    return-void

    .line 110
    :catchall_103
    move-exception v0

    monitor-exit p0
    :try_end_105
    .catchall {:try_start_fc .. :try_end_105} :catchall_103

    throw v0

    .line 96
    :cond_106
    if-nez v12, :cond_128

    :try_start_108
    const-string v0, "GET"

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_128

    const/16 v0, 0x195

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v0, v3, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_115
    .catchall {:try_start_108 .. :try_end_115} :catchall_1cb

    .line 109
    :try_start_115
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_118
    .catchall {:try_start_115 .. :try_end_118} :catchall_1d1

    if-eqz v2, :cond_11d

    :try_start_11a
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_11d
    .catchall {:try_start_11a .. :try_end_11d} :catchall_1dc

    .line 110
    :cond_11d
    monitor-enter p0

    :try_start_11e
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 96
    return-void

    .line 110
    :catchall_125
    move-exception v0

    monitor-exit p0
    :try_end_127
    .catchall {:try_start_11e .. :try_end_127} :catchall_125

    throw v0

    .line 98
    :cond_128
    :try_start_128
    const-string v0, "/comment.json"

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_169

    .line 99
    if-eqz v12, :cond_13c

    const-string v0, "application/json"

    const-wide/16 v5, -0x1

    const/16 v7, 0xc8

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v7, v0, v5, v6}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V

    goto :goto_156

    .line 100
    :cond_13c
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v5, "a"

    new-array v6, v9, [Ljava/lang/Class;

    const-class v7, Ljava/io/BufferedOutputStream;

    const/4 v8, 0x0

    aput-object v7, v6, v8

    invoke-virtual {v0, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v5, v9, [Ljava/lang/Object;

    aput-object v4, v5, v8

    move-object/from16 v6, p1

    invoke-virtual {v0, v6, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_156
    .catchall {:try_start_128 .. :try_end_156} :catchall_1cb

    .line 109
    :goto_156
    :try_start_156
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_159
    .catchall {:try_start_156 .. :try_end_159} :catchall_1d1

    if-eqz v2, :cond_15e

    :try_start_15b
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_15e
    .catchall {:try_start_15b .. :try_end_15e} :catchall_1dc

    .line 110
    :cond_15e
    monitor-enter p0

    :try_start_15f
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 101
    return-void

    .line 110
    :catchall_166
    move-exception v0

    monitor-exit p0
    :try_end_168
    .catchall {:try_start_15f .. :try_end_168} :catchall_166

    throw v0

    .line 103
    :cond_169
    :try_start_169
    iget-object v0, v1, Le/e/a/CastRelay$Session;->hls:Le/e/a/CastHls;

    invoke-virtual {v0, v7}, Le/e/a/CastHls;->lookup(Ljava/lang/String;)Ljava/net/URL;

    move-result-object v0

    .line 104
    if-eqz v0, :cond_1ae

    iget-boolean v5, v1, Le/e/a/CastRelay$Session;->closed:Z

    if-eqz v5, :cond_176

    goto :goto_1ae

    .line 105
    :cond_176
    if-eqz v13, :cond_198

    const-string v5, "bytes=(?:[0-9]+-[0-9]*|-[0-9]+)"

    invoke-virtual {v13, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_198

    .line 106
    const/16 v0, 0x1a0

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v0, v3, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_185
    .catchall {:try_start_169 .. :try_end_185} :catchall_1cb

    .line 109
    :try_start_185
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_188
    .catchall {:try_start_185 .. :try_end_188} :catchall_1d1

    if-eqz v2, :cond_18d

    :try_start_18a
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_18d
    .catchall {:try_start_18a .. :try_end_18d} :catchall_1dc

    .line 110
    :cond_18d
    monitor-enter p0

    :try_start_18e
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 106
    return-void

    .line 110
    :catchall_195
    move-exception v0

    monitor-exit p0
    :try_end_197
    .catchall {:try_start_18e .. :try_end_197} :catchall_195

    throw v0

    .line 108
    :cond_198
    :try_start_198
    invoke-virtual {v1, v4, v0, v12, v13}, Le/e/a/CastRelay$Session;->transfer(Ljava/io/BufferedOutputStream;Ljava/net/URL;ZLjava/lang/String;)V
    :try_end_19b
    .catchall {:try_start_198 .. :try_end_19b} :catchall_1cb

    .line 109
    :try_start_19b
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_19e
    .catchall {:try_start_19b .. :try_end_19e} :catchall_1d1

    if-eqz v2, :cond_1a3

    :try_start_1a0
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_1a3
    .catchall {:try_start_1a0 .. :try_end_1a3} :catchall_1dc

    .line 110
    :cond_1a3
    monitor-enter p0

    :try_start_1a4
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    goto :goto_1fb

    :catchall_1ab
    move-exception v0

    monitor-exit p0
    :try_end_1ad
    .catchall {:try_start_1a4 .. :try_end_1ad} :catchall_1ab

    throw v0

    .line 104
    :cond_1ae
    :goto_1ae
    :try_start_1ae
    const-string v0, "Cast relay: unknown or expired resource route"

    invoke-static {v0}, Le/e/a/CastDiagnostics;->record(Ljava/lang/String;)V

    const/16 v0, 0x194

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v4, v0, v3, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_1b8
    .catchall {:try_start_1ae .. :try_end_1b8} :catchall_1cb

    .line 109
    :try_start_1b8
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V
    :try_end_1bb
    .catchall {:try_start_1b8 .. :try_end_1bb} :catchall_1d1

    if-eqz v2, :cond_1c0

    :try_start_1bd
    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V
    :try_end_1c0
    .catchall {:try_start_1bd .. :try_end_1c0} :catchall_1dc

    .line 110
    :cond_1c0
    monitor-enter p0

    :try_start_1c1
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 104
    return-void

    .line 110
    :catchall_1c8
    move-exception v0

    monitor-exit p0
    :try_end_1ca
    .catchall {:try_start_1c1 .. :try_end_1ca} :catchall_1c8

    throw v0

    .line 109
    :catchall_1cb
    move-exception v0

    move-object v3, v0

    :try_start_1cd
    invoke-virtual {v4}, Ljava/io/BufferedOutputStream;->close()V

    throw v3
    :try_end_1d1
    .catchall {:try_start_1cd .. :try_end_1d1} :catchall_1d1

    :catchall_1d1
    move-exception v0

    if-nez v3, :cond_1d6

    move-object v3, v0

    goto :goto_1de

    :cond_1d6
    if-eq v3, v0, :cond_1de

    :try_start_1d8
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_1de

    :catchall_1dc
    move-exception v0

    goto :goto_1e4

    :cond_1de
    :goto_1de
    if-eqz v2, :cond_1e3

    invoke-virtual/range {p2 .. p2}, Ljava/net/Socket;->close()V

    :cond_1e3
    throw v3
    :try_end_1e4
    .catchall {:try_start_1d8 .. :try_end_1e4} :catchall_1dc

    :goto_1e4
    if-eqz v3, :cond_1ec

    if-eq v3, v0, :cond_1ed

    :try_start_1e8
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_1ed

    :cond_1ec
    move-object v3, v0

    :cond_1ed
    :goto_1ed
    throw v3
    :try_end_1ee
    .catch Ljava/lang/Exception; {:try_start_1e8 .. :try_end_1ee} :catch_1f0
    .catchall {:try_start_1e8 .. :try_end_1ee} :catchall_1ee

    .line 110
    :catchall_1ee
    move-exception v0

    goto :goto_1ff

    .line 109
    :catch_1f0
    move-exception v0

    :try_start_1f1
    invoke-static {v0}, Le/e/a/CastRelay;->failed(Ljava/lang/Throwable;)V
    :try_end_1f4
    .catchall {:try_start_1f1 .. :try_end_1f4} :catchall_1ee

    .line 110
    monitor-enter p0

    :try_start_1f5
    iget-object v0, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0

    .line 111
    :goto_1fb
    return-void

    .line 110
    :catchall_1fc
    move-exception v0

    monitor-exit p0
    :try_end_1fe
    .catchall {:try_start_1f5 .. :try_end_1fe} :catchall_1fc

    throw v0

    :goto_1ff
    monitor-enter p0

    :try_start_200
    iget-object v3, v1, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v3, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit p0
    :try_end_206
    .catchall {:try_start_200 .. :try_end_206} :catchall_207

    throw v0

    :catchall_207
    move-exception v0

    :try_start_208
    monitor-exit p0
    :try_end_209
    .catchall {:try_start_208 .. :try_end_209} :catchall_207

    throw v0
.end method


# virtual methods
.method declared-synchronized accept(Ljava/lang/Object;Ljava/net/Socket;)V
    .registers 5

    monitor-enter p0

    .line 67
    :try_start_1
    iget-boolean v0, p0, Le/e/a/CastRelay$Session;->closed:Z

    if-eqz v0, :cond_a

    # invokes: Le/e/a/CastRelay;->closeSocket(Ljava/net/Socket;)V
    invoke-static {p2}, Le/e/a/CastRelay;->access$0(Ljava/net/Socket;)V
    :try_end_8
    .catchall {:try_start_1 .. :try_end_8} :catchall_28

    monitor-exit p0

    return-void

    .line 68
    :cond_a
    :try_start_a
    iget-object v0, p0, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_f
    .catchall {:try_start_a .. :try_end_f} :catchall_28

    .line 69
    :try_start_f
    iget-object v0, p0, Le/e/a/CastRelay$Session;->workers:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, Le/e/a/CastRelay$Session$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1, p2}, Le/e/a/CastRelay$Session$$ExternalSyntheticLambda1;-><init>(Le/e/a/CastRelay$Session;Ljava/lang/Object;Ljava/net/Socket;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V
    :try_end_19
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_f .. :try_end_19} :catch_1a
    .catchall {:try_start_f .. :try_end_19} :catchall_28

    goto :goto_26

    .line 70
    :catch_1a
    move-exception p1

    :try_start_1b
    iget-object v0, p0, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    # invokes: Le/e/a/CastRelay;->closeSocket(Ljava/net/Socket;)V
    invoke-static {p2}, Le/e/a/CastRelay;->access$0(Ljava/net/Socket;)V

    invoke-static {p1}, Le/e/a/CastRelay;->failed(Ljava/lang/Throwable;)V
    :try_end_26
    .catchall {:try_start_1b .. :try_end_26} :catchall_28

    .line 71
    :goto_26
    monitor-exit p0

    return-void

    .line 66
    :catchall_28
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method declared-synchronized close()V
    .registers 3

    monitor-enter p0

    .line 73
    const/4 v0, 0x1

    :try_start_2
    iput-boolean v0, p0, Le/e/a/CastRelay$Session;->closed:Z

    iget-object v0, p0, Le/e/a/CastRelay$Session;->workers:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdownNow()Ljava/util/List;

    .line 74
    iget-object v0, p0, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_3c

    .line 75
    iget-object v0, p0, Le/e/a/CastRelay$Session;->sockets:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 76
    iget-object v0, p0, Le/e/a/CastRelay$Session;->connections:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_20
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_32

    .line 77
    iget-object v0, p0, Le/e/a/CastRelay$Session;->connections:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    iget-object v0, p0, Le/e/a/CastRelay$Session;->hls:Le/e/a/CastHls;

    invoke-virtual {v0}, Le/e/a/CastHls;->clear()V
    :try_end_30
    .catchall {:try_start_2 .. :try_end_30} :catchall_46

    .line 78
    monitor-exit p0

    return-void

    .line 76
    :cond_32
    :try_start_32
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_20

    .line 74
    :cond_3c
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/net/Socket;

    # invokes: Le/e/a/CastRelay;->closeSocket(Ljava/net/Socket;)V
    invoke-static {v1}, Le/e/a/CastRelay;->access$0(Ljava/net/Socket;)V
    :try_end_45
    .catchall {:try_start_32 .. :try_end_45} :catchall_46

    goto :goto_f

    .line 72
    :catchall_46
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method synthetic lambda$0$e-e-a-CastRelay$Session(Ljava/lang/Object;Ljava/net/Socket;)V
    .registers 3

    .line 69
    invoke-direct {p0, p1, p2}, Le/e/a/CastRelay$Session;->serve(Ljava/lang/Object;Ljava/net/Socket;)V

    return-void
.end method

.method transfer(Ljava/io/BufferedOutputStream;Ljava/net/URL;ZLjava/lang/String;)V
    .registers 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 113
    move-object v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p4

    .line 114
    nop

    .line 116
    const/4 v3, 0x0

    move-object/from16 v4, p2

    const/4 v5, 0x0

    .line 117
    :goto_a
    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    :try_start_d
    invoke-static {v4}, Le/e/a/CastHls;->validate(Ljava/net/URL;)V

    .line 118
    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v9

    check-cast v9, Ljava/net/HttpURLConnection;
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_16} :catch_1cd
    .catchall {:try_start_d .. :try_end_16} :catchall_1cb

    .line 119
    :try_start_16
    monitor-enter p0
    :try_end_17
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_17} :catch_1c9
    .catchall {:try_start_16 .. :try_end_17} :catchall_1e0

    .line 120
    :try_start_17
    iget-boolean v10, v1, Le/e/a/CastRelay$Session;->closed:Z

    if-nez v10, :cond_1be

    .line 121
    iget-object v10, v1, Le/e/a/CastRelay$Session;->connections:Ljava/util/Set;

    invoke-interface {v10, v9}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 119
    monitor-exit p0
    :try_end_21
    .catchall {:try_start_17 .. :try_end_21} :catchall_1c6

    .line 123
    const/16 v10, 0x3a98

    :try_start_23
    invoke-virtual {v9, v10}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v10, 0x4e20

    invoke-virtual {v9, v10}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 124
    invoke-virtual {v9, v3}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 126
    const-string v10, "GET"

    invoke-virtual {v9, v10}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 127
    const-string v10, "Accept-Encoding"

    const-string v11, "identity"

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    const-string v10, "User-Agent"

    const-string v11, "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 129
    const-string v10, "Origin"

    const-string v11, "https://www.nicovideo.jp"

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 130
    const-string v10, "Referer"

    const-string v11, "https://www.nicovideo.jp/"

    invoke-virtual {v9, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 131
    iget-object v10, v1, Le/e/a/CastRelay$Session;->hls:Le/e/a/CastHls;

    invoke-virtual {v10, v4}, Le/e/a/CastHls;->cookieFor(Ljava/net/URL;)Ljava/lang/String;

    move-result-object v10

    .line 132
    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_60

    const-string v11, "Cookie"

    invoke-virtual {v9, v11, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 133
    :cond_60
    invoke-virtual {v4}, Ljava/net/URL;->getPath()Ljava/lang/String;

    move-result-object v10

    const-string v11, ".m3u8"

    invoke-virtual {v10, v11}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v10

    .line 134
    if-eqz v0, :cond_73

    if-nez v10, :cond_73

    const-string v11, "Range"

    invoke-virtual {v9, v11, v0}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 135
    :cond_73
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v11

    .line 136
    const/16 v12, 0x12d

    if-eq v11, v12, :cond_19b

    const/16 v12, 0x12e

    if-eq v11, v12, :cond_19b

    const/16 v12, 0x12f

    if-eq v11, v12, :cond_19b

    const/16 v12, 0x133

    if-eq v11, v12, :cond_19b

    const/16 v12, 0x134

    if-ne v11, v12, :cond_8d

    goto/16 :goto_19b

    .line 142
    :cond_8d
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v5, "Cast relay HTTP "

    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    if-eqz v10, :cond_9d

    const-string v5, " playlist"

    goto :goto_9f

    :cond_9d
    const-string v5, " resource"

    :goto_9f
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le/e/a/CastDiagnostics;->record(Ljava/lang/String;)V
    :try_end_aa
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_aa} :catch_1c9
    .catchall {:try_start_23 .. :try_end_aa} :catchall_1e0

    .line 143
    const/16 v0, 0xc8

    const/4 v5, 0x1

    if-eq v11, v0, :cond_c0

    const/16 v12, 0xce

    if-eq v11, v12, :cond_c0

    :try_start_b3
    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v2, v11, v8, v6, v7}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_b6
    .catch Ljava/io/IOException; {:try_start_b3 .. :try_end_b6} :catch_bc
    .catchall {:try_start_b3 .. :try_end_b6} :catchall_1e0

    .line 176
    if-eqz v9, :cond_bb

    invoke-direct {p0, v9}, Le/e/a/CastRelay$Session;->release(Ljava/net/HttpURLConnection;)V

    .line 143
    :cond_bb
    return-void

    .line 171
    :catch_bc
    move-exception v0

    const/4 v3, 0x1

    goto/16 :goto_1cf

    .line 144
    :cond_c0
    :try_start_c0
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getContentType()Ljava/lang/String;

    move-result-object v12

    .line 145
    if-eqz v12, :cond_d6

    sget-object v13, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v12, v13}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "mpegurl"

    invoke-virtual {v13, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13
    :try_end_d2
    .catch Ljava/io/IOException; {:try_start_c0 .. :try_end_d2} :catch_1c9
    .catchall {:try_start_c0 .. :try_end_d2} :catchall_1e0

    if-eqz v13, :cond_d6

    const/4 v13, 0x1

    goto :goto_d7

    :cond_d6
    const/4 v13, 0x0

    :goto_d7
    or-int/2addr v10, v13

    .line 146
    if-eqz v10, :cond_11e

    .line 148
    :try_start_da
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v10
    :try_end_de
    .catchall {:try_start_da .. :try_end_de} :catchall_112

    :try_start_de
    # invokes: Le/e/a/CastRelay;->readPlaylist(Ljava/io/InputStream;)[B
    invoke-static {v10}, Le/e/a/CastRelay;->access$3(Ljava/io/InputStream;)[B

    move-result-object v11
    :try_end_e2
    .catchall {:try_start_de .. :try_end_e2} :catchall_108

    if-eqz v10, :cond_e7

    :try_start_e4
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_e7
    .catchall {:try_start_e4 .. :try_end_e7} :catchall_112

    .line 149
    :cond_e7
    :try_start_e7
    iget-object v10, v1, Le/e/a/CastRelay$Session;->hls:Le/e/a/CastHls;

    new-instance v12, Ljava/lang/String;

    sget-object v13, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v12, v11, v13}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-virtual {v10, v4, v12}, Le/e/a/CastHls;->rewrite(Ljava/net/URL;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v10, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v4, v10}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3
    :try_end_fa
    .catch Ljava/io/IOException; {:try_start_e7 .. :try_end_fa} :catch_1c9
    .catchall {:try_start_e7 .. :try_end_fa} :catchall_1e0

    .line 150
    :try_start_fa
    const-string v4, "application/vnd.apple.mpegurl"

    array-length v10, v3

    int-to-long v10, v10

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v2, v0, v4, v10, v11}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V

    .line 151
    if-nez p3, :cond_192

    invoke-virtual {v2, v3}, Ljava/io/BufferedOutputStream;->write([B)V
    :try_end_106
    .catch Ljava/io/IOException; {:try_start_fa .. :try_end_106} :catch_bc
    .catchall {:try_start_fa .. :try_end_106} :catchall_1e0

    .line 152
    goto/16 :goto_192

    .line 148
    :catchall_108
    move-exception v0

    move-object v4, v0

    if-eqz v10, :cond_10f

    :try_start_10c
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V

    :cond_10f
    throw v4
    :try_end_110
    .catchall {:try_start_10c .. :try_end_110} :catchall_110

    :catchall_110
    move-exception v0

    goto :goto_114

    :catchall_112
    move-exception v0

    move-object v4, v8

    :goto_114
    if-eqz v4, :cond_11c

    if-eq v4, v0, :cond_11d

    :try_start_118
    invoke-virtual {v4, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_11d

    :cond_11c
    move-object v4, v0

    :cond_11d
    :goto_11d
    throw v4

    .line 153
    :cond_11e
    const-string v0, "Content-Length"

    invoke-virtual {v9, v0}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 154
    if-nez v0, :cond_129

    const-wide/16 v13, -0x1

    goto :goto_12d

    :cond_129
    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v13
    :try_end_12d
    .catch Ljava/io/IOException; {:try_start_118 .. :try_end_12d} :catch_1c9
    .catchall {:try_start_118 .. :try_end_12d} :catchall_1e0

    .line 155
    :goto_12d
    if-nez v12, :cond_131

    :try_start_12f
    const-string v12, "application/octet-stream"

    :cond_131
    # invokes: Le/e/a/CastRelay;->responseStart(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v2, v11, v12, v13, v14}, Le/e/a/CastRelay;->access$4(Ljava/io/OutputStream;ILjava/lang/String;J)V

    .line 156
    if-nez v10, :cond_148

    .line 157
    const-string v0, "Content-Range"

    const-string v4, "Content-Range"

    invoke-virtual {v9, v4}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    # invokes: Le/e/a/CastRelay;->header(Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;)V
    invoke-static {v2, v0, v4}, Le/e/a/CastRelay;->access$5(Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    const-string v0, "Accept-Ranges"

    const-string v4, "bytes"

    # invokes: Le/e/a/CastRelay;->header(Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;)V
    invoke-static {v2, v0, v4}, Le/e/a/CastRelay;->access$5(Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    :cond_148
    const-string v0, "\r\n"

    sget-object v4, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/io/BufferedOutputStream;->write([B)V
    :try_end_153
    .catch Ljava/io/IOException; {:try_start_12f .. :try_end_153} :catch_bc
    .catchall {:try_start_12f .. :try_end_153} :catchall_1e0

    .line 161
    if-nez p3, :cond_192

    :try_start_155
    invoke-virtual {v9}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4
    :try_end_159
    .catchall {:try_start_155 .. :try_end_159} :catchall_186

    .line 162
    const v0, 0x8000

    :try_start_15c
    new-array v0, v0, [B

    .line 163
    nop

    :goto_15f
    invoke-virtual {v4, v0}, Ljava/io/InputStream;->read([B)I

    move-result v10
    :try_end_163
    .catchall {:try_start_15c .. :try_end_163} :catchall_17c

    const/4 v11, -0x1

    if-ne v10, v11, :cond_16c

    .line 167
    if-eqz v4, :cond_192

    :try_start_168
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_16b
    .catchall {:try_start_168 .. :try_end_16b} :catchall_186

    goto :goto_192

    .line 164
    :cond_16c
    :try_start_16c
    iget-boolean v11, v1, Le/e/a/CastRelay$Session;->closed:Z

    if-nez v11, :cond_174

    .line 165
    invoke-virtual {v2, v0, v3, v10}, Ljava/io/BufferedOutputStream;->write([BII)V

    goto :goto_15f

    .line 164
    :cond_174
    new-instance v0, Ljava/io/IOException;

    const-string v3, "Cast session closed"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_17c
    .catchall {:try_start_16c .. :try_end_17c} :catchall_17c

    .line 167
    :catchall_17c
    move-exception v0

    move-object v3, v0

    if-eqz v4, :cond_183

    :try_start_180
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    :cond_183
    throw v3
    :try_end_184
    .catchall {:try_start_180 .. :try_end_184} :catchall_184

    :catchall_184
    move-exception v0

    goto :goto_188

    :catchall_186
    move-exception v0

    move-object v3, v8

    :goto_188
    if-eqz v3, :cond_190

    if-eq v3, v0, :cond_191

    :try_start_18c
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_191

    :cond_190
    move-object v3, v0

    :cond_191
    :goto_191
    throw v3

    .line 169
    :cond_192
    :goto_192
    invoke-virtual/range {p1 .. p1}, Ljava/io/BufferedOutputStream;->flush()V
    :try_end_195
    .catch Ljava/io/IOException; {:try_start_18c .. :try_end_195} :catch_bc
    .catchall {:try_start_18c .. :try_end_195} :catchall_1e0

    .line 176
    if-eqz v9, :cond_19a

    invoke-direct {p0, v9}, Le/e/a/CastRelay$Session;->release(Ljava/net/HttpURLConnection;)V

    .line 169
    :cond_19a
    return-void

    .line 137
    :cond_19b
    :goto_19b
    :try_start_19b
    const-string v10, "Location"

    invoke-virtual {v9, v10}, Ljava/net/HttpURLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 138
    const/4 v11, 0x5

    if-ge v5, v11, :cond_1b6

    if-eqz v10, :cond_1b6

    .line 139
    new-instance v11, Ljava/net/URL;

    invoke-direct {v11, v4, v10}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    invoke-static {v11}, Le/e/a/CastHls;->validate(Ljava/net/URL;)V

    .line 140
    invoke-direct {p0, v9}, Le/e/a/CastRelay$Session;->release(Ljava/net/HttpURLConnection;)V

    .line 116
    add-int/lit8 v5, v5, 0x1

    move-object v4, v11

    goto/16 :goto_a

    .line 138
    :cond_1b6
    new-instance v0, Ljava/io/IOException;

    const-string v4, "Cast redirect failed"

    invoke-direct {v0, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1be
    .catch Ljava/io/IOException; {:try_start_19b .. :try_end_1be} :catch_1c9
    .catchall {:try_start_19b .. :try_end_1be} :catchall_1e0

    .line 120
    :cond_1be
    :try_start_1be
    new-instance v0, Ljava/io/IOException;

    const-string v4, "Cast session closed"

    invoke-direct {v0, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 119
    :catchall_1c6
    move-exception v0

    monitor-exit p0
    :try_end_1c8
    .catchall {:try_start_1be .. :try_end_1c8} :catchall_1c6

    :try_start_1c8
    throw v0
    :try_end_1c9
    .catch Ljava/io/IOException; {:try_start_1c8 .. :try_end_1c9} :catch_1c9
    .catchall {:try_start_1c8 .. :try_end_1c9} :catchall_1e0

    .line 171
    :catch_1c9
    move-exception v0

    goto :goto_1cf

    .line 176
    :catchall_1cb
    move-exception v0

    goto :goto_1e2

    .line 171
    :catch_1cd
    move-exception v0

    move-object v9, v8

    .line 173
    :goto_1cf
    :try_start_1cf
    invoke-static {v0}, Le/e/a/CastRelay;->failed(Ljava/lang/Throwable;)V

    .line 174
    if-nez v3, :cond_1df

    const/16 v0, 0x1f6

    # invokes: Le/e/a/CastRelay;->response(Ljava/io/OutputStream;ILjava/lang/String;J)V
    invoke-static {v2, v0, v8, v6, v7}, Le/e/a/CastRelay;->access$2(Ljava/io/OutputStream;ILjava/lang/String;J)V
    :try_end_1d9
    .catchall {:try_start_1cf .. :try_end_1d9} :catchall_1e0

    .line 176
    if-eqz v9, :cond_1de

    invoke-direct {p0, v9}, Le/e/a/CastRelay$Session;->release(Ljava/net/HttpURLConnection;)V

    .line 177
    :cond_1de
    return-void

    .line 175
    :cond_1df
    :try_start_1df
    throw v0
    :try_end_1e0
    .catchall {:try_start_1df .. :try_end_1e0} :catchall_1e0

    .line 176
    :catchall_1e0
    move-exception v0

    move-object v8, v9

    :goto_1e2
    if-eqz v8, :cond_1e7

    invoke-direct {p0, v8}, Le/e/a/CastRelay$Session;->release(Ljava/net/HttpURLConnection;)V

    :cond_1e7
    throw v0
.end method
