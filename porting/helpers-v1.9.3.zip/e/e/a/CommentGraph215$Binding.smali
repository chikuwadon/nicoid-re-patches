.class final Le/e/a/CommentGraph215$Binding;
.super Ljava/lang/Object;
.source "CommentGraph215.java"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;
.implements Landroid/view/View$OnLayoutChangeListener;
.implements Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/CommentGraph215;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Binding"
.end annotation


# instance fields
.field disposed:Z

.field final overlay:Le/e/a/CommentGraph215$Overlay;

.field final owner:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final popup:Z

.field final prefs:Landroid/content/SharedPreferences;

.field final root:Landroid/view/View;

.field final seek:Landroid/widget/SeekBar;

.field snapshot:Le/e/a/CommentGraph215$Snapshot;


# direct methods
.method constructor <init>(Ljava/lang/Object;Landroid/view/View;Landroid/widget/SeekBar;Z)V
    .registers 5

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p4, p0, Le/e/a/CommentGraph215$Binding;->popup:Z

    new-instance p4, Ljava/lang/ref/WeakReference;

    invoke-direct {p4, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p4, p0, Le/e/a/CommentGraph215$Binding;->owner:Ljava/lang/ref/WeakReference;

    iput-object p2, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    iput-object p3, p0, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    new-instance p1, Le/e/a/CommentGraph215$Overlay;

    invoke-direct {p1, p0}, Le/e/a/CommentGraph215$Overlay;-><init>(Le/e/a/CommentGraph215$Binding;)V

    iput-object p1, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Le/e/a/CommentGraph215$Binding;->prefs:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method dispose()V
    .registers 3

    .line 34
    iget-boolean v0, p0, Le/e/a/CommentGraph215$Binding;->disposed:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, Le/e/a/CommentGraph215$Binding;->disposed:Z

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v0, p0}, Landroid/widget/SeekBar;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0, p0}, Landroid/content/SharedPreferences;->unregisterOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object v0

    iget-object v1, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    invoke-virtual {v0, v1}, Landroid/view/ViewOverlay;->remove(Landroid/graphics/drawable/Drawable;)V

    sget-object v0, Le/e/a/CommentGraph215;->BINDINGS:Ljava/util/Map;

    iget-object v1, p0, Le/e/a/CommentGraph215$Binding;->owner:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x0

    iput-object v0, p0, Le/e/a/CommentGraph215$Binding;->snapshot:Le/e/a/CommentGraph215$Snapshot;

    return-void
.end method

.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 10

    .line 36
    invoke-virtual {p0}, Le/e/a/CommentGraph215$Binding;->refresh()V

    return-void
.end method

.method public onSharedPreferenceChanged(Landroid/content/SharedPreferences;Ljava/lang/String;)V
    .registers 3

    .line 37
    const-string p1, "seek_comment_density"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_d

    iget-object p1, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    invoke-virtual {p1}, Le/e/a/CommentGraph215$Overlay;->invalidateSelf()V

    :cond_d
    return-void
.end method

.method public onViewAttachedToWindow(Landroid/view/View;)V
    .registers 2

    .line 35
    invoke-virtual {p0}, Le/e/a/CommentGraph215$Binding;->refresh()V

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .registers 2

    .line 35
    invoke-virtual {p0}, Le/e/a/CommentGraph215$Binding;->dispose()V

    return-void
.end method

.method refresh()V
    .registers 5

    .line 33
    iget-boolean v0, p0, Le/e/a/CommentGraph215$Binding;->disposed:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x0

    :try_start_6
    iget-object v1, p0, Le/e/a/CommentGraph215$Binding;->owner:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_12

    invoke-virtual {p0}, Le/e/a/CommentGraph215$Binding;->dispose()V

    return-void

    :cond_12
    iget-boolean v2, p0, Le/e/a/CommentGraph215$Binding;->popup:Z

    if-eqz v2, :cond_19

    const-string v2, "z"

    goto :goto_1b

    :cond_19
    const-string v2, "h1"

    :goto_1b
    invoke-static {v1, v2}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    iget-boolean v3, p0, Le/e/a/CommentGraph215$Binding;->popup:Z

    if-eqz v3, :cond_26

    const-string v3, "f"

    goto :goto_28

    :cond_26
    const-string v3, "b0"

    :goto_28
    invoke-static {v1, v3}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    sget-object v3, Le/e/a/CommentGraph215;->DATA:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Le/e/a/CommentGraph215$Snapshot;

    if-eqz v2, :cond_40

    iget-object v3, v2, Le/e/a/CommentGraph215$Snapshot;->id:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4e

    :cond_40
    iget-boolean v2, p0, Le/e/a/CommentGraph215$Binding;->popup:Z

    if-eqz v2, :cond_4d

    sget-object v2, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Le/e/a/CommentGraph215$Snapshot;

    goto :goto_4e

    :cond_4d
    move-object v2, v0

    :cond_4e
    :goto_4e
    if-eqz v2, :cond_58

    iget-object v3, v2, Le/e/a/CommentGraph215$Snapshot;->id:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    :cond_58
    move-object v2, v0

    :cond_59
    iput-object v2, p0, Le/e/a/CommentGraph215$Binding;->snapshot:Le/e/a/CommentGraph215$Snapshot;
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_5b} :catch_5c

    goto :goto_5e

    :catch_5c
    iput-object v0, p0, Le/e/a/CommentGraph215$Binding;->snapshot:Le/e/a/CommentGraph215$Snapshot;

    :goto_5e
    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    iget-object v1, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    iget-object v2, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v3, v1, v2}, Le/e/a/CommentGraph215$Overlay;->setBounds(IIII)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    invoke-virtual {v0}, Le/e/a/CommentGraph215$Overlay;->invalidateSelf()V

    return-void
.end method

.method start()V
    .registers 3

    .line 32
    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v0, p0}, Landroid/widget/SeekBar;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0, p0}, Landroid/content/SharedPreferences;->registerOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object v0

    iget-object v1, p0, Le/e/a/CommentGraph215$Binding;->overlay:Le/e/a/CommentGraph215$Overlay;

    invoke-virtual {v0, v1}, Landroid/view/ViewOverlay;->add(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Le/e/a/CommentGraph215$Binding;->refresh()V

    return-void
.end method
