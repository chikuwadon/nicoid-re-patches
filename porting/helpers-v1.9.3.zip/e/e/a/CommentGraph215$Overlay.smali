.class final Le/e/a/CommentGraph215$Overlay;
.super Landroid/graphics/drawable/Drawable;
.source "CommentGraph215.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/CommentGraph215;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Overlay"
.end annotation


# instance fields
.field final b:Le/e/a/CommentGraph215$Binding;

.field final bar:[I

.field final p:Landroid/graphics/Paint;

.field final path:Landroid/graphics/Path;

.field final root:[I


# direct methods
.method constructor <init>(Le/e/a/CommentGraph215$Binding;)V
    .registers 4

    .line 40
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Le/e/a/CommentGraph215$Overlay;->p:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    const/4 v0, 0x2

    new-array v1, v0, [I

    iput-object v1, p0, Le/e/a/CommentGraph215$Overlay;->root:[I

    new-array v0, v0, [I

    iput-object v0, p0, Le/e/a/CommentGraph215$Overlay;->bar:[I

    iput-object p1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 15

    .line 41
    iget-object v0, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v0, v0, Le/e/a/CommentGraph215$Binding;->snapshot:Le/e/a/CommentGraph215$Snapshot;

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Le/e/a/CommentGraph215;->enabled(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_15c

    if-eqz v0, :cond_15c

    iget v1, v0, Le/e/a/CommentGraph215$Snapshot;->count:I

    if-eqz v1, :cond_15c

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v1}, Landroid/widget/SeekBar;->isShown()Z

    move-result v1

    if-eqz v1, :cond_15c

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getAlpha()F

    move-result v1

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    if-eqz v1, :cond_15c

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getWidth()I

    move-result v1

    if-nez v1, :cond_3b

    goto/16 :goto_15c

    :cond_3b
    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->host:Landroid/view/View;

    if-nez v1, :cond_42

    return-void

    :cond_42
    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->host:Landroid/view/View;

    iget-object v2, p0, Le/e/a/CommentGraph215$Overlay;->root:[I

    invoke-virtual {v1, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v1, v1, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    iget-object v2, p0, Le/e/a/CommentGraph215$Overlay;->bar:[I

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->getLocationOnScreen([I)V

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->bar:[I

    const/4 v2, 0x0

    aget v1, v1, v2

    iget-object v3, p0, Le/e/a/CommentGraph215$Overlay;->root:[I

    aget v3, v3, v2

    sub-int/2addr v1, v3

    iget-object v3, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v3, v3, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v3}, Landroid/widget/SeekBar;->getPaddingLeft()I

    move-result v3

    add-int/2addr v1, v3

    int-to-float v1, v1

    iget-object v3, p0, Le/e/a/CommentGraph215$Overlay;->bar:[I

    aget v3, v3, v2

    iget-object v4, p0, Le/e/a/CommentGraph215$Overlay;->root:[I

    aget v4, v4, v2

    sub-int/2addr v3, v4

    iget-object v4, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v4, v4, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v4}, Landroid/widget/SeekBar;->getWidth()I

    move-result v4

    add-int/2addr v3, v4

    iget-object v4, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v4, v4, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v4}, Landroid/widget/SeekBar;->getPaddingRight()I

    move-result v4

    sub-int/2addr v3, v4

    int-to-float v3, v3

    iget-object v4, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v4, v4, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->density:F

    iget-object v5, p0, Le/e/a/CommentGraph215$Overlay;->bar:[I

    const/4 v6, 0x1

    aget v5, v5, v6

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->root:[I

    aget v7, v7, v6

    sub-int/2addr v5, v7

    int-to-float v5, v5

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v7, v7, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v7}, Landroid/widget/SeekBar;->getHeight()I

    move-result v7

    int-to-float v7, v7

    const/high16 v8, 0x40000000    # 2.0f

    div-float/2addr v7, v8

    add-float/2addr v5, v7

    const/high16 v7, 0x40a00000    # 5.0f

    mul-float v7, v7, v4

    sub-float/2addr v5, v7

    iget-object v7, v0, Le/e/a/CommentGraph215$Snapshot;->bins:[I

    array-length v8, v7

    const/4 v9, 0x0

    const/4 v10, 0x0

    :goto_b4
    if-lt v9, v8, :cond_152

    if-nez v10, :cond_b9

    return-void

    :cond_b9
    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->p:Landroid/graphics/Paint;

    const v8, -0x66864249

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v7, v7, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    const/high16 v8, 0x3f800000    # 1.0f

    :goto_c7
    if-nez v7, :cond_ca

    goto :goto_d6

    :cond_ca
    invoke-virtual {v7}, Landroid/view/View;->getAlpha()F

    move-result v9

    mul-float v8, v8, v9

    iget-object v9, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v9, v9, Le/e/a/CommentGraph215$Binding;->host:Landroid/view/View;

    if-ne v7, v9, :cond_143

    :goto_d6
    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x43190000    # 153.0f

    mul-float v8, v8, v9

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setAlpha(I)V

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->rewind()V

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    invoke-virtual {v7, v1, v5}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-object v7, v7, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    invoke-virtual {v7}, Landroid/widget/SeekBar;->getLayoutDirection()I

    move-result v7

    if-ne v7, v6, :cond_f9

    const/4 v9, 0x1

    goto :goto_fa

    :cond_f9
    const/4 v9, 0x0

    :goto_fa
    const/16 v6, 0xb4

    if-lt v2, v6, :cond_110

    iget-object v0, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    invoke-virtual {v0, v3, v5}, Landroid/graphics/Path;->lineTo(FF)V

    iget-object v0, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->close()V

    iget-object v0, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    iget-object v1, p0, Le/e/a/CommentGraph215$Overlay;->p:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void

    :cond_110
    if-eqz v9, :cond_115

    rsub-int v6, v2, 0xb3

    goto :goto_116

    :cond_115
    move v6, v2

    :goto_116
    iget-object v7, p0, Le/e/a/CommentGraph215$Overlay;->path:Landroid/graphics/Path;

    sub-float v8, v3, v1

    int-to-float v11, v2

    const/high16 v12, 0x3f000000    # 0.5f

    add-float/2addr v11, v12

    mul-float v8, v8, v11

    const/high16 v11, 0x43340000    # 180.0f

    div-float/2addr v8, v11

    add-float/2addr v8, v1

    iget-object v11, p0, Le/e/a/CommentGraph215$Overlay;->b:Le/e/a/CommentGraph215$Binding;

    iget-boolean v11, v11, Le/e/a/CommentGraph215$Binding;->popup:Z

    if-eqz v11, :cond_12d

    const/16 v11, 0xc

    goto :goto_12f

    :cond_12d
    const/16 v11, 0x14

    :goto_12f
    int-to-float v11, v11

    mul-float v11, v11, v4

    iget-object v12, v0, Le/e/a/CommentGraph215$Snapshot;->bins:[I

    aget v6, v12, v6

    int-to-float v6, v6

    mul-float v11, v11, v6

    int-to-float v6, v10

    div-float/2addr v11, v6

    sub-float v6, v5, v11

    invoke-virtual {v7, v8, v6}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_fa

    :cond_143
    invoke-virtual {v7}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    instance-of v9, v7, Landroid/view/View;

    if-eqz v9, :cond_14f

    check-cast v7, Landroid/view/View;

    goto/16 :goto_c7

    :cond_14f
    const/4 v7, 0x0

    goto/16 :goto_c7

    :cond_152
    aget v11, v7, v9

    invoke-static {v10, v11}, Ljava/lang/Math;->max(II)I

    move-result v10

    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_b4

    :cond_15c
    :goto_15c
    return-void
.end method

.method public getOpacity()I
    .registers 2

    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 2

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2

    return-void
.end method
