.class final Le/e/a/CommentGraph215$Snapshot;
.super Ljava/lang/Object;
.source "CommentGraph215.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/CommentGraph215;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Snapshot"
.end annotation


# instance fields
.field final bins:[I

.field final count:I

.field final duration:J

.field final id:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;J[II)V
    .registers 6

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/CommentGraph215$Snapshot;->id:Ljava/lang/String;

    iput-wide p2, p0, Le/e/a/CommentGraph215$Snapshot;->duration:J

    iput-object p4, p0, Le/e/a/CommentGraph215$Snapshot;->bins:[I

    iput p5, p0, Le/e/a/CommentGraph215$Snapshot;->count:I

    return-void
.end method
