.class public final Le/e/a/CommentGraph215;
.super Ljava/lang/Object;
.source "CommentGraph215.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/CommentGraph215$Binding;,
        Le/e/a/CommentGraph215$Overlay;,
        Le/e/a/CommentGraph215$Snapshot;
    }
.end annotation


# static fields
.field static final BINDINGS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Le/e/a/CommentGraph215$Binding;",
            ">;"
        }
    .end annotation
.end field

.field static final DATA:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Le/e/a/CommentGraph215$Snapshot;",
            ">;"
        }
    .end annotation
.end field

.field public static final GRAPH:Ljava/lang/String; = "seek_comment_density"

.field static final MAIN:Landroid/os/Handler;

.field static final SHARED:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Le/e/a/CommentGraph215$Snapshot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 7
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Le/e/a/CommentGraph215;->BINDINGS:Ljava/util/Map;

    .line 8
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Le/e/a/CommentGraph215;->DATA:Ljava/util/Map;

    .line 9
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    .line 10
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Le/e/a/CommentGraph215;->MAIN:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static attach(Ljava/lang/Object;)V
    .registers 2

    const/4 v0, 0x0

    .line 22
    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->attachOwner(Ljava/lang/Object;Z)V

    return-void
.end method

.method static attachOwner(Ljava/lang/Object;Z)V
    .registers 7

    if-eqz p1, :cond_5

    .line 24
    :try_start_2
    const-string v0, "a"

    goto :goto_7

    :cond_5
    const-string v0, "x1"

    :goto_7
    invoke-static {p0, v0}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz p1, :cond_12

    const-string v1, "d"

    goto :goto_14

    :cond_12
    const-string v1, "Z"

    :goto_14
    invoke-static {p0, v1}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    if-eqz v0, :cond_28

    if-nez v1, :cond_26

    const-string v1, "seekBar"

    invoke-static {v0, v1}, Le/e/a/PortraitTimeline213;->find(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    :cond_26
    if-nez v1, :cond_29

    :cond_28
    return-void

    :cond_29
    if-eqz p1, :cond_39

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v2, v2, Landroid/view/View;

    if-eqz v2, :cond_39

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    :cond_39
    sget-object v2, Le/e/a/CommentGraph215;->BINDINGS:Ljava/util/Map;

    invoke-interface {v2, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/CommentGraph215$Binding;

    if-eqz v3, :cond_4f

    iget-object v4, v3, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    if-ne v4, v0, :cond_4f

    iget-object v4, v3, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    if-ne v4, v1, :cond_4f

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->refresh()V

    return-void

    :cond_4f
    if-eqz v3, :cond_54

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->dispose()V

    :cond_54
    new-instance v3, Le/e/a/CommentGraph215$Binding;

    invoke-direct {v3, p0, v0, v1, p1}, Le/e/a/CommentGraph215$Binding;-><init>(Ljava/lang/Object;Landroid/view/View;Landroid/widget/SeekBar;Z)V

    invoke-interface {v2, p0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->start()V
    :try_end_5f
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_5f} :catch_60

    return-void

    :catch_60
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Comment graph attachment unavailable: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le/e/a/ModernDebug;->record(Ljava/lang/String;)V

    return-void
.end method

.method public static attachPopup(Ljava/lang/Object;)V
    .registers 2

    const/4 v0, 0x1

    .line 23
    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->attachOwner(Ljava/lang/Object;Z)V

    return-void
.end method

.method static enabled(Landroid/content/Context;)Z
    .registers 3

    .line 11
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "seek_comment_density"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method static parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;
    .registers 6

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    const/4 v1, 0x0

    .line 28
    :goto_5
    invoke-virtual {p0}, Landroid/preference/PreferenceGroup;->getPreferenceCount()I

    move-result v2

    if-lt v1, v2, :cond_c

    return-object v0

    :cond_c
    invoke-virtual {p0, v1}, Landroid/preference/PreferenceGroup;->getPreference(I)Landroid/preference/Preference;

    move-result-object v2

    if-ne v2, p1, :cond_13

    return-object p0

    :cond_13
    instance-of v3, v2, Landroid/preference/PreferenceGroup;

    if-eqz v3, :cond_20

    check-cast v2, Landroid/preference/PreferenceGroup;

    invoke-static {v2, p1}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object v2

    if-eqz v2, :cond_20

    return-object v2

    :cond_20
    add-int/lit8 v1, v1, 0x1

    goto :goto_5
.end method

.method public static publish(Ljava/lang/Object;Ljava/util/ArrayList;)V
    .registers 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/ArrayList<",
            "*>;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    if-eqz v0, :cond_e6

    if-eqz p1, :cond_e6

    .line 15
    :try_start_6
    const-string v1, "modernWatch"

    invoke-static {v0, v1}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    const/4 v2, 0x0

    if-nez v1, :cond_13

    move-object v3, v2

    goto :goto_19

    :cond_13
    const-string v3, "video"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    :goto_19
    if-eqz v3, :cond_e6

    .line 16
    const-string v4, "d"

    invoke-static {v0, v4}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    const-string v4, "duration"

    const-wide/16 v7, 0x0

    invoke-virtual {v3, v4, v7, v8}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v3

    const-wide/16 v9, 0x3e8

    mul-long v3, v3, v9

    invoke-static {v1, v6}, Le/e/a/DetailData;->matchesWatch(Lorg/json/JSONObject;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e6

    cmp-long v1, v3, v7

    if-lez v1, :cond_e6

    const/16 v1, 0xb4

    .line 17
    new-array v9, v1, [I

    .line 18
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move-object v5, v2

    const/4 v10, 0x0

    :cond_45
    :goto_45
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-nez v11, :cond_86

    .line 19
    new-instance v5, Le/e/a/CommentGraph215$Snapshot;

    move-wide v7, v3

    invoke-direct/range {v5 .. v10}, Le/e/a/CommentGraph215$Snapshot;-><init>(Ljava/lang/String;J[II)V

    sget-object v1, Le/e/a/CommentGraph215;->DATA:Ljava/util/Map;

    invoke-interface {v1, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    monitor-enter v1
    :try_end_59
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_59} :catch_cc

    :try_start_59
    invoke-interface {v1, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_5c
    sget-object v0, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v2

    const/16 v3, 0x8

    if-gt v2, v3, :cond_72

    monitor-exit v1
    :try_end_67
    .catchall {:try_start_59 .. :try_end_67} :catchall_84

    :try_start_67
    sget-object v0, Le/e/a/CommentGraph215;->MAIN:Landroid/os/Handler;

    new-instance v1, Le/e/a/CommentGraph215$1;

    invoke-direct {v1}, Le/e/a/CommentGraph215$1;-><init>()V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_71
    .catch Ljava/lang/Exception; {:try_start_67 .. :try_end_71} :catch_cc

    return-void

    :cond_72
    :try_start_72
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5c

    :goto_82
    monitor-exit v1
    :try_end_83
    .catchall {:try_start_72 .. :try_end_83} :catchall_84

    :try_start_83
    throw v0

    :catchall_84
    move-exception v0

    goto :goto_82

    .line 18
    :cond_86
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    if-eqz v11, :cond_45

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v12

    if-eq v2, v12, :cond_9c

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-string v5, "d"

    invoke-virtual {v2, v5}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    :cond_9c
    invoke-virtual {v5, v11}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    instance-of v12, v11, Ljava/lang/Number;

    if-eqz v12, :cond_45

    check-cast v11, Ljava/lang/Number;

    invoke-virtual {v11}, Ljava/lang/Number;->longValue()J

    move-result-wide v11

    const-wide/16 v13, 0xa

    mul-long v13, v13, v11

    cmp-long v15, v13, v7

    if-ltz v15, :cond_45

    cmp-long v15, v13, v3

    if-gtz v15, :cond_45

    const-wide/16 v13, 0x708

    mul-long v11, v11, v13

    div-long/2addr v11, v3

    const-wide/16 v13, 0xb3

    invoke-static {v13, v14, v11, v12}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v11

    long-to-int v12, v11

    aget v11, v9, v12

    add-int/lit8 v11, v11, 0x1

    aput v11, v9, v12
    :try_end_c8
    .catch Ljava/lang/Exception; {:try_start_83 .. :try_end_c8} :catch_cc

    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_45

    :catch_cc
    move-exception v0

    .line 20
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Comment graph unavailable: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le/e/a/ModernDebug;->record(Ljava/lang/String;)V

    :cond_e6
    return-void
.end method

.method static remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V
    .registers 2

    .line 27
    invoke-virtual {p0, p1}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object p0

    invoke-static {p0, p1}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object p0

    if-eqz p1, :cond_13

    if-eqz p0, :cond_13

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceGroup;->removePreference(Landroid/preference/Preference;)Z

    :cond_13
    return-void
.end method

.method public static settings(Landroid/preference/PreferenceActivity;)V
    .registers 5

    .line 25
    const-string v0, "seek_thumbnails"

    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V

    const-string v0, "seek_local_frequency"

    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V

    const-string v0, "seek_comment_density"

    invoke-virtual {p0, v0}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    if-eqz v1, :cond_13

    return-void

    :cond_13
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v1

    const-string v2, "quality_mode"

    invoke-virtual {p0, v2}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v2

    invoke-static {v1, v2}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object v1

    if-nez v1, :cond_27

    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v1

    :cond_27
    new-instance v2, Landroid/preference/CheckBoxPreference;

    invoke-direct {v2, p0}, Landroid/preference/CheckBoxPreference;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setKey(Ljava/lang/String;)V

    const-string v0, "\u30b3\u30e1\u30f3\u30c8\u306e\u76db\u308a\u4e0a\u304c\u308a"

    const-string v3, "Comment activity"

    invoke-static {p0, v0, v3}, Le/e/a/CommentGraph215;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setTitle(Ljava/lang/CharSequence;)V

    const-string v0, "\u53d6\u5f97\u6e08\u307f\u30b3\u30e1\u30f3\u30c8\u306e\u6642\u523b\u5206\u5e03\u3092\u30b7\u30fc\u30af\u30d0\u30fc\u306b\u8868\u793a\u3057\u307e\u3059\u3002\u52d5\u753b\u306e\u5168\u30b3\u30e1\u30f3\u30c8\u306e\u7d71\u8a08\u3068\u306f\u9650\u308a\u307e\u305b\u3093"

    const-string v3, "Show the time distribution of fetched comments on the seek bar; this may not cover all comments"

    invoke-static {p0, v0, v3}, Le/e/a/CommentGraph215;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setSummary(Ljava/lang/CharSequence;)V

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setDefaultValue(Ljava/lang/Object;)V

    invoke-static {p0}, Le/e/a/CommentGraph215;->enabled(Landroid/content/Context;)Z

    move-result p0

    invoke-virtual {v2, p0}, Landroid/preference/CheckBoxPreference;->setChecked(Z)V

    invoke-virtual {v1, v2}, Landroid/preference/PreferenceGroup;->addPreference(Landroid/preference/Preference;)Z

    return-void
.end method

.method static tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 26
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    iget-object p0, p0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-virtual {p0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object p0

    const-string v0, "ja"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_17

    return-object p1

    :cond_17
    return-object p2
.end method
