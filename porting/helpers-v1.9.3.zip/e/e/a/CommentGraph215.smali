.class public final Le/e/a/CommentGraph215;
.super Ljava/lang/Object;
.source "CommentGraph215.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/CommentGraph215$Binding;,
        Le/e/a/CommentGraph215$Overlay;,
        Le/e/a/CommentGraph215$Snapshot;
    }
.end annotation


# static fields
.field static final BINDINGS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Le/e/a/CommentGraph215$Binding;",
            ">;"
        }
    .end annotation
.end field

.field static final DATA:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Le/e/a/CommentGraph215$Snapshot;",
            ">;"
        }
    .end annotation
.end field

.field public static final GRAPH:Ljava/lang/String; = "seek_comment_density"

.field static final MAIN:Landroid/os/Handler;

.field static final SHARED:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Le/e/a/CommentGraph215$Snapshot;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 7
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Le/e/a/CommentGraph215;->BINDINGS:Ljava/util/Map;

    .line 8
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Le/e/a/CommentGraph215;->DATA:Ljava/util/Map;

    .line 9
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    .line 10
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Le/e/a/CommentGraph215;->MAIN:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static attach(Ljava/lang/Object;)V
    .registers 2

    const/4 v0, 0x0

    .line 22
    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->attachOwner(Ljava/lang/Object;Z)V

    return-void
.end method

.method static attachOwner(Ljava/lang/Object;Z)V
    .registers 7

    if-eqz p1, :cond_5

    .line 24
    :try_start_2
    const-string v0, "a"

    goto :goto_7

    :cond_5
    const-string v0, "x1"

    :goto_7
    invoke-static {p0, v0}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz p1, :cond_12

    const-string v1, "d"

    goto :goto_14

    :cond_12
    const-string v1, "Z"

    :goto_14
    invoke-static {p0, v1}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    if-nez v0, :cond_1d

    return-void

    :cond_1d
    if-nez v1, :cond_27

    const-string v1, "seekBar"

    invoke-static {v0, v1}, Le/e/a/PortraitTimeline213;->find(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    :cond_27
    if-nez v1, :cond_2a

    return-void

    :cond_2a
    if-eqz p1, :cond_3a

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v2, v2, Landroid/view/View;

    if-eqz v2, :cond_3a

    invoke-virtual {v1}, Landroid/widget/SeekBar;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    :cond_3a
    sget-object v2, Le/e/a/CommentGraph215;->BINDINGS:Ljava/util/Map;

    invoke-interface {v2, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le/e/a/CommentGraph215$Binding;

    if-eqz v3, :cond_50

    iget-object v4, v3, Le/e/a/CommentGraph215$Binding;->root:Landroid/view/View;

    if-ne v4, v0, :cond_50

    iget-object v4, v3, Le/e/a/CommentGraph215$Binding;->seek:Landroid/widget/SeekBar;

    if-ne v4, v1, :cond_50

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->refresh()V

    return-void

    :cond_50
    if-eqz v3, :cond_55

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->dispose()V

    :cond_55
    new-instance v3, Le/e/a/CommentGraph215$Binding;

    invoke-direct {v3, p0, v0, v1, p1}, Le/e/a/CommentGraph215$Binding;-><init>(Ljava/lang/Object;Landroid/view/View;Landroid/widget/SeekBar;Z)V

    invoke-interface {v2, p0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3}, Le/e/a/CommentGraph215$Binding;->start()V
    :try_end_60
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_60} :catch_61

    goto :goto_7b

    :catch_61
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Comment graph attachment unavailable: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le/e/a/ModernDebug;->record(Ljava/lang/String;)V

    :goto_7b
    return-void
.end method

.method public static attachPopup(Ljava/lang/Object;)V
    .registers 2

    const/4 v0, 0x1

    .line 23
    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->attachOwner(Ljava/lang/Object;Z)V

    return-void
.end method

.method static enabled(Landroid/content/Context;)Z
    .registers 3

    .line 11
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "seek_comment_density"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method static parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;
    .registers 6

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    const/4 v1, 0x0

    .line 28
    :goto_5
    invoke-virtual {p0}, Landroid/preference/PreferenceGroup;->getPreferenceCount()I

    move-result v2

    if-lt v1, v2, :cond_c

    return-object v0

    :cond_c
    invoke-virtual {p0, v1}, Landroid/preference/PreferenceGroup;->getPreference(I)Landroid/preference/Preference;

    move-result-object v2

    if-ne v2, p1, :cond_13

    return-object p0

    :cond_13
    instance-of v3, v2, Landroid/preference/PreferenceGroup;

    if-eqz v3, :cond_20

    check-cast v2, Landroid/preference/PreferenceGroup;

    invoke-static {v2, p1}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object v2

    if-eqz v2, :cond_20

    return-object v2

    :cond_20
    add-int/lit8 v1, v1, 0x1

    goto :goto_5
.end method

.method public static publish(Ljava/lang/Object;Ljava/util/ArrayList;)V
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/ArrayList<",
            "*>;)V"
        }
    .end annotation

    if-eqz p0, :cond_f1

    if-nez p1, :cond_6

    goto/16 :goto_f1

    .line 15
    :cond_6
    :try_start_6
    const-string v0, "modernWatch"

    invoke-static {p0, v0}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;

    const/4 v1, 0x0

    if-nez v0, :cond_13

    move-object v2, v1

    goto :goto_19

    :cond_13
    const-string v2, "video"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    :goto_19
    if-nez v2, :cond_1c

    return-void

    .line 16
    :cond_1c
    const-string v3, "d"

    invoke-static {p0, v3}, Le/e/a/Playback214;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "duration"

    const-wide/16 v5, 0x0

    invoke-virtual {v2, v4, v5, v6}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v7

    const-wide/16 v9, 0x3e8

    mul-long v7, v7, v9

    invoke-static {v0, v3}, Le/e/a/DetailData;->matchesWatch(Lorg/json/JSONObject;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d6

    cmp-long v0, v7, v5

    if-gtz v0, :cond_3e

    goto/16 :goto_d6

    :cond_3e
    const/16 v0, 0xb4

    .line 17
    new-array v0, v0, [I

    .line 18
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v2, 0x0

    move-object v2, v1

    const/4 v9, 0x0

    :cond_49
    :goto_49
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_8d

    .line 19
    new-instance p1, Le/e/a/CommentGraph215$Snapshot;

    move-object v4, p1

    move-object v5, v3

    move-wide v6, v7

    move-object v8, v0

    invoke-direct/range {v4 .. v9}, Le/e/a/CommentGraph215$Snapshot;-><init>(Ljava/lang/String;J[II)V

    sget-object v0, Le/e/a/CommentGraph215;->DATA:Ljava/util/Map;

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    monitor-enter p0
    :try_end_60
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_60} :catch_d7

    :try_start_60
    invoke-interface {p0, v3, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_63
    sget-object p1, Le/e/a/CommentGraph215;->SHARED:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v0

    const/16 v1, 0x8

    if-gt v0, v1, :cond_7a

    monitor-exit p0
    :try_end_6e
    .catchall {:try_start_60 .. :try_end_6e} :catchall_8a

    :try_start_6e
    sget-object p0, Le/e/a/CommentGraph215;->MAIN:Landroid/os/Handler;

    new-instance p1, Le/e/a/CommentGraph215$1;

    invoke-direct {p1}, Le/e/a/CommentGraph215$1;-><init>()V

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_78
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_78} :catch_d7

    goto/16 :goto_f1

    :cond_7a
    :try_start_7a
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_63

    :catchall_8a
    move-exception p1

    monitor-exit p0
    :try_end_8c
    .catchall {:try_start_7a .. :try_end_8c} :catchall_8a

    :try_start_8c
    throw p1

    .line 18
    :cond_8d
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    if-nez v4, :cond_94

    goto :goto_49

    :cond_94
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v10

    if-eq v1, v10, :cond_a4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "d"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    :cond_a4
    invoke-virtual {v2, v4}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    instance-of v10, v4, Ljava/lang/Number;

    if-nez v10, :cond_ad

    goto :goto_49

    :cond_ad
    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    const-wide/16 v12, 0xa

    mul-long v12, v12, v10

    cmp-long v4, v12, v5

    if-ltz v4, :cond_49

    cmp-long v4, v12, v7

    if-lez v4, :cond_c0

    goto :goto_49

    :cond_c0
    const-wide/16 v12, 0x708

    mul-long v10, v10, v12

    div-long/2addr v10, v7

    const-wide/16 v12, 0xb3

    invoke-static {v12, v13, v10, v11}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v10

    long-to-int v4, v10

    aget v10, v0, v4

    add-int/lit8 v10, v10, 0x1

    aput v10, v0, v4
    :try_end_d2
    .catch Ljava/lang/Exception; {:try_start_8c .. :try_end_d2} :catch_d7

    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_49

    :cond_d6
    :goto_d6
    return-void

    :catch_d7
    move-exception p0

    .line 20
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Comment graph unavailable: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le/e/a/ModernDebug;->record(Ljava/lang/String;)V

    :cond_f1
    :goto_f1
    return-void
.end method

.method static remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V
    .registers 2

    .line 27
    invoke-virtual {p0, p1}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object p1

    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object p0

    invoke-static {p0, p1}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object p0

    if-eqz p1, :cond_13

    if-eqz p0, :cond_13

    invoke-virtual {p0, p1}, Landroid/preference/PreferenceGroup;->removePreference(Landroid/preference/Preference;)Z

    :cond_13
    return-void
.end method

.method public static settings(Landroid/preference/PreferenceActivity;)V
    .registers 5

    .line 25
    const-string v0, "seek_thumbnails"

    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V

    const-string v0, "seek_local_frequency"

    invoke-static {p0, v0}, Le/e/a/CommentGraph215;->remove(Landroid/preference/PreferenceActivity;Ljava/lang/String;)V

    const-string v0, "seek_comment_density"

    invoke-virtual {p0, v0}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v1

    if-eqz v1, :cond_13

    return-void

    :cond_13
    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v1

    const-string v2, "quality_mode"

    invoke-virtual {p0, v2}, Landroid/preference/PreferenceActivity;->findPreference(Ljava/lang/CharSequence;)Landroid/preference/Preference;

    move-result-object v2

    invoke-static {v1, v2}, Le/e/a/CommentGraph215;->parent(Landroid/preference/PreferenceGroup;Landroid/preference/Preference;)Landroid/preference/PreferenceGroup;

    move-result-object v1

    if-nez v1, :cond_27

    invoke-virtual {p0}, Landroid/preference/PreferenceActivity;->getPreferenceScreen()Landroid/preference/PreferenceScreen;

    move-result-object v1

    :cond_27
    new-instance v2, Landroid/preference/CheckBoxPreference;

    invoke-direct {v2, p0}, Landroid/preference/CheckBoxPreference;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setKey(Ljava/lang/String;)V

    const-string v0, "\u30b3\u30e1\u30f3\u30c8\u306e\u76db\u308a\u4e0a\u304c\u308a"

    const-string v3, "Comment activity"

    invoke-static {p0, v0, v3}, Le/e/a/CommentGraph215;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setTitle(Ljava/lang/CharSequence;)V

    const-string v0, "\u53d6\u5f97\u6e08\u307f\u30b3\u30e1\u30f3\u30c8\u306e\u6642\u523b\u5206\u5e03\u3092\u30b7\u30fc\u30af\u30d0\u30fc\u306b\u8868\u793a\u3057\u307e\u3059\u3002\u52d5\u753b\u306e\u5168\u30b3\u30e1\u30f3\u30c8\u306e\u7d71\u8a08\u3068\u306f\u9650\u308a\u307e\u305b\u3093"

    const-string v3, "Show the time distribution of fetched comments on the seek bar; this may not cover all comments"

    invoke-static {p0, v0, v3}, Le/e/a/CommentGraph215;->tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setSummary(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/preference/CheckBoxPreference;->setDefaultValue(Ljava/lang/Object;)V

    invoke-static {p0}, Le/e/a/CommentGraph215;->enabled(Landroid/content/Context;)Z

    move-result p0

    invoke-virtual {v2, p0}, Landroid/preference/CheckBoxPreference;->setChecked(Z)V

    invoke-virtual {v1, v2}, Landroid/preference/PreferenceGroup;->addPreference(Landroid/preference/Preference;)Z

    return-void
.end method

.method static tr(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 26
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    iget-object p0, p0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-virtual {p0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object p0

    const-string v0, "ja"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_17

    goto :goto_18

    :cond_17
    move-object p1, p2

    :goto_18
    return-object p1
.end method
