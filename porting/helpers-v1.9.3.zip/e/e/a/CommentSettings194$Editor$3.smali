.class Le/e/a/CommentSettings194$Editor$3;
.super Ljava/lang/Object;
.source "CommentSettings194.java"

# interfaces
.implements Le/e/a/CommentSettings194$Editor$Choice;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le/e/a/CommentSettings194$Editor;-><init>(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Le/e/a/CommentSettings194$Editor;


# direct methods
.method constructor <init>(Le/e/a/CommentSettings194$Editor;)V
    .registers 2

    .line 117
    iput-object p1, p0, Le/e/a/CommentSettings194$Editor$3;->this$1:Le/e/a/CommentSettings194$Editor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final choose(I)V
    .registers 3

    .line 120
    iget-object v0, p0, Le/e/a/CommentSettings194$Editor$3;->this$1:Le/e/a/CommentSettings194$Editor;

    invoke-virtual {v0, p1}, Le/e/a/CommentSettings194$Editor;->m41lambda$2$eeaCommentSettings194$Editor(I)V

    .line 121
    return-void
.end method
