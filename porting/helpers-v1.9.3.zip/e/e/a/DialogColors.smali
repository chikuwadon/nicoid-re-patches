.class public final Le/e/a/DialogColors;
.super Ljava/lang/Object;
.source "DialogColors.java"


# static fields
.field public static final ACCENT_DARK:I = -0xad335d

.field public static final INK_DARK:I = -0x111112

.field public static final INK_LIGHT:I = -0xdfdedc

.field public static final LIST_CORNER:I = -0x66666667

.field public static final MUTED_DARK:I = -0x48453d

.field public static final MUTED_LIGHT:I = -0x99958d

.field public static final SURFACE_DARK:I = -0xe6e4e0


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static accent(IZ)I
    .registers 8

    .line 3
    shr-int/lit8 v0, p0, 0x10

    and-int/lit16 v0, v0, 0xff

    shr-int/lit8 v1, p0, 0x8

    and-int/lit16 v1, v1, 0xff

    and-int/lit16 v2, p0, 0xff

    if-eqz p1, :cond_1e

    if-le v1, v0, :cond_1b

    int-to-double v2, v2

    int-to-double v0, v1

    const-wide v4, 0x3ff0cccccccccccdL    # 1.05

    mul-double v0, v0, v4

    cmpl-double p1, v2, v0

    if-lez p1, :cond_1e

    :cond_1b
    const p0, -0xad335d

    :cond_1e
    return p0
.end method

.method public static ink(Z)I
    .registers 1

    .line 3
    if-eqz p0, :cond_6

    const p0, -0x111112

    goto :goto_9

    :cond_6
    const p0, -0xdfdedc

    :goto_9
    return p0
.end method

.method public static muted(Z)I
    .registers 1

    .line 3
    if-eqz p0, :cond_6

    const p0, -0x48453d

    goto :goto_9

    :cond_6
    const p0, -0x99958d

    :goto_9
    return p0
.end method

.method public static purple(I)Z
    .registers 7

    .line 3
    shr-int/lit8 v0, p0, 0x10

    and-int/lit16 v0, v0, 0xff

    shr-int/lit8 v1, p0, 0x8

    and-int/lit16 v1, v1, 0xff

    and-int/lit16 p0, p0, 0xff

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v0, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    sub-int v3, v2, v3

    int-to-float v3, v3

    const/high16 v4, 0x41400000    # 12.0f

    const/4 v5, 0x0

    cmpg-float v4, v3, v4

    if-gez v4, :cond_25

    return v5

    :cond_25
    const/high16 v4, 0x42700000    # 60.0f

    if-ne v2, v0, :cond_2f

    sub-int/2addr v1, p0

    int-to-float p0, v1

    div-float/2addr p0, v3

    :goto_2c
    mul-float p0, p0, v4

    goto :goto_3e

    :cond_2f
    if-ne v2, v1, :cond_37

    sub-int/2addr p0, v0

    int-to-float p0, p0

    div-float/2addr p0, v3

    const/high16 v0, 0x40000000    # 2.0f

    goto :goto_3c

    :cond_37
    sub-int/2addr v0, v1

    int-to-float p0, v0

    div-float/2addr p0, v3

    const/high16 v0, 0x40800000    # 4.0f

    :goto_3c
    add-float/2addr p0, v0

    goto :goto_2c

    :goto_3e
    const/4 v0, 0x0

    cmpg-float v0, p0, v0

    if-gez v0, :cond_46

    const/high16 v0, 0x43b40000    # 360.0f

    add-float/2addr p0, v0

    :cond_46
    const/high16 v0, 0x43750000    # 245.0f

    cmpl-float v0, p0, v0

    if-ltz v0, :cond_55

    const v0, 0x43b18000    # 355.0f

    cmpg-float p0, p0, v0

    if-gtz p0, :cond_55

    const/4 p0, 0x1

    return p0

    :cond_55
    return v5
.end method

.method public static secondary(IZ)I
    .registers 6

    .line 3
    if-eqz p1, :cond_6

    const v0, 0x3c449ba6    # 0.012f

    goto :goto_9

    :cond_6
    const v0, 0x3d23d70a    # 0.04f

    :goto_9
    const/16 v1, 0xff

    if-eqz p1, :cond_10

    const/16 p1, 0xff

    goto :goto_11

    :cond_10
    const/4 p1, 0x0

    :goto_11
    shr-int/lit8 v2, p0, 0x10

    and-int/2addr v2, v1

    int-to-float v2, v2

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float/2addr v3, v0

    mul-float v2, v2, v3

    int-to-float p1, p1

    mul-float p1, p1, v0

    add-float/2addr v2, p1

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v0

    shr-int/lit8 v2, p0, 0x8

    and-int/2addr v2, v1

    int-to-float v2, v2

    mul-float v2, v2, v3

    add-float/2addr v2, p1

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    and-int/2addr p0, v1

    int-to-float p0, p0

    mul-float p0, p0, v3

    add-float/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/high16 p1, -0x1000000

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p1, v0

    shl-int/lit8 v0, v2, 0x8

    or-int/2addr p1, v0

    or-int/2addr p0, p1

    return p0
.end method
