.class public final synthetic Le/e/a/DirectBackground235$State$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic f$0:Le/e/a/DirectBackground235$State;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Le/e/a/DirectBackground235$State;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/DirectBackground235$State$$ExternalSyntheticLambda0;->f$0:Le/e/a/DirectBackground235$State;

    iput p2, p0, Le/e/a/DirectBackground235$State$$ExternalSyntheticLambda0;->f$1:I

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 4

    .line 0
    iget-object v0, p0, Le/e/a/DirectBackground235$State$$ExternalSyntheticLambda0;->f$0:Le/e/a/DirectBackground235$State;

    iget v1, p0, Le/e/a/DirectBackground235$State$$ExternalSyntheticLambda0;->f$1:I

    invoke-virtual {v0, v1, p1}, Le/e/a/DirectBackground235$State;->lambda$7$e-e-a-DirectBackground235$State(ILandroid/animation/ValueAnimator;)V

    return-void
.end method
