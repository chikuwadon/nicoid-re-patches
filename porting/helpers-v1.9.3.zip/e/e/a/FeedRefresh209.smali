.class public final Le/e/a/FeedRefresh209;
.super Landroid/widget/FrameLayout;
.source "FeedRefresh209.java"


# instance fields
.field private final content:Landroid/view/View;

.field private horizontal:Z

.field private final refresh:Ljava/lang/Runnable;

.field private final refreshing:Ljava/lang/reflect/Method;

.field private final slop:I

.field final swipe:Landroid/view/ViewGroup;

.field private x:F

.field private y:F


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/view/View;Ljava/lang/Runnable;)V
    .registers 12

    .line 13
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Le/e/a/FeedRefresh209;->content:Landroid/view/View;

    iput-object p3, p0, Le/e/a/FeedRefresh209;->refresh:Ljava/lang/Runnable;

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p2

    iput p2, p0, Le/e/a/FeedRefresh209;->slop:I

    .line 15
    :try_start_11
    const-string p2, "androidx.swiperefreshlayout.widget.SwipeRefreshLayout"

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    .line 16
    const/4 p3, 0x2

    new-array v0, p3, [Ljava/lang/Class;

    const-class v1, Landroid/content/Context;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-class v1, Landroid/util/AttributeSet;

    const/4 v3, 0x1

    aput-object v1, v0, v3

    invoke-virtual {p2, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    new-array p3, p3, [Ljava/lang/Object;

    aput-object p1, p3, v2

    const/4 v1, 0x0

    aput-object v1, p3, v3

    invoke-virtual {v0, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/view/ViewGroup;

    iput-object p3, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    .line 17
    const-string p3, "setRefreshing"

    new-array v0, v3, [Ljava/lang/Class;

    sget-object v4, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v4, v0, v2

    invoke-virtual {p2, p3, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p3

    iput-object p3, p0, Le/e/a/FeedRefresh209;->refreshing:Ljava/lang/reflect/Method;

    .line 18
    invoke-virtual {p2}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object p3

    array-length v0, p3
    :try_end_4a
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_4a} :catch_118

    move v4, v2

    :goto_4b
    const-string v5, "setOnRefreshListener"

    if-lt v4, v0, :cond_50

    goto :goto_64

    :cond_50
    :try_start_50
    aget-object v6, p3, v4

    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_114

    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v7

    array-length v7, v7

    if-ne v7, v3, :cond_114

    move-object v1, v6

    .line 19
    :goto_64
    if-eqz v1, :cond_10e

    invoke-virtual {v1}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object p3

    aget-object p3, p3, v2

    .line 20
    invoke-virtual {p3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    new-array v4, v3, [Ljava/lang/Class;

    aput-object p3, v4, v2

    new-instance p3, Le/e/a/FeedRefresh209$$ExternalSyntheticLambda0;

    invoke-direct {p3, p0}, Le/e/a/FeedRefresh209$$ExternalSyntheticLambda0;-><init>(Le/e/a/FeedRefresh209;)V

    invoke-static {v0, v4, p3}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p3

    .line 23
    iget-object v0, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-array v4, v3, [Ljava/lang/Object;

    aput-object p3, v4, v2

    invoke-virtual {v1, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    const-string p3, "setColorSchemeColors"

    new-array v0, v3, [Ljava/lang/Class;

    const-class v1, [I

    aput-object v1, v0, v2

    invoke-virtual {p2, p3, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p3

    iget-object v0, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-array v1, v3, [Ljava/lang/Object;

    new-array v4, v3, [I

    invoke-static {p1}, Le/e/a/UiDialogs;->accent(Landroid/content/Context;)I

    move-result v5

    aput v5, v4, v2

    aput-object v4, v1, v2

    invoke-virtual {p3, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    const-string p3, "setProgressBackgroundColorSchemeColor"

    new-array v0, v3, [Ljava/lang/Class;

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v2

    invoke-virtual {p2, p3, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p3

    iget-object v0, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-array v1, v3, [Ljava/lang/Object;

    invoke-static {p1}, Le/e/a/ThemeChoice;->isNight(Landroid/content/Context;)Z

    move-result v4

    if-eqz v4, :cond_bd

    const v4, -0xd6d4cf

    goto :goto_c0

    :cond_bd
    const v4, -0x50506

    :goto_c0
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v1, v2

    invoke-virtual {p3, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    const-string p3, "setDistanceToTriggerSync"

    new-array v0, v3, [Ljava/lang/Class;

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v2

    invoke-virtual {p2, p3, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p2

    iget-object p3, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-array v0, v3, [Ljava/lang/Object;

    const/16 v1, 0x40

    invoke-static {p1, v1}, Le/e/a/PanelUi;->dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v2

    invoke-virtual {p2, p3, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    new-instance p2, Le/e/a/FeedRefresh209$1;

    invoke-direct {p2, p0, p1}, Le/e/a/FeedRefresh209$1;-><init>(Le/e/a/FeedRefresh209;Landroid/content/Context;)V

    .line 30
    iget-object p1, p0, Le/e/a/FeedRefresh209;->content:Landroid/view/View;

    new-instance p3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v0, -0x1

    invoke-direct {p3, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, p1, p3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-instance p3, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {p3, v0, v0}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    new-instance p2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p2, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, p1, p2}, Le/e/a/FeedRefresh209;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 31
    nop

    .line 32
    return-void

    .line 19
    :cond_10e
    new-instance p1, Ljava/lang/NoSuchMethodException;

    invoke-direct {p1, v5}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_114
    .catch Ljava/lang/Exception; {:try_start_50 .. :try_end_114} :catch_118

    .line 18
    :cond_114
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_4b

    .line 31
    :catch_118
    move-exception p1

    new-instance p2, Ljava/lang/IllegalStateException;

    const-string p3, "Cannot initialize native feed refresh"

    invoke-direct {p2, p3, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method

.method static synthetic access$0(Le/e/a/FeedRefresh209;)Z
    .registers 1

    .line 12
    iget-boolean p0, p0, Le/e/a/FeedRefresh209;->horizontal:Z

    return p0
.end method

.method static synthetic access$1(Le/e/a/FeedRefresh209;)Landroid/view/View;
    .registers 1

    .line 11
    iget-object p0, p0, Le/e/a/FeedRefresh209;->content:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$2(Landroid/view/View;I)Z
    .registers 2

    .line 33
    invoke-static {p0, p1}, Le/e/a/FeedRefresh209;->scrolls(Landroid/view/View;I)Z

    move-result p0

    return p0
.end method

.method private static scrolls(Landroid/view/View;I)Z
    .registers 6

    .line 33
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    return v1

    :cond_8
    invoke-virtual {p0, p1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_10

    return v2

    :cond_10
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2c

    check-cast p0, Landroid/view/ViewGroup;

    move v0, v1

    :goto_17
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-lt v0, v3, :cond_1e

    goto :goto_2c

    :cond_1e
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3, p1}, Le/e/a/FeedRefresh209;->scrolls(Landroid/view/View;I)Z

    move-result v3

    if-eqz v3, :cond_29

    return v2

    :cond_29
    add-int/lit8 v0, v0, 0x1

    goto :goto_17

    :cond_2c
    :goto_2c
    return v1
.end method


# virtual methods
.method synthetic lambda$0$e-e-a-FeedRefresh209(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .line 21
    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, Ljava/lang/Object;

    if-ne v0, v1, :cond_3c

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "hashCode"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    :cond_1d
    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p2

    const-string v0, "equals"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_39

    const/4 p2, 0x0

    aget-object p3, p3, p2

    if-ne p1, p3, :cond_34

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_34
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_39
    const-string p1, "Feed refresh listener"

    return-object p1

    .line 22
    :cond_3c
    iget-object p1, p0, Le/e/a/FeedRefresh209;->refresh:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    const/4 p1, 0x0

    return-object p1
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_16

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Le/e/a/FeedRefresh209;->x:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iput p1, p0, Le/e/a/FeedRefresh209;->y:F

    iput-boolean v1, p0, Le/e/a/FeedRefresh209;->horizontal:Z

    goto :goto_4c

    :cond_16
    const/4 v2, 0x2

    if-ne v0, v2, :cond_4c

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v2, p0, Le/e/a/FeedRefresh209;->x:F

    sub-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v2, p0, Le/e/a/FeedRefresh209;->slop:I

    int-to-float v2, v2

    cmpl-float v0, v0, v2

    if-lez v0, :cond_4c

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v2, p0, Le/e/a/FeedRefresh209;->x:F

    sub-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v2, p0, Le/e/a/FeedRefresh209;->y:F

    sub-float/2addr p1, v2

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const v2, 0x3fa66666    # 1.3f

    mul-float/2addr p1, v2

    cmpl-float p1, v0, p1

    if-lez p1, :cond_4c

    const/4 p1, 0x1

    iput-boolean p1, p0, Le/e/a/FeedRefresh209;->horizontal:Z

    :cond_4c
    :goto_4c
    return v1
.end method

.method public setRefreshing(Z)V
    .registers 6

    .line 35
    :try_start_0
    iget-object v0, p0, Le/e/a/FeedRefresh209;->refreshing:Ljava/lang/reflect/Method;

    iget-object v1, p0, Le/e/a/FeedRefresh209;->swipe:Landroid/view/ViewGroup;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x0

    aput-object p1, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_11} :catch_12

    goto :goto_1a

    :catch_12
    move-exception p1

    const-string v0, "nicoid-feed"

    const-string v1, "Cannot update native refresh state"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1a
    return-void
.end method
