.class Le/e/a/FollowFeed$1;
.super Ljava/lang/Object;
.source "FollowFeed.java"

# interfaces
.implements Landroid/widget/AbsListView$OnScrollListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le/e/a/FollowFeed;->load(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$a:Landroid/app/Activity;

.field final synthetic val$state:Le/e/a/FollowFeed$State;


# direct methods
.method constructor <init>(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 114
    iput-object p1, p0, Le/e/a/FollowFeed$1;->val$state:Le/e/a/FollowFeed$State;

    iput-object p2, p0, Le/e/a/FollowFeed$1;->val$a:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onScroll(Landroid/widget/AbsListView;III)V
    .registers 8
    .param p1, "l"    # Landroid/widget/AbsListView;
    .param p2, "first"    # I
    .param p3, "count"    # I
    .param p4, "total"    # I

    .line 117
    iget-object v0, p0, Le/e/a/FollowFeed$1;->val$state:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .local v0, "selected":Le/e/a/FollowFeed$State;
    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->autoLoad:Z

    if-eqz v1, :cond_22

    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->failed:Z

    if-nez v1, :cond_22

    iget-object v1, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_22

    if-lez p3, :cond_22

    add-int v1, p2, p3

    add-int/lit8 v2, p4, -0x1

    if-lt v1, v2, :cond_22

    iget-object v1, p0, Le/e/a/FollowFeed$1;->val$a:Landroid/app/Activity;

    const/4 v2, 0x0

    # invokes: Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V
    invoke-static {v1, v0, v2}, Le/e/a/FollowFeed;->access$100(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    .line 118
    :cond_22
    return-void
.end method

.method public onScrollStateChanged(Landroid/widget/AbsListView;I)V
    .registers 5
    .param p1, "l"    # Landroid/widget/AbsListView;
    .param p2, "mode"    # I

    .line 115
    const/4 v0, 0x1

    if-ne p2, v0, :cond_9

    iget-object v1, p0, Le/e/a/FollowFeed$1;->val$state:Le/e/a/FollowFeed$State;

    iget-object v1, v1, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    iput-boolean v0, v1, Le/e/a/FollowFeed$State;->autoLoad:Z

    :cond_9
    return-void
.end method
