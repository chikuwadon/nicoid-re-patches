.class Le/e/a/FollowFeed$2;
.super Ljava/lang/Object;
.source "FollowFeed.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le/e/a/FollowFeed;->load(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$a:Landroid/app/Activity;

.field final synthetic val$state:Le/e/a/FollowFeed$State;


# direct methods
.method constructor <init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 123
    iput-object p1, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    iput-object p2, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3
    .param p1, "x"    # Landroid/app/Activity;
    .param p2, "b"    # Landroid/os/Bundle;

    .line 124
    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 7
    .param p1, "x"    # Landroid/app/Activity;

    .line 130
    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    if-ne p1, v0, :cond_2e

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_a
    if-ge v2, v1, :cond_1c

    aget-object v3, v0, v2

    .local v3, "page":Le/e/a/FollowFeed$State;
    if-eqz v3, :cond_19

    iget-object v4, v3, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    if-eqz v4, :cond_19

    iget-object v4, v3, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    invoke-virtual {v4}, Le/e/a/NetworkTask;->cancel()V

    .end local v3    # "page":Le/e/a/FollowFeed$State;
    :cond_19
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    :cond_1c
    # getter for: Le/e/a/FollowFeed;->STATES:Ljava/util/WeakHashMap;
    invoke-static {}, Le/e/a/FollowFeed;->access$400()Ljava/util/WeakHashMap;

    move-result-object v0

    iget-object v1, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    invoke-virtual {v0, v1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :cond_2e
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 2
    .param p1, "x"    # Landroid/app/Activity;

    .line 127
    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 7
    .param p1, "x"    # Landroid/app/Activity;

    .line 126
    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    if-ne p1, v0, :cond_37

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v1, :cond_16

    aget-object v4, v0, v3

    .local v4, "page":Le/e/a/FollowFeed$State;
    if-eqz v4, :cond_13

    iput-boolean v2, v4, Le/e/a/FollowFeed$State;->stopped:Z

    .end local v4    # "page":Le/e/a/FollowFeed$State;
    :cond_13
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_16
    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    invoke-static {v0}, Le/e/a/ShortImages;->resume(Landroid/app/Activity;)V

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .local v0, "selected":Le/e/a/FollowFeed$State;
    iget-object v1, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    invoke-static {v1, v0}, Le/e/a/FollowFeed;->access$200(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->busy:Z

    if-nez v1, :cond_37

    iget-object v1, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    invoke-static {v1, v0}, Le/e/a/FollowFeed;->access$300(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->initialized:Z

    if-nez v1, :cond_37

    iget-object v1, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    const/4 v2, 0x1

    # invokes: Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V
    invoke-static {v1, v0, v2}, Le/e/a/FollowFeed;->access$100(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    .end local v0    # "selected":Le/e/a/FollowFeed$State;
    :cond_37
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3
    .param p1, "x"    # Landroid/app/Activity;
    .param p2, "b"    # Landroid/os/Bundle;

    .line 129
    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 2
    .param p1, "x"    # Landroid/app/Activity;

    .line 125
    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 8
    .param p1, "x"    # Landroid/app/Activity;

    .line 128
    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    if-ne p1, v0, :cond_3e

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v1, :cond_30

    aget-object v4, v0, v3

    .local v4, "page":Le/e/a/FollowFeed$State;
    if-eqz v4, :cond_2d

    const/4 v5, 0x1

    iput-boolean v5, v4, Le/e/a/FollowFeed$State;->stopped:Z

    iget-object v5, v4, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    if-eqz v5, :cond_1d

    iget-object v5, v4, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    invoke-virtual {v5}, Le/e/a/NetworkTask;->cancel()V

    :cond_1d
    iget-boolean v5, v4, Le/e/a/FollowFeed$State;->busy:Z

    if-eqz v5, :cond_2b

    iget-object v5, v4, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_2b

    iput-boolean v2, v4, Le/e/a/FollowFeed$State;->initialized:Z

    :cond_2b
    iput-boolean v2, v4, Le/e/a/FollowFeed$State;->busy:Z

    .end local v4    # "page":Le/e/a/FollowFeed$State;
    :cond_2d
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_30
    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$2;->val$state:Le/e/a/FollowFeed$State;

    iget-object v1, v1, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    # invokes: Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    invoke-static {v0, v1}, Le/e/a/FollowFeed;->access$200(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iget-object v0, p0, Le/e/a/FollowFeed$2;->val$a:Landroid/app/Activity;

    invoke-static {v0}, Le/e/a/ShortImages;->cancel(Landroid/app/Activity;)V

    :cond_3e
    return-void
.end method
