.class public final synthetic Le/e/a/FollowFeed$6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/IntConsumer;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Le/e/a/FollowFeed;"
    method = "lambda$load$1"
    proto = "(Landroid/app/Activity;Le/e/a/FollowFeed$State;I)V"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Le/e/a/FollowFeed$State;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/FollowFeed$6;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Le/e/a/FollowFeed$6;->f$1:Le/e/a/FollowFeed$State;

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .registers 4

    .line 0
    iget-object v0, p0, Le/e/a/FollowFeed$6;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$6;->f$1:Le/e/a/FollowFeed$State;

    invoke-static {v0, v1, p1}, Le/e/a/FollowFeed;->lambda$load$1(Landroid/app/Activity;Le/e/a/FollowFeed$State;I)V

    return-void
.end method
