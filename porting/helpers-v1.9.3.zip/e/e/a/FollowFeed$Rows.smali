.class final Le/e/a/FollowFeed$Rows;
.super Landroid/widget/BaseAdapter;
.source "FollowFeed.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Le/e/a/FollowFeed;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Rows"
.end annotation


# instance fields
.field final a:Landroid/app/Activity;

.field final s:Le/e/a/FollowFeed$State;


# direct methods
.method constructor <init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 3
    .param p1, "a"    # Landroid/app/Activity;
    .param p2, "s"    # Le/e/a/FollowFeed$State;

    .line 315
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    iput-object p1, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iput-object p2, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    return-void
.end method


# virtual methods
.method public areAllItemsEnabled()Z
    .registers 2

    .line 321
    const/4 v0, 0x0

    return v0
.end method

.method public getCount()I
    .registers 3

    .line 316
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .registers 3
    .param p1, "i"    # I

    .line 317
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_c

    const/4 v0, 0x0

    goto :goto_14

    :cond_c
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    :goto_14
    return-object v0
.end method

.method public getItemId(I)J
    .registers 4
    .param p1, "i"    # I

    .line 318
    int-to-long v0, p1

    return-wide v0
.end method

.method public getItemViewType(I)I
    .registers 3
    .param p1, "i"    # I

    .line 320
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_c

    const/4 v0, 0x2

    goto :goto_1b

    :cond_c
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-object v0, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Ljava/lang/Integer;

    if-eqz v0, :cond_1a

    const/4 v0, 0x0

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x1

    :goto_1b
    return v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 21
    .param p1, "index"    # I
    .param p2, "recycled"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 323
    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-virtual/range {p0 .. p1}, Le/e/a/FollowFeed$Rows;->getItem(I)Ljava/lang/Object;

    move-result-object v2

    .line 324
    .local v2, "value":Ljava/lang/Object;
    const/16 v3, 0x18

    const/16 v4, 0x30

    const/4 v5, 0x0

    if-nez v2, :cond_69

    .line 325
    instance-of v6, v1, Landroid/widget/TextView;

    if-eqz v6, :cond_17

    move-object v5, v1

    check-cast v5, Landroid/widget/TextView;

    goto :goto_1f

    :cond_17
    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v7, 0xf

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v6, v7, v5}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v5

    .local v5, "empty":Landroid/widget/TextView;
    :goto_1f
    const/16 v6, 0x11

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 326
    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v6, v3}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v6

    iget-object v7, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v7, v4}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v7

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v3}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v3

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v4}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v5, v6, v7, v3, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 327
    iget-object v3, v0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-boolean v3, v3, Le/e/a/FollowFeed$State;->busy:Z

    if-eqz v3, :cond_48

    const-string v3, ""

    goto :goto_65

    :cond_48
    iget-object v3, v0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    iget-boolean v3, v3, Le/e/a/FollowFeed$State;->failed:Z

    .line 328
    iget-object v4, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    .line 327
    if-eqz v3, :cond_5b

    const-string v3, "Could not load activity"

    const-string v6, "\u7121\u6cd5\u8f09\u5165\u52d5\u614b"

    const-string v7, "\u65b0\u7740\u3092\u53d6\u5f97\u3067\u304d\u307e\u305b\u3093\u3067\u3057\u305f"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v4, v7, v3, v6}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_65

    .line 328
    :cond_5b
    const-string v3, "No activity matches these filters"

    const-string v6, "\u6c92\u6709\u7b26\u5408\u6b64\u689d\u4ef6\u7684\u52d5\u614b"

    const-string v7, "\u3053\u306e\u6761\u4ef6\u306b\u4e00\u81f4\u3059\u308b\u65b0\u7740\u306f\u3042\u308a\u307e\u305b\u3093"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v4, v7, v3, v6}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 327
    :goto_65
    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 329
    return-object v5

    .line 331
    .end local v5    # "empty":Landroid/widget/TextView;
    :cond_69
    instance-of v6, v2, Ljava/lang/Integer;

    const/16 v7, 0xc

    const/16 v8, 0x10

    const/4 v9, 0x1

    if-eqz v6, :cond_ac

    .line 332
    instance-of v4, v1, Landroid/widget/TextView;

    if-eqz v4, :cond_7a

    move-object v4, v1

    check-cast v4, Landroid/widget/TextView;

    goto :goto_80

    :cond_7a
    iget-object v4, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v4, v8, v9}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v4

    .line 333
    .local v4, "heading":Landroid/widget/TextView;
    :goto_80
    iget-object v5, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v5, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v6, v3}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v3

    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v6, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v6

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v7}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v4, v5, v3, v6, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v3, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    move-object v5, v2

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    # invokes: Le/e/a/FollowFeed;->period(Landroid/content/Context;I)Ljava/lang/String;
    invoke-static {v3, v5}, Le/e/a/FollowFeed;->access$900(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-object v4

    .line 335
    .end local v4    # "heading":Landroid/widget/TextView;
    :cond_ac
    move-object v3, v2

    check-cast v3, Le/e/a/FollowFeedData$Item;

    .line 336
    .local v3, "item":Le/e/a/FollowFeedData$Item;
    if-nez v1, :cond_32f

    .line 337
    new-instance v10, Le/e/a/FeedLayout194;

    iget-object v11, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v10, v11}, Le/e/a/FeedLayout194;-><init>(Landroid/content/Context;)V

    .local v10, "row":Landroid/widget/LinearLayout;
    invoke-virtual {v10, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v11, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v11, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v12, v7}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v12

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v14, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v14, v7}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    new-instance v11, Le/e/a/FollowFeed$Holder;

    const/4 v12, 0x0

    invoke-direct {v11, v12}, Le/e/a/FollowFeed$Holder;-><init>(Le/e/a/FollowFeed$1;)V

    .line 338
    .local v11, "h":Le/e/a/FollowFeed$Holder;
    new-instance v12, Landroid/widget/LinearLayout;

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v12, v13}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v12, "actor":Landroid/widget/LinearLayout;
    invoke-virtual {v12, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 339
    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->imageBox(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;
    invoke-static {v13, v9}, Le/e/a/FollowFeed;->access$1100(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;

    move-result-object v13

    iput-object v13, v11, Le/e/a/FollowFeed$Holder;->avatar:Landroid/widget/FrameLayout;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->avatar:Landroid/widget/FrameLayout;

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v4, 0x28

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v4}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v15

    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v6, v4}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v4

    invoke-direct {v14, v15, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v13, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 340
    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v4, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v4, "words":Landroid/widget/LinearLayout;
    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v6, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v6, v7}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v6, v5, v5, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 341
    new-instance v6, Landroid/widget/LinearLayout;

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v6, v13}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v6, "top":Landroid/widget/LinearLayout;
    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 342
    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v14, 0xe

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v13, v14, v5}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v13

    iput-object v13, v11, Le/e/a/FollowFeed$Holder;->name:Landroid/widget/TextView;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->name:Landroid/widget/TextView;

    invoke-virtual {v13, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->name:Landroid/widget/TextView;

    sget-object v15, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v13, v15}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 343
    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->name:Landroid/widget/TextView;

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v15, v5, v14, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v13, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v13, v7, v5}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v13

    iput-object v13, v11, Le/e/a/FollowFeed$Holder;->date:Landroid/widget/TextView;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->date:Landroid/widget/TextView;

    const v15, 0x3f266666    # 0.65f

    invoke-virtual {v13, v15}, Landroid/widget/TextView;->setAlpha(F)V

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->date:Landroid/widget/TextView;

    invoke-virtual {v6, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 344
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v13, v7, v5}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v13

    iput-object v13, v11, Le/e/a/FollowFeed$Holder;->event:Landroid/widget/TextView;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->event:Landroid/widget/TextView;

    const v15, 0x3f333333    # 0.7f

    invoke-virtual {v13, v15}, Landroid/widget/TextView;->setAlpha(F)V

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->event:Landroid/widget/TextView;

    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v13, v5, v14, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v12, v4, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v10, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 345
    new-instance v13, Landroid/widget/LinearLayout;

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v13, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v13, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    invoke-virtual {v13, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-static {v8}, Le/e/a/Ui110;->actionColor(Landroid/content/Context;)I

    move-result v8

    # invokes: Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v15, v8, v7, v9}, Le/e/a/FollowFeed;->access$1200(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-virtual {v13, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v7, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setClipToOutline(Z)V

    .line 346
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x1

    invoke-direct {v7, v8, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .local v7, "cardParams":Landroid/widget/LinearLayout$LayoutParams;
    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v15, 0x34

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v15}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v9, 0x8

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v9}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v7, v13, v15, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v9, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 347
    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->imageBox(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;
    invoke-static {v9, v5}, Le/e/a/FollowFeed;->access$1100(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;

    move-result-object v9

    iput-object v9, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    iget-object v13, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v15, v8, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v13, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 348
    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v13, 0xb

    const/4 v15, 0x1

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v9, v13, v15}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v9

    iput-object v9, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/4 v8, 0x5

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v15

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/4 v14, 0x2

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v5, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v5, v8}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v5

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v9, v15, v13, v5, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v5, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const v9, -0x44eeeeef

    const/4 v13, 0x3

    const/4 v15, 0x0

    # invokes: Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v8, v9, v13, v15}, Le/e/a/FollowFeed;->access$1200(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 349
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const v8, 0x800033

    const/4 v9, -0x2

    invoke-direct {v5, v9, v9, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .local v5, "badge":Landroid/widget/FrameLayout$LayoutParams;
    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v9, 0x8

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v9}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v8

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v9}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v5, v8, v13, v15, v15}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    iget-object v8, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    invoke-virtual {v8, v9, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 350
    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v9, 0xb

    const/4 v15, 0x1

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v8, v9, v15}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v8

    iput-object v8, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    iget-object v8, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    const/4 v9, -0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v8, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/4 v13, 0x5

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v9, v13}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v9

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v15

    iget-object v14, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v14, v13}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v14, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/4 v1, 0x2

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v14, v1}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v8, v9, v15, v13, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const v9, -0x44eeeeef

    const/4 v13, 0x3

    const/4 v15, 0x0

    # invokes: Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v8, v9, v13, v15}, Le/e/a/FollowFeed;->access$1200(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 351
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const v8, 0x800055

    const/4 v9, -0x2

    invoke-direct {v1, v9, v9, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .local v1, "duration":Landroid/widget/FrameLayout$LayoutParams;
    iget-object v8, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v9, 0x8

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v8, v9}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v8

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v9}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v1, v15, v15, v8, v13}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    iget-object v8, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    invoke-virtual {v8, v9, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 352
    new-instance v8, Landroid/widget/LinearLayout;

    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v9, 0x10

    .local v8, "bottom":Landroid/widget/LinearLayout;
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v13, 0xa

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v9, v13}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v9

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v14, 0x8

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v15

    const/4 v14, 0x0

    invoke-virtual {v8, v9, v13, v14, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 353
    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v13, 0xe

    # invokes: Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    invoke-static {v9, v13, v14}, Le/e/a/FollowFeed;->access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v9

    iput-object v9, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    const/4 v13, 0x3

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setMaxLines(I)V

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    sget-object v13, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    iget-object v9, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v1

    const/4 v1, -0x2

    const/high16 v15, 0x3f800000    # 1.0f

    .end local v1    # "duration":Landroid/widget/FrameLayout$LayoutParams;
    .local v16, "duration":Landroid/widget/FrameLayout$LayoutParams;
    invoke-direct {v13, v14, v1, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v9, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 354
    iget-object v1, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v9, "\u22ee"

    # invokes: Le/e/a/FollowFeed;->chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;
    invoke-static {v1, v9}, Le/e/a/FollowFeed;->access$1300(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    invoke-static {v1}, Le/e/a/Ui110;->circle(Landroid/view/View;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    const/high16 v9, 0x41c00000    # 24.0f

    invoke-virtual {v1, v9}, Landroid/widget/Button;->setTextSize(F)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    const/4 v15, 0x0

    invoke-virtual {v1, v15, v15, v15, v15}, Landroid/widget/Button;->setPadding(IIII)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    iget-object v9, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v13, "Video menu"

    const-string v14, "\u5f71\u7247\u9078\u55ae"

    const-string v15, "\u52d5\u753b\u30e1\u30cb\u30e5\u30fc"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v9, v15, v13, v14}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v9}, Landroid/widget/Button;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    iget-object v13, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const/16 v14, 0x30

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v13, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v13

    iget-object v15, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I
    invoke-static {v15, v14}, Le/e/a/FollowFeed;->access$700(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v9, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 355
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setTag(Ljava/lang/Object;)V

    .line 356
    .end local v4    # "words":Landroid/widget/LinearLayout;
    .end local v5    # "badge":Landroid/widget/FrameLayout$LayoutParams;
    .end local v6    # "top":Landroid/widget/LinearLayout;
    .end local v7    # "cardParams":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8    # "bottom":Landroid/widget/LinearLayout;
    .end local v12    # "actor":Landroid/widget/LinearLayout;
    .end local v16    # "duration":Landroid/widget/FrameLayout$LayoutParams;
    goto :goto_33a

    .end local v10    # "row":Landroid/widget/LinearLayout;
    .end local v11    # "h":Le/e/a/FollowFeed$Holder;
    :cond_32f
    move-object/from16 v10, p2

    check-cast v10, Landroid/widget/LinearLayout;

    .restart local v10    # "row":Landroid/widget/LinearLayout;
    invoke-virtual {v10}, Landroid/widget/LinearLayout;->getTag()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Le/e/a/FollowFeed$Holder;

    .line 357
    .restart local v11    # "h":Le/e/a/FollowFeed$Holder;
    :goto_33a
    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->name:Landroid/widget/TextView;

    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->actor:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_34f

    iget-object v4, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v5, "Creator"

    const-string v6, "\u6295\u7a3f\u8005"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v4, v6, v5, v6}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_351

    :cond_34f
    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->actor:Ljava/lang/String;

    :goto_351
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->date:Landroid/widget/TextView;

    invoke-static {v3}, Le/e/a/FollowFeedData;->date(Le/e/a/FollowFeedData$Item;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->event:Landroid/widget/TextView;

    iget-object v4, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->event(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    invoke-static {v4, v3}, Le/e/a/FollowFeed;->access$1400(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 358
    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->title:Ljava/lang/String;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->badge:Landroid/widget/TextView;

    iget-object v4, v0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    # invokes: Le/e/a/FollowFeed;->badge(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    invoke-static {v4, v3}, Le/e/a/FollowFeed;->access$1500(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    iget v4, v3, Le/e/a/FollowFeedData$Item;->duration:I

    invoke-static {v4}, Le/e/a/FollowFeedData;->duration(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->duration:Landroid/widget/TextView;

    iget v4, v3, Le/e/a/FollowFeedData$Item;->duration:I

    if-lez v4, :cond_38d

    const/4 v5, 0x0

    goto :goto_38f

    :cond_38d
    const/16 v5, 0x8

    :goto_38f
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 359
    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->avatar:Landroid/widget/FrameLayout;

    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->author:Le/e/a/FollowFeedData$Actor;

    iget-object v4, v4, Le/e/a/FollowFeedData$Actor;->icon:Ljava/lang/String;

    # invokes: Le/e/a/FollowFeed;->bindImage(Landroid/widget/FrameLayout;Ljava/lang/String;)V
    invoke-static {v1, v4}, Le/e/a/FollowFeed;->access$1600(Landroid/widget/FrameLayout;Ljava/lang/String;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->thumbnail:Ljava/lang/String;

    # invokes: Le/e/a/FollowFeed;->bindImage(Landroid/widget/FrameLayout;Ljava/lang/String;)V
    invoke-static {v1, v4}, Le/e/a/FollowFeed;->access$1600(Landroid/widget/FrameLayout;Ljava/lang/String;)V

    .line 360
    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    iget-object v4, v3, Le/e/a/FollowFeedData$Item;->title:Ljava/lang/String;

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->card:Landroid/widget/LinearLayout;

    new-instance v4, Le/e/a/FollowFeed$Rows$3;

    invoke-direct {v4, v0, v3}, Le/e/a/FollowFeed$Rows$3;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->thumbnail:Landroid/widget/FrameLayout;

    new-instance v4, Le/e/a/FollowFeed$Rows$4;

    invoke-direct {v4, v0, v3}, Le/e/a/FollowFeed$Rows$4;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-virtual {v1, v4}, Landroid/widget/FrameLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->title:Landroid/widget/TextView;

    new-instance v4, Le/e/a/FollowFeed$Rows$5;

    invoke-direct {v4, v0, v3}, Le/e/a/FollowFeed$Rows$5;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 361
    iget-object v1, v11, Le/e/a/FollowFeed$Holder;->menu:Landroid/widget/Button;

    new-instance v4, Le/e/a/FollowFeed$Rows$6;

    invoke-direct {v4, v0, v3}, Le/e/a/FollowFeed$Rows$6;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 369
    return-object v10
.end method

.method public getViewTypeCount()I
    .registers 2

    .line 319
    const/4 v0, 0x3

    return v0
.end method

.method public isEnabled(I)Z
    .registers 4
    .param p1, "i"    # I

    .line 321
    invoke-virtual {p0, p1}, Le/e/a/FollowFeed$Rows;->getItemViewType(I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_8

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    return v1
.end method

.method synthetic lambda$getView$0$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/View;)V
    .registers 6
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "v"    # Landroid/view/View;

    .line 360
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    const/4 v2, 0x0

    # invokes: Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    invoke-static {v0, v1, p1, v2}, Le/e/a/FollowFeed;->access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    return-void
.end method

.method synthetic lambda$getView$1$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/View;)V
    .registers 6
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "v"    # Landroid/view/View;

    .line 360
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    const/4 v2, 0x0

    # invokes: Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    invoke-static {v0, v1, p1, v2}, Le/e/a/FollowFeed;->access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    return-void
.end method

.method synthetic lambda$getView$2$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/View;)V
    .registers 6
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "v"    # Landroid/view/View;

    .line 360
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    const/4 v2, 0x0

    # invokes: Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    invoke-static {v0, v1, p1, v2}, Le/e/a/FollowFeed;->access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    return-void
.end method

.method synthetic lambda$getView$3$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/MenuItem;)Z
    .registers 6
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "m"    # Landroid/view/MenuItem;

    .line 363
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    const/4 v2, 0x0

    # invokes: Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    invoke-static {v0, v1, p1, v2}, Le/e/a/FollowFeed;->access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    const/4 v0, 0x1

    return v0
.end method

.method synthetic lambda$getView$4$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/MenuItem;)Z
    .registers 6
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "m"    # Landroid/view/MenuItem;

    .line 364
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->s:Le/e/a/FollowFeed$State;

    const/4 v2, 0x1

    # invokes: Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    invoke-static {v0, v1, p1, v2}, Le/e/a/FollowFeed;->access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    return v2
.end method

.method synthetic lambda$getView$5$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/MenuItem;)Z
    .registers 9
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "m"    # Landroid/view/MenuItem;

    .line 366
    iget-object v0, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.SEND"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "text/plain"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "https://www.nicovideo.jp/watch/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Le/e/a/FollowFeedData$Item;->id:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "android.intent.extra.TEXT"

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    iget-object v2, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v3, "Share"

    const-string v4, "\u5206\u4eab"

    const-string v5, "\u5171\u6709"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v2, v5, v3, v4}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v0, 0x1

    return v0
.end method

.method synthetic lambda$getView$6$e-e-a-FollowFeed$Rows(Le/e/a/FollowFeedData$Item;Landroid/view/View;)V
    .registers 9
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;
    .param p2, "v"    # Landroid/view/View;

    .line 362
    new-instance v0, Landroid/widget/PopupMenu;

    iget-object v1, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    invoke-static {v1}, Le/e/a/UiTheme191;->context(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p2}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    .line 363
    .local v0, "menu":Landroid/widget/PopupMenu;
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    iget-object v2, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v3, "Play"

    const-string v4, "\u64ad\u653e"

    const-string v5, "\u518d\u751f"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v2, v5, v3, v4}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Landroid/view/Menu;->add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v1

    new-instance v2, Le/e/a/FollowFeed$Rows$0;

    invoke-direct {v2, p0, p1}, Le/e/a/FollowFeed$Rows$0;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-interface {v1, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 364
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    iget-object v2, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v3, "Video details"

    const-string v4, "\u5f71\u7247\u8cc7\u8a0a"

    const-string v5, "\u52d5\u753b\u60c5\u5831"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v2, v5, v3, v4}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Landroid/view/Menu;->add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v1

    new-instance v2, Le/e/a/FollowFeed$Rows$1;

    invoke-direct {v2, p0, p1}, Le/e/a/FollowFeed$Rows$1;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-interface {v1, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 365
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v1

    iget-object v2, p0, Le/e/a/FollowFeed$Rows;->a:Landroid/app/Activity;

    const-string v3, "Share"

    const-string v4, "\u5206\u4eab"

    const-string v5, "\u5171\u6709"

    # invokes: Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v2, v5, v3, v4}, Le/e/a/FollowFeed;->access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Landroid/view/Menu;->add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v1

    new-instance v2, Le/e/a/FollowFeed$Rows$2;

    invoke-direct {v2, p0, p1}, Le/e/a/FollowFeed$Rows$2;-><init>(Le/e/a/FollowFeed$Rows;Le/e/a/FollowFeedData$Item;)V

    invoke-interface {v1, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 367
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->show()V

    .line 368
    return-void
.end method
