.class public final Le/e/a/FollowFeed;
.super Ljava/lang/Object;
.source "FollowFeed.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le/e/a/FollowFeed$State;,
        Le/e/a/FollowFeed$Rows;,
        Le/e/a/FollowFeed$LoginRequired;,
        Le/e/a/FollowFeed$Thumbnail;,
        Le/e/a/FollowFeed$Holder;
    }
.end annotation


# static fields
.field private static final MAIN:Landroid/os/Handler;

.field private static final STATES:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/app/Activity;",
            "Le/e/a/FollowFeed$State;",
            ">;"
        }
    .end annotation
.end field

.field private static final WORKER:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 21
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Le/e/a/FollowFeed;->MAIN:Landroid/os/Handler;

    .line 22
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Le/e/a/FollowFeed;->WORKER:Ljava/util/concurrent/ExecutorService;

    .line 23
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Le/e/a/FollowFeed;->STATES:Ljava/util/WeakHashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$100(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V
    .registers 3
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeed$State;
    .param p2, "x2"    # Z

    .line 20
    invoke-static {p0, p1, p2}, Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    return-void
.end method

.method static synthetic access$1100(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;
    .registers 3
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Z

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->imageBox(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1200(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;
    .registers 5
    .param p0, "x0"    # Landroid/content/Context;
    .param p1, "x1"    # I
    .param p2, "x2"    # I
    .param p3, "x3"    # Z

    .line 20
    invoke-static {p0, p1, p2, p3}, Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1300(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;
    .registers 3
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Ljava/lang/String;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1400(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    .registers 3
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeedData$Item;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->event(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1500(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    .registers 3
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeedData$Item;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->badge(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1600(Landroid/widget/FrameLayout;Ljava/lang/String;)V
    .registers 2
    .param p0, "x0"    # Landroid/widget/FrameLayout;
    .param p1, "x1"    # Ljava/lang/String;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->bindImage(Landroid/widget/FrameLayout;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1700(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    .registers 4
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeed$State;
    .param p2, "x2"    # Le/e/a/FollowFeedData$Item;
    .param p3, "x3"    # Z

    .line 20
    invoke-static {p0, p1, p2, p3}, Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    return-void
.end method

.method static synthetic access$200(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 2
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeed$State;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    return-void
.end method

.method static synthetic access$300(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 2
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # Le/e/a/FollowFeed$State;

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    return-void
.end method

.method static synthetic access$400()Ljava/util/WeakHashMap;
    .registers 1

    .line 20
    sget-object v0, Le/e/a/FollowFeed;->STATES:Ljava/util/WeakHashMap;

    return-object v0
.end method

.method static synthetic access$600(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    .registers 4
    .param p0, "x0"    # Landroid/app/Activity;
    .param p1, "x1"    # I
    .param p2, "x2"    # Z

    .line 20
    invoke-static {p0, p1, p2}, Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$700(Landroid/content/Context;I)I
    .registers 3
    .param p0, "x0"    # Landroid/content/Context;
    .param p1, "x1"    # I

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v0

    return v0
.end method

.method static synthetic access$800(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5
    .param p0, "x0"    # Landroid/content/Context;
    .param p1, "x1"    # Ljava/lang/String;
    .param p2, "x2"    # Ljava/lang/String;
    .param p3, "x3"    # Ljava/lang/String;

    .line 20
    invoke-static {p0, p1, p2, p3}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$900(Landroid/content/Context;I)Ljava/lang/String;
    .registers 3
    .param p0, "x0"    # Landroid/content/Context;
    .param p1, "x1"    # I

    .line 20
    invoke-static {p0, p1}, Le/e/a/FollowFeed;->period(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static badge(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    .registers 5
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;

    .line 287
    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->label:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->label:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 288
    :cond_13
    iget-boolean v0, p1, Le/e/a/FollowFeedData$Item;->shortVideo:Z

    if-eqz v0, :cond_22

    const-string v0, "Short upload"

    const-string v1, "\u77ed\u5f71\u7247\u6295\u7a3f"

    const-string v2, "\u30b7\u30e7\u30fc\u30c8\u6295\u7a3f"

    invoke-static {p0, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_37

    .line 289
    :cond_22
    iget-boolean v0, p1, Le/e/a/FollowFeedData$Item;->upload:Z

    if-eqz v0, :cond_2d

    const-string v0, "Video upload"

    const-string v1, "\u5f71\u7247\u6295\u7a3f"

    const-string v2, "\u52d5\u753b\u6295\u7a3f"

    goto :goto_33

    :cond_2d
    const-string v0, "Video"

    const-string v1, "\u5f71\u7247"

    const-string v2, "\u52d5\u753b"

    :goto_33
    invoke-static {p0, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 288
    :goto_37
    return-object v0
.end method

.method private static bindImage(Landroid/widget/FrameLayout;Ljava/lang/String;)V
    .registers 7
    .param p0, "box"    # Landroid/widget/FrameLayout;
    .param p1, "url"    # Ljava/lang/String;

    .line 282
    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroid/view/View;

    .local v0, "views":[Landroid/view/View;
    const/4 v1, 0x0

    aget-object v2, v0, v1

    check-cast v2, Landroid/widget/ImageView;

    .local v2, "image":Landroid/widget/ImageView;
    const/4 v3, 0x1

    aget-object v3, v0, v3

    check-cast v3, Landroid/widget/TextView;

    .line 283
    .local v3, "fallback":Landroid/widget/TextView;
    invoke-virtual {v2}, Landroid/widget/ImageView;->getTag()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_21

    invoke-virtual {v2}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_21

    return-void

    .line 284
    :cond_21
    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v2, p1}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-static {p1, v2, v3}, Le/e/a/ShortImages;->load(Ljava/lang/String;Landroid/widget/ImageView;Landroid/widget/TextView;)V

    .line 285
    return-void
.end method

.method private static chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;
    .registers 8
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "title"    # Ljava/lang/String;

    .line 65
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .local v0, "b":Landroid/widget/Button;
    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextSize(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 66
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setMinHeight(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setMinimumHeight(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setMinWidth(I)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setMinimumWidth(I)V

    .line 67
    const/16 v2, 0x10

    invoke-static {p0, v2}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v3

    const/4 v4, 0x6

    invoke-static {p0, v4}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v5

    invoke-static {p0, v2}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-static {p0, v4}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v0, v3, v5, v2, v4}, Landroid/widget/Button;->setPadding(IIII)V

    invoke-static {p0}, Le/e/a/FollowFeed;->surface(Landroid/content/Context;)I

    move-result v2

    const/16 v3, 0x18

    invoke-static {p0, v2, v3, v1}, Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 68
    invoke-static {v0}, Le/e/a/ThemeChoice;->textColor(Landroid/view/View;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextColor(I)V

    return-object v0
.end method

.method private static chooseActor(Landroid/app/Activity;Le/e/a/FollowFeed$State;Ljava/lang/String;)V
    .registers 11
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "page"    # Le/e/a/FollowFeed$State;
    .param p2, "key"    # Ljava/lang/String;

    .line 240
    iget-object v0, p1, Le/e/a/FollowFeed$State;->session:Le/e/a/FollowFeed$State;

    if-nez v0, :cond_6

    move-object v0, p1

    goto :goto_8

    :cond_6
    iget-object v0, p1, Le/e/a/FollowFeed$State;->session:Le/e/a/FollowFeed$State;

    .line 241
    .local v0, "session":Le/e/a/FollowFeed$State;
    :goto_8
    iput-object p2, v0, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    iget-object v1, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/FollowFeedData$Actor;

    .local v1, "chosen":Le/e/a/FollowFeedData$Actor;
    if-eqz v1, :cond_19

    iget-object v2, v0, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, p2, v1}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 242
    :cond_19
    iget-object v2, v0, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    const/4 v3, 0x0

    if-eqz v2, :cond_39

    iget-object v2, v0, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    array-length v4, v2

    const/4 v5, 0x0

    :goto_22
    if-ge v5, v4, :cond_39

    aget-object v6, v2, v5

    .local v6, "state":Le/e/a/FollowFeed$State;
    if-eqz v6, :cond_36

    iput-object p2, v6, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    if-eqz v1, :cond_31

    iget-object v7, v6, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v7, p2, v1}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_31
    const/4 v7, 0x0

    iput-object v7, v6, Le/e/a/FollowFeed$State;->authorStamp:Ljava/lang/String;

    iput-object v7, v6, Le/e/a/FollowFeed$State;->scroll:Landroid/os/Parcelable;

    .end local v6    # "state":Le/e/a/FollowFeed$State;
    :cond_36
    add-int/lit8 v5, v5, 0x1

    goto :goto_22

    .line 243
    :cond_39
    iput-object p2, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->renderAuthors(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iget-object v2, p1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setSelection(I)V

    .line 244
    return-void
.end method

.method private static color(Landroid/content/Context;II)I
    .registers 6
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "attr"    # I
    .param p2, "fallback"    # I

    .line 47
    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 48
    .local v0, "v":Landroid/util/TypedValue;
    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, p1, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result v1

    if-nez v1, :cond_11

    return p2

    .line 49
    :cond_11
    iget v1, v0, Landroid/util/TypedValue;->resourceId:I

    if-nez v1, :cond_18

    iget v1, v0, Landroid/util/TypedValue;->data:I

    goto :goto_22

    :cond_18
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    iget v2, v0, Landroid/util/TypedValue;->resourceId:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    :goto_22
    return v1
.end method

.method private static cookie(Landroid/app/Activity;)Ljava/lang/String;
    .registers 2
    .param p0, "a"    # Landroid/app/Activity;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 161
    const-string v0, "E"

    invoke-static {p0, v0}, Le/e/a/PlaybackSession;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {p0, v0}, Le/e/a/SessionCookies194;->cookie(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static dp(Landroid/content/Context;I)I
    .registers 4
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "v"    # I

    .line 40
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float v0, v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method private static event(Landroid/app/Activity;Le/e/a/FollowFeedData$Item;)Ljava/lang/String;
    .registers 5
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "item"    # Le/e/a/FollowFeedData$Item;

    .line 292
    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->message:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_13

    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->message:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 293
    :cond_13
    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->subMessage:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_26

    iget-object v0, p1, Le/e/a/FollowFeedData$Item;->subMessage:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 294
    :cond_26
    iget-boolean v0, p1, Le/e/a/FollowFeedData$Item;->upload:Z

    if-eqz v0, :cond_40

    iget-boolean v0, p1, Le/e/a/FollowFeedData$Item;->shortVideo:Z

    if-eqz v0, :cond_39

    const-string v0, "Uploaded a short video"

    const-string v1, "\u6295\u7a3f\u4e86\u77ed\u5f71\u7247"

    const-string v2, "\u30b7\u30e7\u30fc\u30c8\u52d5\u753b\u3092\u6295\u7a3f\u3057\u307e\u3057\u305f"

    invoke-static {p0, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_4a

    .line 295
    :cond_39
    const-string v0, "Uploaded a video"

    const-string v1, "\u6295\u7a3f\u4e86\u5f71\u7247"

    const-string v2, "\u52d5\u753b\u3092\u6295\u7a3f\u3057\u307e\u3057\u305f"

    goto :goto_46

    :cond_40
    const-string v0, "Video activity"

    const-string v1, "\u5f71\u7247\u52d5\u614b"

    const-string v2, "\u52d5\u753b\u306e\u30a2\u30af\u30c6\u30a3\u30d3\u30c6\u30a3"

    :goto_46
    invoke-static {p0, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 294
    :goto_4a
    return-object v0
.end method

.method private static fetch(Ljava/lang/String;Ljava/lang/String;Le/e/a/NetworkTask;)Lorg/json/JSONObject;
    .registers 12
    .param p0, "path"    # Ljava/lang/String;
    .param p1, "auth"    # Ljava/lang/String;
    .param p2, "task"    # Le/e/a/NetworkTask;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 164
    new-instance v0, Ljava/net/URL;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "https://api.feed.nicovideo.jp/v1/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;

    .line 165
    .local v0, "c":Ljava/net/HttpURLConnection;
    invoke-virtual {p2, v0}, Le/e/a/NetworkTask;->bind(Ljava/net/HttpURLConnection;)Z

    move-result v1

    if-eqz v1, :cond_ea

    .line 167
    const/16 v1, 0x2710

    :try_start_26
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 168
    const-string v2, "X-Frontend-Id"

    const-string v3, "6"

    invoke-virtual {v0, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "X-Frontend-Version"

    const-string v3, "0"

    invoke-virtual {v0, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "Cookie"

    invoke-virtual {v0, v2, p1}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 169
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    .local v2, "code":I
    const/16 v3, 0x191

    if-eq v2, v3, :cond_db

    const/16 v3, 0x193

    if-eq v2, v3, :cond_db

    const/16 v3, 0xc8

    if-ne v2, v3, :cond_c2

    .line 170
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 171
    .local v3, "body":Ljava/lang/StringBuilder;
    new-instance v4, Ljava/io/InputStreamReader;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    const-string v6, "UTF-8"

    invoke-direct {v4, v5, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V
    :try_end_63
    .catchall {:try_start_26 .. :try_end_63} :catchall_e2

    .line 172
    .local v4, "reader":Ljava/io/Reader;
    const/16 v5, 0x1000

    :try_start_65
    new-array v5, v5, [C

    .line 173
    .local v5, "buf":[C
    :goto_67
    invoke-virtual {v4, v5}, Ljava/io/Reader;->read([C)I

    move-result v6

    move v7, v6

    .local v7, "n":I
    const/4 v8, -0x1

    if-eq v6, v8, :cond_8f

    invoke-virtual {p2}, Le/e/a/NetworkTask;->cancelled()Z

    move-result v6

    if-nez v6, :cond_89

    invoke-virtual {v3, v5, v1, v7}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    const/high16 v8, 0x400000

    if-gt v6, v8, :cond_81

    goto :goto_67

    :cond_81
    new-instance v1, Ljava/io/IOException;

    const-string v6, "Feed response too large"

    invoke-direct {v1, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    goto :goto_8e

    :cond_89
    new-instance v1, Ljava/io/InterruptedIOException;

    invoke-direct {v1}, Ljava/io/InterruptedIOException;-><init>()V

    .end local v0    # "c":Ljava/net/HttpURLConnection;
    .end local v2    # "code":I
    .end local v3    # "body":Ljava/lang/StringBuilder;
    .end local v4    # "reader":Ljava/io/Reader;
    .end local p0    # "path":Ljava/lang/String;
    .end local p1    # "auth":Ljava/lang/String;
    .end local p2    # "task":Le/e/a/NetworkTask;
    :goto_8e
    throw v1
    :try_end_8f
    .catchall {:try_start_65 .. :try_end_8f} :catchall_b8

    .line 174
    .end local v5    # "buf":[C
    .end local v7    # "n":I
    .restart local v0    # "c":Ljava/net/HttpURLConnection;
    .restart local v2    # "code":I
    .restart local v3    # "body":Ljava/lang/StringBuilder;
    .restart local v4    # "reader":Ljava/io/Reader;
    .restart local p0    # "path":Ljava/lang/String;
    .restart local p1    # "auth":Ljava/lang/String;
    .restart local p2    # "task":Le/e/a/NetworkTask;
    :cond_8f
    :try_start_8f
    invoke-virtual {v4}, Ljava/io/Reader;->close()V

    .line 175
    .end local v4    # "reader":Ljava/io/Reader;
    new-instance v1, Lorg/json/JSONObject;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 176
    .local v1, "response":Lorg/json/JSONObject;
    const-string v4, "ok"

    const-string v5, "code"

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_a7
    .catchall {:try_start_8f .. :try_end_a7} :catchall_e2

    if-eqz v4, :cond_b0

    .line 177
    invoke-virtual {p2, v0}, Le/e/a/NetworkTask;->release(Ljava/net/HttpURLConnection;)V

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 176
    return-object v1

    :cond_b0
    :try_start_b0
    new-instance v4, Ljava/io/IOException;

    const-string v5, "Feed did not return ok"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "c":Ljava/net/HttpURLConnection;
    .end local p0    # "path":Ljava/lang/String;
    .end local p1    # "auth":Ljava/lang/String;
    .end local p2    # "task":Le/e/a/NetworkTask;
    throw v4
    :try_end_b8
    .catchall {:try_start_b0 .. :try_end_b8} :catchall_e2

    .line 171
    .end local v1    # "response":Lorg/json/JSONObject;
    .restart local v0    # "c":Ljava/net/HttpURLConnection;
    .restart local v4    # "reader":Ljava/io/Reader;
    .restart local p0    # "path":Ljava/lang/String;
    .restart local p1    # "auth":Ljava/lang/String;
    .restart local p2    # "task":Le/e/a/NetworkTask;
    :catchall_b8
    move-exception v1

    :try_start_b9
    invoke-virtual {v4}, Ljava/io/Reader;->close()V
    :try_end_bc
    .catchall {:try_start_b9 .. :try_end_bc} :catchall_bd

    goto :goto_c1

    :catchall_bd
    move-exception v5

    :try_start_be
    invoke-virtual {v1, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "c":Ljava/net/HttpURLConnection;
    .end local p0    # "path":Ljava/lang/String;
    .end local p1    # "auth":Ljava/lang/String;
    .end local p2    # "task":Le/e/a/NetworkTask;
    :goto_c1
    throw v1

    .line 169
    .end local v3    # "body":Ljava/lang/StringBuilder;
    .end local v4    # "reader":Ljava/io/Reader;
    .restart local v0    # "c":Ljava/net/HttpURLConnection;
    .restart local p0    # "path":Ljava/lang/String;
    .restart local p1    # "auth":Ljava/lang/String;
    .restart local p2    # "task":Le/e/a/NetworkTask;
    :cond_c2
    new-instance v1, Ljava/io/IOException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Feed HTTP "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "c":Ljava/net/HttpURLConnection;
    .end local p0    # "path":Ljava/lang/String;
    .end local p1    # "auth":Ljava/lang/String;
    .end local p2    # "task":Le/e/a/NetworkTask;
    :goto_da
    throw v1

    .restart local v0    # "c":Ljava/net/HttpURLConnection;
    .restart local p0    # "path":Ljava/lang/String;
    .restart local p1    # "auth":Ljava/lang/String;
    .restart local p2    # "task":Le/e/a/NetworkTask;
    :cond_db
    new-instance v1, Le/e/a/FollowFeed$LoginRequired;

    const/4 v3, 0x0

    invoke-direct {v1, v3}, Le/e/a/FollowFeed$LoginRequired;-><init>(Le/e/a/FollowFeed$1;)V
    :try_end_e1
    .catchall {:try_start_be .. :try_end_e1} :catchall_e2

    goto :goto_da

    .line 177
    .end local v2    # "code":I
    :catchall_e2
    move-exception v1

    invoke-virtual {p2, v0}, Le/e/a/NetworkTask;->release(Ljava/net/HttpURLConnection;)V

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v1

    .line 165
    :cond_ea
    new-instance v1, Ljava/io/InterruptedIOException;

    invoke-direct {v1}, Ljava/io/InterruptedIOException;-><init>()V

    throw v1
.end method

.method private static filterName(Landroid/content/Context;I)Ljava/lang/String;
    .registers 9
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "i"    # I

    .line 71
    const/4 v0, 0x4

    new-array v0, v0, [[Ljava/lang/String;

    const-string v1, "Content"

    const-string v2, "\u5167\u5bb9"

    const-string v3, "\u30b3\u30f3\u30c6\u30f3\u30c4"

    filled-new-array {v3, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "Videos"

    const-string v3, "\u5f71\u7247"

    const-string v4, "\u52d5\u753b"

    filled-new-array {v4, v1, v3}, [Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const-string v1, "Shorts"

    const-string v4, "\u77ed\u5f71\u7247"

    const-string v5, "\u30b7\u30e7\u30fc\u30c8"

    filled-new-array {v5, v1, v4}, [Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    aput-object v1, v0, v4

    const-string v1, "All"

    const-string v5, "\u5168\u90e8"

    const-string v6, "\u3059\u3079\u3066"

    filled-new-array {v6, v1, v5}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    aput-object v1, v0, v5

    .line 72
    .local v0, "names":[[Ljava/lang/String;
    aget-object v1, v0, p1

    aget-object v1, v1, v2

    aget-object v2, v0, p1

    aget-object v2, v2, v3

    aget-object v3, v0, p1

    aget-object v3, v3, v4

    invoke-static {p0, v1, v2, v3}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private static imageBox(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;
    .registers 8
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "round"    # Z

    .line 268
    if-eqz p1, :cond_8

    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    goto :goto_d

    :cond_8
    new-instance v0, Le/e/a/FollowFeed$Thumbnail;

    invoke-direct {v0, p0}, Le/e/a/FollowFeed$Thumbnail;-><init>(Landroid/content/Context;)V

    .local v0, "box":Landroid/widget/FrameLayout;
    :goto_d
    invoke-static {p0}, Le/e/a/FollowFeed;->surface(Landroid/content/Context;)I

    move-result v1

    const/4 v2, 0x0

    if-eqz p1, :cond_17

    const/16 v3, 0x64

    goto :goto_18

    :cond_17
    const/4 v3, 0x0

    :goto_18
    invoke-static {p0, v1, v3, v2}, Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 269
    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .local v1, "image":Landroid/widget/ImageView;
    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 270
    if-eqz p1, :cond_37

    const/16 v3, 0x12

    goto :goto_39

    :cond_37
    const/16 v3, 0x1c

    :goto_39
    invoke-static {p0, v3, v2}, Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v3

    .local v3, "fallback":Landroid/widget/TextView;
    if-eqz p1, :cond_42

    const-string v5, "\u25cf"

    goto :goto_44

    :cond_42
    const-string v5, "\u25b6"

    :goto_44
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p0}, Le/e/a/ThemeChoice;->accent(Landroid/content/Context;)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v5, 0x11

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v5, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 271
    const/4 v4, 0x2

    new-array v4, v4, [Landroid/view/View;

    aput-object v1, v4, v2

    const/4 v2, 0x1

    aput-object v3, v4, v2

    invoke-virtual {v0, v4}, Landroid/widget/FrameLayout;->setTag(Ljava/lang/Object;)V

    .line 272
    if-eqz p1, :cond_6b

    invoke-static {v0}, Le/e/a/Following190;->roundAvatar(Landroid/view/View;)V

    :cond_6b
    return-object v0
.end method

.method private static label(Landroid/app/Activity;IZ)Landroid/widget/TextView;
    .registers 6
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "size"    # I
    .param p2, "bold"    # Z

    .line 55
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .local v0, "v":Landroid/widget/TextView;
    int-to-float v1, p1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-static {v0}, Le/e/a/ThemeChoice;->textColor(Landroid/view/View;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 56
    if-eqz p2, :cond_1c

    const-string v1, "sans-serif-medium"

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 57
    :cond_1c
    return-object v0
.end method

.method static synthetic lambda$load$0(Landroid/app/Activity;Landroid/view/View;)V
    .registers 4
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "v"    # Landroid/view/View;

    .line 96
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.sauzask.nicoid.NicoidFavUserActivity"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic lambda$load$1(Landroid/app/Activity;Le/e/a/FollowFeed$State;I)V
    .registers 3
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "state"    # Le/e/a/FollowFeed$State;
    .param p2, "index"    # I

    .line 99
    invoke-static {p0, p1, p2}, Le/e/a/FollowFeed;->select(Landroid/app/Activity;Le/e/a/FollowFeed$State;I)V

    return-void
.end method

.method static synthetic lambda$load$2(Le/e/a/FollowFeed$State;I)V
    .registers 3
    .param p0, "state"    # Le/e/a/FollowFeed$State;
    .param p1, "index"    # I

    .line 100
    iget-object v0, p0, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    invoke-virtual {v0, p1}, Le/e/a/Ui110$Swipe;->select(I)V

    return-void
.end method

.method static synthetic lambda$load$3(Le/e/a/FollowFeed$State;Landroid/app/Activity;Landroid/view/View;)V
    .registers 5
    .param p0, "state"    # Le/e/a/FollowFeed$State;
    .param p1, "a"    # Landroid/app/Activity;
    .param p2, "v"    # Landroid/view/View;

    .line 107
    iget-object v0, p0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .local v0, "selected":Le/e/a/FollowFeed$State;
    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->failed:Z

    if-eqz v1, :cond_10

    iget-object v1, v0, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_10

    const/4 v1, 0x1

    goto :goto_11

    :cond_10
    const/4 v1, 0x0

    :goto_11
    invoke-static {p1, v0, v1}, Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    return-void
.end method

.method static synthetic lambda$load$4(Le/e/a/FollowFeed$State;Landroid/app/Activity;Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 10
    .param p0, "state"    # Le/e/a/FollowFeed$State;
    .param p1, "a"    # Landroid/app/Activity;
    .param p2, "parent"    # Landroid/widget/AdapterView;
    .param p3, "view"    # Landroid/view/View;
    .param p4, "position"    # I
    .param p5, "id"    # J

    .line 112
    iget-object v0, p0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .local v0, "selected":Le/e/a/FollowFeed$State;
    iget-object v1, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p4, v1, :cond_20

    iget-object v1, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Le/e/a/FollowFeedData$Item;

    if-eqz v1, :cond_20

    iget-object v1, v0, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/FollowFeedData$Item;

    const/4 v2, 0x0

    invoke-static {p1, v0, v1, v2}, Le/e/a/FollowFeed;->open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V

    .line 113
    :cond_20
    return-void
.end method

.method static synthetic lambda$load$5(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V
    .registers 5
    .param p0, "state"    # Le/e/a/FollowFeed$State;
    .param p1, "a"    # Landroid/app/Activity;

    .line 120
    iget-object v0, p0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .local v0, "selected":Le/e/a/FollowFeed$State;
    iget-boolean v1, v0, Le/e/a/FollowFeed$State;->busy:Z

    if-nez v1, :cond_10

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    iget-object v1, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setSelection(I)V

    :cond_10
    return-void
.end method

.method static synthetic lambda$menu$6(Landroid/app/Activity;Landroid/view/MenuItem;)Z
    .registers 3
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "item"    # Landroid/view/MenuItem;

    .line 158
    invoke-static {p0}, Le/e/a/FollowFeed;->load(Landroid/app/Activity;)V

    const/4 v0, 0x1

    return v0
.end method

.method static synthetic lambda$renderAuthors$11(Landroid/app/Activity;Le/e/a/FollowFeed$State;Landroid/view/View;)V
    .registers 4
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "v"    # Landroid/view/View;

    .line 252
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Le/e/a/FollowFeed;->chooseActor(Landroid/app/Activity;Le/e/a/FollowFeed$State;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$renderAuthors$12(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Actor;Landroid/view/View;)V
    .registers 5
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "actor"    # Le/e/a/FollowFeedData$Actor;
    .param p3, "v"    # Landroid/view/View;

    .line 263
    invoke-virtual {p2}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, p1, v0}, Le/e/a/FollowFeed;->chooseActor(Landroid/app/Activity;Le/e/a/FollowFeed$State;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$request$10(ILjava/lang/String;Ljava/lang/String;Le/e/a/NetworkTask;ZLe/e/a/FollowFeed$State;Landroid/app/Activity;)V
    .registers 23
    .param p0, "filter"    # I
    .param p1, "cursor"    # Ljava/lang/String;
    .param p2, "auth"    # Ljava/lang/String;
    .param p3, "task"    # Le/e/a/NetworkTask;
    .param p4, "refresh"    # Z
    .param p5, "s"    # Le/e/a/FollowFeed$State;
    .param p6, "a"    # Landroid/app/Activity;

    .line 190
    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v4, p3

    :try_start_6
    const-string v0, "publish"

    const-string v3, "video"

    const-string v5, "short_video"

    const-string v6, "all"

    filled-new-array {v0, v3, v5, v6}, [Ljava/lang/String;

    move-result-object v0

    move-object v11, v0

    .line 191
    .local v11, "types":[Ljava/lang/String;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "activities/followings/"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    aget-object v3, v11, p0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "?context=my_timeline&limit=50"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 192
    .local v0, "path":Ljava/lang/String;
    if-eqz v1, :cond_4e

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "&cursor="

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "UTF-8"

    invoke-static {v1, v5}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object v0, v3

    :cond_4e
    move-object v12, v0

    .line 193
    .end local v0    # "path":Ljava/lang/String;
    .local v12, "path":Ljava/lang/String;
    invoke-static {v12, v2, v4}, Le/e/a/FollowFeed;->fetch(Ljava/lang/String;Ljava/lang/String;Le/e/a/NetworkTask;)Lorg/json/JSONObject;

    move-result-object v0

    move-object v13, v0

    .local v13, "response":Lorg/json/JSONObject;
    invoke-static {v13}, Le/e/a/FollowFeedData;->parse(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v7

    .line 194
    .local v7, "items":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Item;>;"
    const-string v0, "nextCursor"

    invoke-static {v13, v0}, Le/e/a/FollowFeedData;->string(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 195
    .local v9, "next":Ljava/lang/String;
    const-string v0, "activities"

    invoke-virtual {v13, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v14, v0

    .local v14, "raw":Lorg/json/JSONArray;
    if-eqz v14, :cond_71

    invoke-virtual {v14}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-nez v0, :cond_6e

    goto :goto_71

    :cond_6e
    const/4 v0, 0x0

    const/4 v10, 0x0

    goto :goto_73

    :cond_71
    :goto_71
    const/4 v0, 0x1

    const/4 v10, 0x1

    .line 196
    .local v10, "empty":Z
    :goto_73
    const/4 v3, 0x0

    .line 197
    .local v3, "actors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    if-eqz p4, :cond_8a

    invoke-virtual {v4}, Le/e/a/NetworkTask;->cancelled()Z

    move-result v0
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_7a} :catch_9f

    if-nez v0, :cond_8a

    :try_start_7c
    const-string v0, "actors?limit=50"

    invoke-static {v0, v2, v4}, Le/e/a/FollowFeed;->fetch(Ljava/lang/String;Ljava/lang/String;Le/e/a/NetworkTask;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v0}, Le/e/a/FollowFeedData;->actors(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_7c .. :try_end_86} :catch_89

    move-object v3, v0

    move-object v0, v3

    goto :goto_8b

    :catch_89
    move-exception v0

    .line 198
    :cond_8a
    move-object v0, v3

    .end local v3    # "actors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    .local v0, "actors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    :goto_8b
    move-object v8, v0

    .line 199
    .local v8, "authors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    :try_start_8c
    sget-object v15, Le/e/a/FollowFeed;->MAIN:Landroid/os/Handler;

    new-instance v3, Le/e/a/FollowFeed$11;

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    invoke-direct/range {v3 .. v10}, Le/e/a/FollowFeed$11;-><init>(Le/e/a/NetworkTask;Le/e/a/FollowFeed$State;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;Z)V

    invoke-virtual {v15, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_9a
    .catch Ljava/lang/Exception; {:try_start_8c .. :try_end_9a} :catch_9f

    .line 216
    move-object/from16 v6, p5

    move-object/from16 v7, p6

    .end local v0    # "actors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    .end local v7    # "items":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Item;>;"
    .end local v8    # "authors":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Le/e/a/FollowFeedData$Actor;>;"
    .end local v9    # "next":Ljava/lang/String;
    .end local v10    # "empty":Z
    .end local v11    # "types":[Ljava/lang/String;
    .end local v12    # "path":Ljava/lang/String;
    .end local v13    # "response":Lorg/json/JSONObject;
    .end local v14    # "raw":Lorg/json/JSONArray;
    goto :goto_bc

    .line 209
    :catch_9f
    move-exception v0

    .line 210
    .local v0, "error":Ljava/lang/Exception;
    invoke-virtual {v4}, Le/e/a/NetworkTask;->cancelled()Z

    move-result v3

    if-eqz v3, :cond_a7

    return-void

    .line 211
    :cond_a7
    sget-object v3, Le/e/a/FollowFeed;->MAIN:Landroid/os/Handler;

    new-instance v5, Le/e/a/FollowFeed$12;

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    invoke-direct {v5, v4, v6, v7, v0}, Le/e/a/FollowFeed$12;-><init>(Le/e/a/NetworkTask;Le/e/a/FollowFeed$State;Landroid/app/Activity;Ljava/lang/Exception;)V

    invoke-virtual {v3, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 215
    const-string v3, "nicoid-feed"

    const-string v5, "Feed request failed"

    invoke-static {v3, v5, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 217
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_bc
    return-void
.end method

.method static synthetic lambda$request$7(Le/e/a/FollowFeedData$Item;Le/e/a/FollowFeedData$Item;)I
    .registers 6
    .param p0, "left"    # Le/e/a/FollowFeedData$Item;
    .param p1, "right"    # Le/e/a/FollowFeedData$Item;

    .line 202
    iget-wide v0, p1, Le/e/a/FollowFeedData$Item;->time:J

    iget-wide v2, p0, Le/e/a/FollowFeedData$Item;->time:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$request$8(Le/e/a/NetworkTask;Le/e/a/FollowFeed$State;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;Z)V
    .registers 12
    .param p0, "task"    # Le/e/a/NetworkTask;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "a"    # Landroid/app/Activity;
    .param p3, "items"    # Ljava/util/ArrayList;
    .param p4, "authors"    # Ljava/util/ArrayList;
    .param p5, "next"    # Ljava/lang/String;
    .param p6, "empty"    # Z

    .line 200
    invoke-virtual {p0}, Le/e/a/NetworkTask;->cancelled()Z

    move-result v0

    if-nez v0, :cond_d9

    iget-object v0, p1, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    if-ne v0, p0, :cond_d9

    invoke-virtual {p2}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_d9

    iget-boolean v0, p1, Le/e/a/FollowFeed$State;->stopped:Z

    if-eqz v0, :cond_16

    goto/16 :goto_d9

    .line 201
    :cond_16
    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1a
    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/FollowFeedData$Item;

    .local v1, "item":Le/e/a/FollowFeedData$Item;
    iget-object v2, p1, Le/e/a/FollowFeed$State;->ids:Ljava/util/HashSet;

    iget-object v3, v1, Le/e/a/FollowFeedData$Item;->key:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1a

    iget-object v2, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1a

    .line 202
    .end local v1    # "item":Le/e/a/FollowFeedData$Item;
    :cond_36
    iget-object v0, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    new-instance v1, Le/e/a/FollowFeed$4;

    invoke-direct {v1}, Le/e/a/FollowFeed$4;-><init>()V

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 203
    if-eqz p4, :cond_61

    iget-object v0, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    invoke-virtual {p4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_61

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/FollowFeedData$Actor;

    .local v1, "actor":Le/e/a/FollowFeedData$Actor;
    iget-object v2, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4b

    .line 204
    .end local v1    # "actor":Le/e/a/FollowFeedData$Actor;
    :cond_61
    iget-object v0, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_67
    :goto_67
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_99

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le/e/a/FollowFeedData$Item;

    .local v1, "item":Le/e/a/FollowFeedData$Item;
    iget-object v2, v1, Le/e/a/FollowFeedData$Item;->author:Le/e/a/FollowFeedData$Actor;

    iget-object v2, v2, Le/e/a/FollowFeedData$Actor;->name:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_67

    iget-object v2, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    iget-object v3, v1, Le/e/a/FollowFeedData$Item;->author:Le/e/a/FollowFeedData$Actor;

    invoke-virtual {v3}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_67

    iget-object v2, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    iget-object v3, v1, Le/e/a/FollowFeedData$Item;->author:Le/e/a/FollowFeedData$Actor;

    invoke-virtual {v3}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v1, Le/e/a/FollowFeedData$Item;->author:Le/e/a/FollowFeedData$Actor;

    invoke-virtual {v2, v3, v4}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_67

    .line 205
    .end local v1    # "item":Le/e/a/FollowFeedData$Item;
    :cond_99
    invoke-virtual {p5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a1

    const/4 v0, 0x0

    goto :goto_a2

    :cond_a1
    move-object v0, p5

    :goto_a2
    iput-object v0, p1, Le/e/a/FollowFeed$State;->cursor:Ljava/lang/String;

    const/4 v0, 0x0

    if-nez p6, :cond_b6

    iget-object v1, p1, Le/e/a/FollowFeed$State;->cursor:Ljava/lang/String;

    if-eqz v1, :cond_b6

    iget-object v1, p1, Le/e/a/FollowFeed$State;->cursors:Ljava/util/HashSet;

    invoke-virtual {v1, p5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b4

    goto :goto_b6

    :cond_b4
    const/4 v1, 0x0

    goto :goto_b7

    :cond_b6
    :goto_b6
    const/4 v1, 0x1

    :goto_b7
    iput-boolean v1, p1, Le/e/a/FollowFeed$State;->end:Z

    iput-boolean v0, p1, Le/e/a/FollowFeed$State;->busy:Z

    .line 206
    invoke-static {p2, p1}, Le/e/a/FollowFeed;->renderAuthors(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p2, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p2, p1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    .line 207
    iget-object v0, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    if-nez v0, :cond_cb

    const-string v0, ""

    goto :goto_d5

    :cond_cb
    const-string v0, "Filtered by creator"

    const-string v1, "\u4f9d\u6295\u7a3f\u8005\u7be9\u9078"

    const-string v2, "\u6295\u7a3f\u8005\u3067\u7d5e\u308a\u8fbc\u307f\u4e2d"

    invoke-static {p2, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_d5
    invoke-static {p1, v0}, Le/e/a/FollowFeed;->status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V

    .line 208
    return-void

    .line 200
    :cond_d9
    :goto_d9
    return-void
.end method

.method static synthetic lambda$request$9(Le/e/a/NetworkTask;Le/e/a/FollowFeed$State;Landroid/app/Activity;Ljava/lang/Exception;)V
    .registers 7
    .param p0, "task"    # Le/e/a/NetworkTask;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "a"    # Landroid/app/Activity;
    .param p3, "error"    # Ljava/lang/Exception;

    .line 211
    invoke-virtual {p0}, Le/e/a/NetworkTask;->cancelled()Z

    move-result v0

    if-nez v0, :cond_3e

    iget-object v0, p1, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    if-ne v0, p0, :cond_3e

    invoke-virtual {p2}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_3e

    iget-boolean v0, p1, Le/e/a/FollowFeed$State;->stopped:Z

    if-eqz v0, :cond_15

    goto :goto_3e

    :cond_15
    const/4 v0, 0x0

    iput-boolean v0, p1, Le/e/a/FollowFeed$State;->busy:Z

    const/4 v0, 0x1

    iput-boolean v0, p1, Le/e/a/FollowFeed$State;->failed:Z

    .line 212
    instance-of v0, p3, Le/e/a/FollowFeed$LoginRequired;

    if-eqz v0, :cond_2a

    const-string v0, "Please sign in again"

    const-string v1, "\u8acb\u91cd\u65b0\u767b\u5165"

    const-string v2, "\u30ed\u30b0\u30a4\u30f3\u3057\u76f4\u3057\u3066\u304f\u3060\u3055\u3044"

    invoke-static {p2, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_34

    .line 213
    :cond_2a
    const-string v0, "Could not load. Refresh to retry"

    const-string v1, "\u7121\u6cd5\u53d6\u5f97\uff0c\u8acb\u91cd\u65b0\u6574\u7406\u4ee5\u91cd\u8a66"

    const-string v2, "\u53d6\u5f97\u3067\u304d\u307e\u305b\u3093\u3067\u3057\u305f\u3002\u66f4\u65b0\u3057\u3066\u518d\u8a66\u884c\u3057\u3066\u304f\u3060\u3055\u3044"

    invoke-static {p2, v2, v0, v1}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 212
    :goto_34
    invoke-static {p1, v0}, Le/e/a/FollowFeed;->status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V

    .line 214
    invoke-static {p2, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p2, p1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    return-void

    .line 211
    :cond_3e
    :goto_3e
    return-void
.end method

.method public static load(Landroid/app/Activity;)V
    .registers 17
    .param p0, "a"    # Landroid/app/Activity;

    .line 76
    move-object/from16 v1, p0

    :try_start_2
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "nicoid_my_page"

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {v1}, Le/e/a/AccountPage;->load(Landroid/app/Activity;)V

    return-void

    .line 77
    :cond_13
    invoke-static {v1}, Le/e/a/CreatorPage;->open(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1a

    return-void

    .line 78
    :cond_1a
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v2, "H"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-virtual {v0, v1, v3}, Ljava/lang/reflect/Field;->setBoolean(Ljava/lang/Object;Z)V

    .line 79
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v2, "I"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Field;->setBoolean(Ljava/lang/Object;Z)V

    .line 80
    sget-object v0, Le/e/a/FollowFeed;->STATES:Ljava/util/WeakHashMap;

    invoke-virtual {v0, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Le/e/a/FollowFeed$State;

    .line 81
    .local v0, "s":Le/e/a/FollowFeed$State;
    if-nez v0, :cond_2a4

    .line 82
    new-instance v4, Le/e/a/FollowFeed$State;

    const/4 v5, 0x0

    invoke-direct {v4, v5}, Le/e/a/FollowFeed$State;-><init>(Le/e/a/FollowFeed$1;)V

    move-object v0, v4

    const-string v4, "A"

    invoke-static {v1, v4}, Le/e/a/PlaybackSession;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/widget/ListView;

    iput-object v4, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iget-object v4, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    if-nez v4, :cond_55

    return-void

    .line 83
    :cond_55
    const-string v4, "O"

    invoke-static {v1, v4}, Le/e/a/PlaybackSession;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_5b} :catch_2ab

    .line 84
    .local v4, "bar":Ljava/lang/Object;
    const-string v6, "Nico \u52d5\u614b"

    const-string v7, "Nico Reports"

    const-string v8, "\u30cb\u30b3\u30ec\u30dd"

    if-eqz v4, :cond_76

    :try_start_63
    const-string v9, "b"

    new-array v10, v2, [Ljava/lang/Class;

    const-class v11, Ljava/lang/CharSequence;

    aput-object v11, v10, v3

    invoke-static {v1, v8, v7, v6}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-array v12, v2, [Ljava/lang/Object;

    aput-object v11, v12, v3

    invoke-static {v4, v9, v10, v12}, Le/e/a/PlaybackSession;->call(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    :cond_76
    invoke-static {v1, v8, v7, v6}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    .line 86
    if-eqz v4, :cond_8e

    const-string v6, "c"

    new-array v7, v2, [Ljava/lang/Class;

    const-class v8, Ljava/lang/CharSequence;

    aput-object v8, v7, v3

    new-array v8, v2, [Ljava/lang/Object;

    aput-object v5, v8, v3

    invoke-static {v4, v6, v7, v8}, Le/e/a/PlaybackSession;->call(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    :cond_8e
    const-string v6, "Q"

    invoke-static {v1, v6}, Le/e/a/PlaybackSession;->get(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    .local v6, "footer":Landroid/view/View;
    if-eqz v6, :cond_9d

    iget-object v7, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v7, v6}, Landroid/widget/ListView;->removeFooterView(Landroid/view/View;)Z

    .line 88
    :cond_9d
    iget-object v7, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v7}, Landroid/widget/ListView;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    instance-of v7, v7, Landroid/view/ViewGroup;

    if-eqz v7, :cond_b4

    iget-object v7, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v7}, Landroid/widget/ListView;->getParent()Landroid/view/ViewParent;

    move-result-object v7

    check-cast v7, Landroid/view/ViewGroup;

    iget-object v8, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 89
    :cond_b4
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v7, "root":Landroid/widget/LinearLayout;
    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-static {v7}, Le/e/a/ThemeChoice;->background(Landroid/view/View;)V

    invoke-static {v7}, Le/e/a/TabViewport110;->fill(Landroid/view/View;)V

    .line 90
    move-object v8, v0

    .local v8, "state":Le/e/a/FollowFeed$State;
    iput-object v8, v8, Le/e/a/FollowFeed$State;->session:Le/e/a/FollowFeed$State;

    iput-object v8, v8, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    const/4 v9, 0x4

    new-array v10, v9, [Le/e/a/FollowFeed$State;

    iput-object v10, v8, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    iget-object v10, v8, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    aput-object v8, v10, v3

    .line 91
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v10, "authorRow":Landroid/widget/LinearLayout;
    const/16 v11, 0x10

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v12, 0x8

    invoke-static {v1, v12}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v12}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v1, v12}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v1, v9}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v10, v13, v14, v12, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 92
    new-instance v12, Landroid/widget/HorizontalScrollView;

    invoke-direct {v12, v1}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .local v12, "scroll":Landroid/widget/HorizontalScrollView;
    invoke-virtual {v12, v3}, Landroid/widget/HorizontalScrollView;->setHorizontalScrollBarEnabled(Z)V

    .line 93
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v13, v0, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    iget-object v13, v0, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    invoke-virtual {v13, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v13, v0, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    invoke-virtual {v12, v13}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .line 94
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, -0x2

    invoke-direct {v13, v3, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v12, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    const-string v13, "\u30d5\u30a9\u30ed\u30fc\u4e00\u89a7 \u203a"

    const-string v5, "Following \u203a"

    const-string v14, "\u8ffd\u8e64\u5217\u8868 \u203a"

    invoke-static {v1, v13, v5, v14}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Le/e/a/FollowFeed;->chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .local v5, "follow":Landroid/widget/Button;
    invoke-static {v5}, Le/e/a/Ui110;->flat(Landroid/widget/Button;)V

    const/high16 v13, 0x41500000    # 13.0f

    invoke-virtual {v5, v13}, Landroid/widget/Button;->setTextSize(F)V

    .line 96
    new-instance v13, Le/e/a/FollowFeed$5;

    invoke-direct {v13, v1}, Le/e/a/FollowFeed$5;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v5, v13}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 97
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x30

    invoke-static {v1, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v13, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v5, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v7, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 99
    new-instance v13, Le/e/a/Ui110$Swipe;

    new-instance v14, Le/e/a/FollowFeed$6;

    invoke-direct {v14, v1, v8}, Le/e/a/FollowFeed$6;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-direct {v13, v1, v9, v14}, Le/e/a/Ui110$Swipe;-><init>(Landroid/content/Context;ILjava/util/function/IntConsumer;)V

    iput-object v13, v0, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    .line 100
    new-instance v9, Le/e/a/Ui110$Tabs;

    invoke-static {v1, v3}, Le/e/a/FollowFeed;->filterName(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v13

    invoke-static {v1, v2}, Le/e/a/FollowFeed;->filterName(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v14

    const/4 v2, 0x2

    invoke-static {v1, v2}, Le/e/a/FollowFeed;->filterName(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v2

    const/4 v15, 0x3

    invoke-static {v1, v15}, Le/e/a/FollowFeed;->filterName(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v15

    filled-new-array {v13, v14, v2, v15}, [Ljava/lang/String;

    move-result-object v2

    new-instance v13, Le/e/a/FollowFeed$7;

    invoke-direct {v13, v8}, Le/e/a/FollowFeed$7;-><init>(Le/e/a/FollowFeed$State;)V

    invoke-direct {v9, v1, v2, v13}, Le/e/a/Ui110$Tabs;-><init>(Landroid/content/Context;[Ljava/lang/String;Ljava/util/function/IntConsumer;)V

    iput-object v9, v0, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    iget-object v2, v0, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 101
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v2, "loading":Landroid/widget/LinearLayout;
    invoke-virtual {v2, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-static {v1, v11}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v1, v11}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v2, v9, v3, v11, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 102
    const/16 v9, 0xc

    invoke-static {v1, v9, v3}, Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v11

    iput-object v11, v0, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    iget-object v11, v0, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    const v13, 0x3f333333    # 0.7f

    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setAlpha(F)V

    iget-object v11, v0, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, -0x2

    invoke-direct {v13, v3, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v11, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 103
    new-instance v11, Landroid/widget/ProgressBar;

    invoke-direct {v11, v1}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    iput-object v11, v0, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    iget-object v11, v0, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    invoke-virtual {v11}, Landroid/widget/ProgressBar;->getIndeterminateDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v11

    invoke-virtual {v11}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v11

    invoke-static {v1}, Le/e/a/ThemeChoice;->accent(Landroid/content/Context;)I

    move-result v13

    sget-object v14, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v11, v13, v14}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 104
    iget-object v11, v0, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x14

    invoke-static {v1, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v13, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v11, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x1c

    invoke-static {v1, v13}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v13

    const/4 v14, -0x1

    invoke-direct {v11, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v2, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 105
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v11, "tail":Landroid/widget/LinearLayout;
    const/16 v13, 0x11

    invoke-virtual {v11, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-static {v1, v9}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v1, v9}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v1, v9}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v9

    const/16 v14, 0x18

    invoke-static {v1, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v11, v13, v15, v9, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 106
    const-string v9, "\u904e\u53bb\u306e\u65b0\u7740\u3092\u8aad\u307f\u8fbc\u3080"

    const-string v13, "Load older activity"

    const-string v14, "\u8f09\u5165\u8f03\u65e9\u7684\u52d5\u614b"

    invoke-static {v1, v9, v13, v14}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v1, v9}, Le/e/a/FollowFeed;->chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v9

    iput-object v9, v0, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    .line 107
    iget-object v9, v0, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    new-instance v13, Le/e/a/FollowFeed$8;

    invoke-direct {v13, v8, v1}, Le/e/a/FollowFeed$8;-><init>(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V

    invoke-virtual {v9, v13}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v9, v0, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 108
    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    const/4 v13, 0x0

    invoke-virtual {v9, v11, v13, v3}, Landroid/widget/ListView;->addFooterView(Landroid/view/View;Ljava/lang/Object;Z)V

    new-instance v9, Le/e/a/FollowFeed$Rows;

    invoke-direct {v9, v1, v0}, Le/e/a/FollowFeed$Rows;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iput-object v9, v0, Le/e/a/FollowFeed$State;->rows:Le/e/a/FollowFeed$Rows;

    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iget-object v13, v0, Le/e/a/FollowFeed$State;->rows:Le/e/a/FollowFeed$Rows;

    invoke-virtual {v9, v13}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 109
    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    const/4 v13, 0x0

    invoke-virtual {v9, v13}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v9, v3}, Landroid/widget/ListView;->setCacheColorHint(I)V

    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-static {v9}, Le/e/a/ThemeChoice;->background(Landroid/view/View;)V

    .line 111
    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    new-instance v13, Le/e/a/FollowFeed$9;

    invoke-direct {v13, v8, v1}, Le/e/a/FollowFeed$9;-><init>(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V

    invoke-virtual {v9, v13}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 114
    iget-object v9, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    new-instance v13, Le/e/a/FollowFeed$1;

    invoke-direct {v13, v8, v1}, Le/e/a/FollowFeed$1;-><init>(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V

    invoke-virtual {v9, v13}, Landroid/widget/ListView;->setOnScrollListener(Landroid/widget/AbsListView$OnScrollListener;)V

    .line 120
    iget-object v9, v0, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    iget-object v13, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    new-instance v14, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v15, -0x1

    invoke-direct {v14, v15, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v13, v14}, Le/e/a/Ui110$Swipe;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v9, Le/e/a/FeedRefresh209;

    iget-object v13, v0, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    new-instance v14, Le/e/a/FollowFeed$10;

    invoke-direct {v14, v8, v1}, Le/e/a/FollowFeed$10;-><init>(Le/e/a/FollowFeed$State;Landroid/app/Activity;)V

    invoke-direct {v9, v1, v13, v14}, Le/e/a/FeedRefresh209;-><init>(Landroid/content/Context;Landroid/view/View;Ljava/lang/Runnable;)V

    iput-object v9, v0, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    iget-object v9, v0, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, -0x1

    invoke-direct {v13, v15, v3, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v9, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 121
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const-string v9, "y"

    invoke-virtual {v3, v9}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    invoke-virtual {v3, v1, v7}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v3, Le/e/a/FollowFeed;->STATES:Ljava/util/WeakHashMap;

    invoke-virtual {v3, v1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    invoke-static {v1, v0}, Le/e/a/FollowFeed;->renderAuthors(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {v1, v0}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    .line 123
    invoke-virtual {v1}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v3

    new-instance v9, Le/e/a/FollowFeed$2;

    invoke-direct {v9, v1, v8}, Le/e/a/FollowFeed$2;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-virtual {v3, v9}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 133
    .end local v2    # "loading":Landroid/widget/LinearLayout;
    .end local v4    # "bar":Ljava/lang/Object;
    .end local v5    # "follow":Landroid/widget/Button;
    .end local v6    # "footer":Landroid/view/View;
    .end local v7    # "root":Landroid/widget/LinearLayout;
    .end local v8    # "state":Le/e/a/FollowFeed$State;
    .end local v10    # "authorRow":Landroid/widget/LinearLayout;
    .end local v11    # "tail":Landroid/widget/LinearLayout;
    .end local v12    # "scroll":Landroid/widget/HorizontalScrollView;
    :cond_2a4
    iget-object v2, v0, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V
    :try_end_2aa
    .catch Ljava/lang/Exception; {:try_start_63 .. :try_end_2aa} :catch_2ab

    .line 134
    .end local v0    # "s":Le/e/a/FollowFeed$State;
    goto :goto_2b3

    :catch_2ab
    move-exception v0

    .local v0, "error":Ljava/lang/Exception;
    const-string v2, "nicoid-feed"

    const-string v3, "Feed view failed"

    invoke-static {v2, v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 135
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_2b3
    return-void
.end method

.method public static menu(Landroid/app/Activity;Landroid/view/Menu;)Z
    .registers 6
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "menu"    # Landroid/view/Menu;

    .line 157
    invoke-static {p0, p1}, Le/e/a/Ranking190;->managerMenu(Landroid/app/Activity;Landroid/view/Menu;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    .line 158
    :cond_8
    invoke-interface {p1}, Landroid/view/Menu;->clear()V

    const-string v0, "Refresh"

    const-string v2, "\u91cd\u65b0\u6574\u7406"

    const-string v3, "\u66f4\u65b0"

    invoke-static {p0, v3, v0, v2}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Landroid/view/Menu;->add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    new-instance v2, Le/e/a/FollowFeed$0;

    invoke-direct {v2, p0}, Le/e/a/FollowFeed$0;-><init>(Landroid/app/Activity;)V

    invoke-interface {v0, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    return v1
.end method

.method private static open(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Item;Z)V
    .registers 12
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "item"    # Le/e/a/FollowFeedData$Item;
    .param p3, "info"    # Z

    .line 298
    if-nez p3, :cond_75

    iget-boolean v0, p2, Le/e/a/FollowFeedData$Item;->shortVideo:Z

    if-eqz v0, :cond_75

    .line 299
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .local v0, "ids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .local v1, "titles":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .local v2, "thumbnails":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    const/4 v3, -0x1

    .line 302
    .local v3, "selected":I
    iget-object v4, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_53

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Le/e/a/FollowFeedData$Item;

    .local v5, "candidate":Le/e/a/FollowFeedData$Item;
    const/4 v6, 0x3

    iget-object v7, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-virtual {v5, v6, v7}, Le/e/a/FollowFeedData$Item;->matches(ILjava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_52

    iget-boolean v6, v5, Le/e/a/FollowFeedData$Item;->shortVideo:Z

    if-eqz v6, :cond_52

    .line 303
    iget-object v6, v5, Le/e/a/FollowFeedData$Item;->id:Ljava/lang/String;

    iget-object v7, p2, Le/e/a/FollowFeedData$Item;->id:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_43

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 304
    :cond_43
    iget-object v6, v5, Le/e/a/FollowFeedData$Item;->id:Ljava/lang/String;

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v6, v5, Le/e/a/FollowFeedData$Item;->title:Ljava/lang/String;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v6, v5, Le/e/a/FollowFeedData$Item;->thumbnail:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 302
    .end local v5    # "candidate":Le/e/a/FollowFeedData$Item;
    :cond_52
    goto :goto_1c

    .line 306
    :cond_53
    if-ltz v3, :cond_75

    const/4 v4, 0x0

    new-array v5, v4, [Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [Ljava/lang/String;

    new-array v6, v4, [Ljava/lang/String;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/String;

    new-array v4, v4, [Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Ljava/lang/String;

    invoke-static {p0, v5, v6, v4, v3}, Le/e/a/ModernShorts;->openVideos(Landroid/app/Activity;[Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;I)Z

    move-result v4

    if-eqz v4, :cond_75

    return-void

    .line 308
    .end local v0    # "ids":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    .end local v1    # "titles":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    .end local v2    # "thumbnails":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    .end local v3    # "selected":I
    :cond_75
    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "https://www.nicovideo.jp/watch/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p2, Le/e/a/FollowFeedData$Item;->id:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 309
    if-eqz p3, :cond_9a

    const-string v1, "com.sauzask.nicoid.NicoidVideoInfoActivity"

    goto :goto_9c

    :cond_9a
    const-string v1, "com.sauzask.nicoid.NicoidVideoActivity"

    :goto_9c
    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 308
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 310
    return-void
.end method

.method private static period(Landroid/content/Context;I)Ljava/lang/String;
    .registers 9
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "bucket"    # I

    .line 227
    const/4 v0, 0x6

    new-array v0, v0, [[Ljava/lang/String;

    const-string v1, "Today"

    const-string v2, "\u4eca\u5929"

    const-string v3, "\u4eca\u65e5"

    filled-new-array {v3, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "Yesterday"

    const-string v3, "\u6628\u5929"

    const-string v4, "\u6628\u65e5"

    filled-new-array {v4, v1, v3}, [Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const-string v1, "Past week"

    const-string v4, "\u4e00\u9031\u5167"

    const-string v5, "1\u9031\u9593"

    filled-new-array {v5, v1, v4}, [Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    aput-object v1, v0, v4

    const-string v1, "Past month"

    const-string v5, "\u4e00\u500b\u6708\u5167"

    const-string v6, "1\u304b\u6708"

    filled-new-array {v6, v1, v5}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    aput-object v1, v0, v5

    const-string v1, "Older than a month"

    const-string v5, "\u4e00\u500b\u6708\u4ee5\u524d"

    const-string v6, "1\u304b\u6708\u4ee5\u4e0a\u524d"

    filled-new-array {v6, v1, v5}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    aput-object v1, v0, v5

    const-string v1, "Date unavailable"

    const-string v5, "\u65e5\u671f\u4e0d\u660e"

    const-string v6, "\u65e5\u4ed8\u4e0d\u660e"

    filled-new-array {v6, v1, v5}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    aput-object v1, v0, v5

    .line 228
    .local v0, "labels":[[Ljava/lang/String;
    aget-object v1, v0, p1

    aget-object v1, v1, v2

    aget-object v2, v0, p1

    aget-object v2, v2, v3

    aget-object v3, v0, p1

    aget-object v3, v3, v4

    invoke-static {p0, v1, v2, v3}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private static rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 9
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;

    .line 231
    invoke-virtual {p1}, Le/e/a/FollowFeed$State;->active()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 232
    :cond_7
    iget-object v0, p1, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, -0x1

    .line 233
    .local v0, "last":I
    iget-object v1, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_42

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Le/e/a/FollowFeedData$Item;

    .local v2, "item":Le/e/a/FollowFeedData$Item;
    const/4 v3, 0x3

    iget-object v4, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Le/e/a/FollowFeedData$Item;->matches(ILjava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_41

    .line 234
    iget-wide v3, v2, Le/e/a/FollowFeedData$Item;->time:J

    iget-wide v5, p1, Le/e/a/FollowFeed$State;->now:J

    invoke-static {v3, v4, v5, v6}, Le/e/a/FollowFeedData;->bucket(JJ)I

    move-result v3

    .local v3, "bucket":I
    if-eq v3, v0, :cond_3c

    iget-object v4, p1, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v0, v3

    :cond_3c
    iget-object v4, p1, Le/e/a/FollowFeed$State;->visible:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 233
    .end local v2    # "item":Le/e/a/FollowFeedData$Item;
    .end local v3    # "bucket":I
    :cond_41
    goto :goto_13

    .line 236
    :cond_42
    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->busy:Z

    if-nez v1, :cond_5e

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->failed:Z

    if-nez v1, :cond_5e

    iget-object v1, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    if-nez v1, :cond_51

    const-string v1, ""

    goto :goto_5b

    :cond_51
    const-string v1, "Filtered by creator"

    const-string v2, "\u4f9d\u6295\u7a3f\u8005\u7be9\u9078"

    const-string v3, "\u6295\u7a3f\u8005\u3067\u7d5e\u308a\u8fbc\u307f\u4e2d"

    invoke-static {p0, v3, v1, v2}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_5b
    invoke-static {p1, v1}, Le/e/a/FollowFeed;->status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V

    .line 237
    :cond_5e
    iget-object v1, p1, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    if-eqz v1, :cond_69

    iget-object v1, p1, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    iget v2, p1, Le/e/a/FollowFeed$State;->filter:I

    invoke-virtual {v1, v2}, Le/e/a/Ui110$Tabs;->select(I)V

    :cond_69
    iget-object v1, p1, Le/e/a/FollowFeed$State;->rows:Le/e/a/FollowFeed$Rows;

    invoke-virtual {v1}, Le/e/a/FollowFeed$Rows;->notifyDataSetChanged()V

    .line 238
    return-void
.end method

.method private static renderAuthors(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 18
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;

    .line 246
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v1}, Le/e/a/FollowFeed$State;->active()Z

    move-result v2

    if-nez v2, :cond_b

    return-void

    .line 247
    :cond_b
    new-instance v2, Ljava/lang/StringBuilder;

    iget-object v3, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .local v2, "stamp":Ljava/lang/StringBuilder;
    const/4 v3, 0x0

    .line 248
    .local v3, "count":I
    iget-object v4, v1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_21
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/16 v6, 0x32

    if-eqz v5, :cond_58

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Le/e/a/FollowFeedData$Actor;

    .local v5, "actor":Le/e/a/FollowFeedData$Actor;
    add-int/lit8 v7, v3, 0x1

    .end local v3    # "count":I
    .local v7, "count":I
    if-lt v3, v6, :cond_35

    move v3, v7

    goto :goto_58

    :cond_35
    const/16 v3, 0x7c

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v8, v5, Le/e/a/FollowFeedData$Actor;->name:Ljava/lang/String;

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v6, v5, Le/e/a/FollowFeedData$Actor;->icon:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move v3, v7

    goto :goto_21

    .line 249
    .end local v5    # "actor":Le/e/a/FollowFeedData$Actor;
    .end local v7    # "count":I
    .restart local v3    # "count":I
    :cond_58
    :goto_58
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .local v4, "value":Ljava/lang/String;
    iget-object v5, v1, Le/e/a/FollowFeed$State;->authorStamp:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_65

    return-void

    :cond_65
    iput-object v4, v1, Le/e/a/FollowFeed$State;->authorStamp:Ljava/lang/String;

    .line 250
    iget-object v5, v1, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 251
    const-string v5, "All"

    const-string v7, "\u5168\u90e8"

    const-string v8, "\u3059\u3079\u3066"

    invoke-static {v0, v8, v5, v7}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Le/e/a/FollowFeed;->chip(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .local v5, "all":Landroid/widget/Button;
    iget-object v7, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v7, :cond_82

    const/4 v7, 0x1

    goto :goto_83

    :cond_82
    const/4 v7, 0x0

    :goto_83
    invoke-virtual {v5, v7}, Landroid/widget/Button;->setSelected(Z)V

    .line 252
    new-instance v7, Le/e/a/FollowFeed$13;

    invoke-direct {v7, v0, v1}, Le/e/a/FollowFeed$13;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-virtual {v5, v7}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 253
    iget-object v7, v1, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x28

    invoke-static {v0, v11}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, -0x2

    invoke-direct {v10, v12, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v5, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 254
    const/4 v7, 0x0

    .line 255
    .local v7, "shown":I
    iget-object v10, v1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    invoke-virtual {v10}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_aa
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_15a

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Le/e/a/FollowFeedData$Actor;

    .line 256
    .local v11, "actor":Le/e/a/FollowFeedData$Actor;
    add-int/lit8 v13, v7, 0x1

    .end local v7    # "shown":I
    .local v13, "shown":I
    if-lt v7, v6, :cond_bd

    move v7, v13

    goto/16 :goto_15a

    .line 257
    :cond_bd
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .local v7, "entry":Landroid/widget/LinearLayout;
    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v14, 0x11

    invoke-virtual {v7, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 258
    const/4 v15, 0x4

    invoke-static {v0, v15}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v0, v15}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v0, v15}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v0, v15}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v7, v6, v12, v14, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 259
    invoke-virtual {v11}, Le/e/a/FollowFeedData$Actor;->key()Ljava/lang/String;

    move-result-object v6

    iget-object v12, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_f7

    invoke-static {v0}, Le/e/a/FollowFeed;->surface(Landroid/content/Context;)I

    move-result v6

    const/16 v12, 0xc

    invoke-static {v0, v6, v12, v9}, Le/e/a/FollowFeed;->shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v7, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 260
    :cond_f7
    invoke-static {v0, v9}, Le/e/a/FollowFeed;->imageBox(Landroid/app/Activity;Z)Landroid/widget/FrameLayout;

    move-result-object v6

    .local v6, "picture":Landroid/widget/FrameLayout;
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x30

    invoke-static {v0, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v0, v14}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v12, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v6, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 261
    const/16 v12, 0xb

    invoke-static {v0, v12, v8}, Le/e/a/FollowFeed;->label(Landroid/app/Activity;IZ)Landroid/widget/TextView;

    move-result-object v12

    .local v12, "name":Landroid/widget/TextView;
    iget-object v14, v11, Le/e/a/FollowFeedData$Actor;->name:Ljava/lang/String;

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v12, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v14, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/16 v14, 0x11

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 262
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v15, -0x1

    const/4 v8, -0x2

    invoke-direct {v14, v15, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v12, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v8, v11, Le/e/a/FollowFeedData$Actor;->icon:Ljava/lang/String;

    invoke-static {v6, v8}, Le/e/a/FollowFeed;->bindImage(Landroid/widget/FrameLayout;Ljava/lang/String;)V

    .line 263
    iget-object v8, v11, Le/e/a/FollowFeedData$Actor;->name:Ljava/lang/String;

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v8, Le/e/a/FollowFeed$14;

    invoke-direct {v8, v0, v1, v11}, Le/e/a/FollowFeed$14;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;Le/e/a/FollowFeedData$Actor;)V

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 264
    iget-object v8, v1, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v15, 0x48

    invoke-static {v0, v15}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v15

    const/4 v9, -0x2

    invoke-direct {v14, v15, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v7, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 265
    .end local v6    # "picture":Landroid/widget/FrameLayout;
    .end local v7    # "entry":Landroid/widget/LinearLayout;
    .end local v11    # "actor":Le/e/a/FollowFeedData$Actor;
    .end local v12    # "name":Landroid/widget/TextView;
    move v7, v13

    const/16 v6, 0x32

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v12, -0x2

    goto/16 :goto_aa

    .line 266
    .end local v13    # "shown":I
    .local v7, "shown":I
    :cond_15a
    :goto_15a
    return-void
.end method

.method private static request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V
    .registers 13
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;
    .param p2, "refresh"    # Z

    .line 181
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_a3

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_a3

    iget-boolean v0, p1, Le/e/a/FollowFeed$State;->stopped:Z

    if-nez v0, :cond_a3

    if-nez p2, :cond_1f

    iget-boolean v0, p1, Le/e/a/FollowFeed$State;->busy:Z

    if-nez v0, :cond_1a

    iget-boolean v0, p1, Le/e/a/FollowFeed$State;->end:Z

    if-eqz v0, :cond_1f

    :cond_1a
    move-object v9, p0

    move-object v8, p1

    move v7, p2

    goto/16 :goto_a6

    .line 182
    :cond_1f
    const/4 v1, 0x1

    iput-boolean v1, p1, Le/e/a/FollowFeed$State;->initialized:Z

    iget-object v0, p1, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    if-eqz v0, :cond_2b

    iget-object v0, p1, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    invoke-virtual {v0}, Le/e/a/NetworkTask;->cancel()V

    :cond_2b
    const/4 v2, 0x0

    iput-boolean v2, p1, Le/e/a/FollowFeed$State;->failed:Z

    .line 183
    if-eqz p2, :cond_4d

    const/4 v0, 0x0

    iput-object v0, p1, Le/e/a/FollowFeed$State;->cursor:Ljava/lang/String;

    iput-boolean v2, p1, Le/e/a/FollowFeed$State;->end:Z

    iget-object v0, p1, Le/e/a/FollowFeed$State;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p1, Le/e/a/FollowFeed$State;->ids:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    iget-object v0, p1, Le/e/a/FollowFeed$State;->cursors:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iput-wide v3, p1, Le/e/a/FollowFeed$State;->now:J

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    .line 184
    :cond_4d
    :try_start_4d
    invoke-static {p0}, Le/e/a/FollowFeed;->cookie(Landroid/app/Activity;)Ljava/lang/String;

    move-result-object v0
    :try_end_51
    .catch Ljava/lang/Exception; {:try_start_4d .. :try_end_51} :catch_52

    .local v0, "credentials":Ljava/lang/String;
    goto :goto_56

    .end local v0    # "credentials":Ljava/lang/String;
    :catch_52
    move-exception v0

    .local v0, "error":Ljava/lang/Exception;
    const-string v3, ""

    move-object v0, v3

    .line 185
    .local v0, "credentials":Ljava/lang/String;
    :goto_56
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_74

    iput-boolean v2, p1, Le/e/a/FollowFeed$State;->busy:Z

    iput-boolean v1, p1, Le/e/a/FollowFeed$State;->failed:Z

    const-string v1, "Sign in to view following activity"

    const-string v2, "\u8acb\u767b\u5165\u4ee5\u67e5\u770b\u8ffd\u8e64\u52d5\u614b"

    const-string v3, "\u30ed\u30b0\u30a4\u30f3\u304c\u5fc5\u8981\u3067\u3059"

    invoke-static {p0, v3, v1, v2}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1}, Le/e/a/FollowFeed;->status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    return-void

    .line 186
    :cond_74
    move-object v5, v0

    .local v5, "auth":Ljava/lang/String;
    iget-object v4, p1, Le/e/a/FollowFeed$State;->cursor:Ljava/lang/String;

    .local v4, "cursor":Ljava/lang/String;
    iget v3, p1, Le/e/a/FollowFeed$State;->filter:I

    .local v3, "filter":I
    new-instance v6, Le/e/a/NetworkTask;

    invoke-direct {v6}, Le/e/a/NetworkTask;-><init>()V

    .local v6, "task":Le/e/a/NetworkTask;
    iput-object v6, p1, Le/e/a/FollowFeed$State;->task:Le/e/a/NetworkTask;

    iput-boolean v1, p1, Le/e/a/FollowFeed$State;->busy:Z

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p0, p1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    .line 187
    const-string v1, "Loading\u2026"

    const-string v2, "\u8f09\u5165\u4e2d\u2026"

    const-string v7, "\u8aad\u307f\u8fbc\u307f\u4e2d\u2026"

    invoke-static {p0, v7, v1, v2}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1}, Le/e/a/FollowFeed;->status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V

    .line 188
    sget-object v1, Le/e/a/FollowFeed;->WORKER:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Le/e/a/FollowFeed$3;

    move-object v9, p0

    move-object v8, p1

    move v7, p2

    .end local p0    # "a":Landroid/app/Activity;
    .end local p1    # "s":Le/e/a/FollowFeed$State;
    .end local p2    # "refresh":Z
    .local v7, "refresh":Z
    .local v8, "s":Le/e/a/FollowFeed$State;
    .local v9, "a":Landroid/app/Activity;
    invoke-direct/range {v2 .. v9}, Le/e/a/FollowFeed$3;-><init>(ILjava/lang/String;Ljava/lang/String;Le/e/a/NetworkTask;ZLe/e/a/FollowFeed$State;Landroid/app/Activity;)V

    invoke-virtual {v6, v1, v2}, Le/e/a/NetworkTask;->start(Ljava/util/concurrent/ExecutorService;Ljava/lang/Runnable;)V

    .line 218
    return-void

    .line 181
    .end local v0    # "credentials":Ljava/lang/String;
    .end local v3    # "filter":I
    .end local v4    # "cursor":Ljava/lang/String;
    .end local v5    # "auth":Ljava/lang/String;
    .end local v6    # "task":Le/e/a/NetworkTask;
    .end local v7    # "refresh":Z
    .end local v8    # "s":Le/e/a/FollowFeed$State;
    .end local v9    # "a":Landroid/app/Activity;
    .restart local p0    # "a":Landroid/app/Activity;
    .restart local p1    # "s":Le/e/a/FollowFeed$State;
    .restart local p2    # "refresh":Z
    :cond_a3
    move-object v9, p0

    move-object v8, p1

    move v7, p2

    .end local p0    # "a":Landroid/app/Activity;
    .end local p1    # "s":Le/e/a/FollowFeed$State;
    .end local p2    # "refresh":Z
    .restart local v7    # "refresh":Z
    .restart local v8    # "s":Le/e/a/FollowFeed$State;
    .restart local v9    # "a":Landroid/app/Activity;
    :goto_a6
    return-void
.end method

.method private static select(Landroid/app/Activity;Le/e/a/FollowFeed$State;I)V
    .registers 12
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "session"    # Le/e/a/FollowFeed$State;
    .param p2, "index"    # I

    .line 137
    iget-object v0, p1, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    .line 138
    .local v0, "previous":Le/e/a/FollowFeed$State;
    iget v1, v0, Le/e/a/FollowFeed$State;->filter:I

    if-ne v1, p2, :cond_7

    return-void

    .line 139
    :cond_7
    iget-object v1, v0, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v1

    iput-object v1, v0, Le/e/a/FollowFeed$State;->scroll:Landroid/os/Parcelable;

    .line 140
    iget-object v1, p1, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    aget-object v1, v1, p2

    .line 141
    .local v1, "next":Le/e/a/FollowFeed$State;
    const/4 v2, 0x0

    if-nez v1, :cond_4f

    .line 142
    new-instance v3, Le/e/a/FollowFeed$State;

    invoke-direct {v3, v2}, Le/e/a/FollowFeed$State;-><init>(Le/e/a/FollowFeed$1;)V

    move-object v1, v3

    iput p2, v1, Le/e/a/FollowFeed$State;->filter:I

    iput-object p1, v1, Le/e/a/FollowFeed$State;->session:Le/e/a/FollowFeed$State;

    iget-boolean v3, v0, Le/e/a/FollowFeed$State;->stopped:Z

    iput-boolean v3, v1, Le/e/a/FollowFeed$State;->stopped:Z

    .line 143
    iget-object v3, p1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    .line 144
    iget-object v3, p1, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->swipe:Le/e/a/Ui110$Swipe;

    iget-object v3, p1, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    iput-object v3, v1, Le/e/a/FollowFeed$State;->authors:Landroid/widget/LinearLayout;

    new-instance v3, Le/e/a/FollowFeed$Rows;

    invoke-direct {v3, p0, v1}, Le/e/a/FollowFeed$Rows;-><init>(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    iput-object v3, v1, Le/e/a/FollowFeed$State;->rows:Le/e/a/FollowFeed$Rows;

    .line 145
    iget-object v3, p1, Le/e/a/FollowFeed$State;->pages:[Le/e/a/FollowFeed$State;

    aput-object v1, v3, p2

    .line 147
    :cond_4f
    iget-object v3, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    iget-object v4, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-static {v3, v4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x1

    xor-int/2addr v3, v4

    .line 148
    .local v3, "authorChanged":Z
    iget-object v5, p1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    iput-object v5, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    iget-object v5, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    if-eqz v5, :cond_7c

    iget-object v5, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    iget-object v6, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_7c

    iget-object v5, v1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    iget-object v6, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    iget-object v7, p1, Le/e/a/FollowFeed$State;->actors:Ljava/util/LinkedHashMap;

    iget-object v8, v1, Le/e/a/FollowFeed$State;->actorKey:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Le/e/a/FollowFeedData$Actor;

    invoke-virtual {v5, v6, v7}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7c
    if-eqz v3, :cond_80

    iput-object v2, v1, Le/e/a/FollowFeed$State;->scroll:Landroid/os/Parcelable;

    .line 149
    :cond_80
    iput-object v1, p1, Le/e/a/FollowFeed$State;->current:Le/e/a/FollowFeed$State;

    const/4 v5, 0x0

    iput-boolean v5, v1, Le/e/a/FollowFeed$State;->autoLoad:Z

    iput-object v2, v1, Le/e/a/FollowFeed$State;->authorStamp:Ljava/lang/String;

    .line 150
    iget-object v2, v1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iget-object v6, v1, Le/e/a/FollowFeed$State;->rows:Le/e/a/FollowFeed$Rows;

    invoke-virtual {v2, v6}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v2, v1, Le/e/a/FollowFeed$State;->tabs:Le/e/a/Ui110$Tabs;

    invoke-virtual {v2, p2}, Le/e/a/Ui110$Tabs;->select(I)V

    iget-object v2, v1, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    iget-object v6, v1, Le/e/a/FollowFeed$State;->message:Ljava/lang/CharSequence;

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 151
    invoke-static {p0, v1}, Le/e/a/FollowFeed;->renderAuthors(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p0, v1}, Le/e/a/FollowFeed;->rebuild(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    invoke-static {p0, v1}, Le/e/a/FollowFeed;->updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V

    .line 152
    iget-object v2, v1, Le/e/a/FollowFeed$State;->scroll:Landroid/os/Parcelable;

    if-eqz v2, :cond_af

    iget-object v2, v1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    iget-object v5, v1, Le/e/a/FollowFeed$State;->scroll:Landroid/os/Parcelable;

    invoke-virtual {v2, v5}, Landroid/widget/ListView;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    goto :goto_b4

    :cond_af
    iget-object v2, v1, Le/e/a/FollowFeed$State;->list:Landroid/widget/ListView;

    invoke-virtual {v2, v5}, Landroid/widget/ListView;->setSelection(I)V

    .line 153
    :goto_b4
    iget-boolean v2, v1, Le/e/a/FollowFeed$State;->initialized:Z

    if-nez v2, :cond_bb

    invoke-static {p0, v1, v4}, Le/e/a/FollowFeed;->request(Landroid/app/Activity;Le/e/a/FollowFeed$State;Z)V

    .line 154
    :cond_bb
    return-void
.end method

.method private static shape(Landroid/content/Context;IIZ)Landroid/graphics/drawable/GradientDrawable;
    .registers 8
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "fill"    # I
    .param p2, "radius"    # I
    .param p3, "border"    # Z

    .line 60
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .local v0, "bg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-static {p0, p2}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 61
    if-eqz p3, :cond_2a

    const/4 v1, 0x1

    invoke-static {p0, v1}, Le/e/a/FollowFeed;->dp(Landroid/content/Context;I)I

    move-result v1

    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v2}, Le/e/a/ThemeChoice;->textColor(Landroid/view/View;)I

    move-result v2

    const v3, 0xffffff

    and-int/2addr v2, v3

    const/high16 v3, 0x22000000

    or-int/2addr v2, v3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 62
    :cond_2a
    return-object v0
.end method

.method private static status(Le/e/a/FollowFeed$State;Ljava/lang/CharSequence;)V
    .registers 3
    .param p0, "s"    # Le/e/a/FollowFeed$State;
    .param p1, "message"    # Ljava/lang/CharSequence;

    .line 155
    iput-object p1, p0, Le/e/a/FollowFeed$State;->message:Ljava/lang/CharSequence;

    invoke-virtual {p0}, Le/e/a/FollowFeed$State;->active()Z

    move-result v0

    if-eqz v0, :cond_d

    iget-object v0, p0, Le/e/a/FollowFeed$State;->status:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_d
    return-void
.end method

.method private static surface(Landroid/content/Context;)I
    .registers 5
    .param p0, "c"    # Landroid/content/Context;

    .line 52
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "attr"

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "nicoidSurface"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-static {p0}, Le/e/a/ThemeChoice;->isNight(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1a

    const v1, -0xcfcdc8

    goto :goto_1d

    :cond_1a
    const v1, -0xe0c0c

    :goto_1d
    invoke-static {p0, v0, v1}, Le/e/a/FollowFeed;->color(Landroid/content/Context;II)I

    move-result v0

    return v0
.end method

.method private static text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p0, "c"    # Landroid/content/Context;
    .param p1, "ja"    # Ljava/lang/String;
    .param p2, "en"    # Ljava/lang/String;
    .param p3, "zh"    # Ljava/lang/String;

    .line 42
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "app_lang"

    const-string v2, "0"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 43
    .local v0, "lang":Ljava/lang/String;
    const-string v1, "-1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    .line 44
    :cond_1c
    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_42

    const-string v1, "en"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    goto :goto_42

    :cond_2d
    const-string v1, "2"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_40

    const-string v1, "zh"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3e

    goto :goto_40

    :cond_3e
    move-object v1, p1

    goto :goto_43

    :cond_40
    :goto_40
    move-object v1, p3

    goto :goto_43

    :cond_42
    :goto_42
    move-object v1, p2

    :goto_43
    return-object v1
.end method

.method private static updateFooter(Landroid/app/Activity;Le/e/a/FollowFeed$State;)V
    .registers 6
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "s"    # Le/e/a/FollowFeed$State;

    .line 220
    invoke-virtual {p1}, Le/e/a/FollowFeed$State;->active()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 221
    :cond_7
    iget-object v0, p1, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    if-eqz v0, :cond_12

    iget-object v0, p1, Le/e/a/FollowFeed$State;->refresh:Le/e/a/FeedRefresh209;

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->busy:Z

    invoke-virtual {v0, v1}, Le/e/a/FeedRefresh209;->setRefreshing(Z)V

    .line 222
    :cond_12
    iget-object v0, p1, Le/e/a/FollowFeed$State;->progress:Landroid/widget/ProgressBar;

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->busy:Z

    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v1, :cond_1d

    const/4 v1, 0x0

    goto :goto_1f

    :cond_1d
    const/16 v1, 0x8

    :goto_1f
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 223
    iget-object v0, p1, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->end:Z

    if-eqz v1, :cond_2d

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->failed:Z

    if-nez v1, :cond_2d

    goto :goto_2e

    :cond_2d
    const/4 v2, 0x0

    :goto_2e
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    iget-object v0, p1, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->busy:Z

    if-nez v1, :cond_3c

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->stopped:Z

    if-nez v1, :cond_3c

    const/4 v3, 0x1

    :cond_3c
    invoke-virtual {v0, v3}, Landroid/widget/Button;->setEnabled(Z)V

    .line 224
    iget-object v0, p1, Le/e/a/FollowFeed$State;->more:Landroid/widget/Button;

    iget-boolean v1, p1, Le/e/a/FollowFeed$State;->failed:Z

    if-eqz v1, :cond_4c

    const-string v1, "Retry"

    const-string v2, "\u91cd\u8a66"

    const-string v3, "\u518d\u8a66\u884c"

    goto :goto_52

    :cond_4c
    const-string v1, "Load older activity"

    const-string v2, "\u8f09\u5165\u8f03\u65e9\u7684\u52d5\u614b"

    const-string v3, "\u904e\u53bb\u306e\u65b0\u7740\u3092\u8aad\u307f\u8fbc\u3080"

    :goto_52
    invoke-static {p0, v3, v1, v2}, Le/e/a/FollowFeed;->text(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 225
    return-void
.end method
