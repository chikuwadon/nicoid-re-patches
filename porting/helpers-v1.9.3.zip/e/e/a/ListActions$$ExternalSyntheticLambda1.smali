.class public final synthetic Le/e/a/ListActions$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le/e/a/ListActions$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iput p2, p0, Le/e/a/ListActions$$ExternalSyntheticLambda1;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Le/e/a/ListActions$$ExternalSyntheticLambda1;->f$0:Landroid/app/Activity;

    iget v1, p0, Le/e/a/ListActions$$ExternalSyntheticLambda1;->f$1:I

    invoke-static {v0, v1}, Le/e/a/ListActions;->lambda$16(Landroid/app/Activity;I)V

    return-void
.end method
